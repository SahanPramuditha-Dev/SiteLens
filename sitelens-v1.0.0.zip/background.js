// ../../packages/rule-definitions/src/privacy.ts
function text(value, limit = 4096) {
  return String(value ?? "").replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "").slice(0, limit);
}
function redactUrl(value) {
  try {
    if (!value) return "[unavailable URL]";
    const u = new URL(value);
    if (!["http:", "https:"].includes(u.protocol)) return `${u.protocol}[OMITTED]`;
    u.username = "";
    u.password = "";
    u.hash = "";
    if (u.search) u.search = "?REDACTED";
    u.pathname = u.pathname.split("/").map((p) => p.length > 80 || /^eyJ[\w-]+\.[\w-]+\.[\w-]+$/.test(p) ? "[REDACTED]" : p).join("/");
    return text(u.href, 2048);
  } catch {
    return "[unavailable URL]";
  }
}
function redactHeader(value) {
  return text(value, 16e3).replace(/'nonce-[^']*'/gi, "'nonce-[REDACTED]'").replace(/https?:\/\/[^\s;,]+/gi, redactUrl).replace(/\beyJ[\w-]+\.[\w-]+\.[\w-]+\b/g, "[REDACTED]");
}
function cookieMetadata(cookie) {
  return {
    name: text(cookie.name, 128),
    domain: text(cookie.domain, 256),
    path: redactUrl(`https://metadata.invalid${cookie.path || "/"}`).replace(
      "https://metadata.invalid",
      ""
    ),
    secure: cookie.secure === true,
    httpOnly: cookie.httpOnly === true,
    sameSite: text(cookie.sameSite || "unspecified", 32),
    hostOnly: cookie.hostOnly === true,
    session: cookie.session === true,
    ...Number.isFinite(cookie.expirationDate) ? { expirationDate: cookie.expirationDate } : {},
    partitioned: !!cookie.partitionKey,
    value: "[REDACTED]"
  };
}
async function hashUrl(url) {
  const u = new URL(url);
  u.hash = "";
  const digest2 = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(u.href));
  return [...new Uint8Array(digest2)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function originOf(url) {
  try {
    if (!url) return "";
    return new URL(url).origin;
  } catch {
    return "";
  }
}
function httpUrl(url) {
  try {
    return ["http:", "https:"].includes(new URL(url).protocol);
  } catch {
    return false;
  }
}

// ../../packages/rule-definitions/src/scope.ts
function defaultScope(url) {
  return {
    origins: [new URL(url).origin],
    domains: [],
    includeSubdomains: false,
    pathPrefixes: ["/"],
    excludedPaths: [],
    includeThirdParty: false,
    authorized: false,
    mode: "passive",
    requestBudget: 0,
    requestsPerSecond: 1,
    maxBytes: 1e6,
    timeoutMs: 1e4
  };
}
function pathMatch(path, prefix) {
  return prefix === "/" || path === prefix || path.startsWith(prefix.endsWith("/") ? prefix : prefix + "/");
}
function inScope(url, scope, thirdParty = false) {
  try {
    const u = new URL(url);
    if (!["http:", "https:", "ws:", "wss:"].includes(u.protocol) || u.username || u.password)
      return false;
    if (thirdParty && !scope.includeThirdParty) return false;
    const allowed = scope.origins.includes(u.origin) || scope.domains.some(
      (d) => u.hostname === d || scope.includeSubdomains && u.hostname.endsWith("." + d)
    );
    let path = u.pathname;
    for (let n = 0; n < 3; n++) {
      const decoded = decodeURIComponent(path);
      if (decoded === path) break;
      path = decoded;
    }
    if (/%(?:2e|2f|5c|25)/i.test(path)) return false;
    const segments = [];
    for (const segment of path.replaceAll("\\", "/").split("/")) {
      if (!segment || segment === ".") continue;
      if (segment === "..") segments.pop();
      else segments.push(segment);
    }
    path = "/" + segments.join("/");
    return allowed && scope.pathPrefixes.some((p) => pathMatch(path, p)) && !scope.excludedPaths.some((p) => pathMatch(path, p));
  } catch {
    return false;
  }
}
function validateScope(value) {
  if (!value || typeof value !== "object") throw new Error("Scope must be an object.");
  const s = value;
  for (const key2 of ["origins", "domains", "pathPrefixes", "excludedPaths"])
    if (!Array.isArray(s[key2]) || s[key2].some((v) => typeof v !== "string" || v.length > 2048) || s[key2].length > 100)
      throw new Error(`Invalid scope ${key2}.`);
  if (!s.origins.length && !s.domains.length)
    throw new Error("Scope requires an origin or domain.");
  if (s.origins.some((o) => {
    try {
      return new URL(o).origin !== o || !/^https?:/.test(o);
    } catch {
      return true;
    }
  }) || s.domains.some((d) => !/^([a-z0-9-]+\.)*[a-z0-9-]+$/i.test(d)))
    throw new Error("Scope origins or domains are invalid.");
  if ([...s.pathPrefixes, ...s.excludedPaths].some(
    (p) => !p.startsWith("/") || p.includes("..") || p.includes("?") || p.includes("#")
  ))
    throw new Error("Use absolute scope paths without queries or parent traversal.");
  for (const [k, min, max] of [
    ["requestBudget", 0, 100],
    ["requestsPerSecond", 0.1, 5],
    ["maxBytes", 1e3, 2e6],
    ["timeoutMs", 1e3, 3e4]
  ])
    if (!Number.isFinite(s[k]) || s[k] < min || s[k] > max) throw new Error(`Invalid scope ${k}.`);
  if (!["passive", "supplemental"].includes(s.mode)) throw new Error("Unsupported scope mode.");
  if (s.mode === "supplemental" && !s.authorized)
    throw new Error("Supplemental requests require recorded authorization.");
  return {
    ...s,
    includeSubdomains: s.includeSubdomains === true,
    includeThirdParty: s.includeThirdParty === true,
    authorized: s.authorized === true,
    requestBudget: s.mode === "passive" ? 0 : Math.trunc(s.requestBudget)
  };
}
var RequestBudget = class {
  used = 0;
  previous = 0;
  scope;
  constructor(scope) {
    this.scope = scope;
  }
  async reserve(url) {
    if (this.scope.mode !== "supplemental" || !this.scope.authorized || !inScope(url, this.scope) || this.used >= this.scope.requestBudget)
      throw new Error("Request blocked by scope, authorization or budget.");
    this.used++;
    const wait = Math.max(0, this.previous + 1e3 / this.scope.requestsPerSecond - Date.now());
    if (wait) await new Promise((r) => setTimeout(r, wait));
    this.previous = Date.now();
  }
  get count() {
    return this.used;
  }
};

// ../../packages/assessment-engine/src/workspace.ts
function freshness(a, binding, currentDocumentId, currentTargetKey) {
  return a.importedAt || a.reproducibility?.reevaluatedFrom || a.supplemental ? "older assessment" : !binding ? "unavailable" : currentTargetKey && a.targetKey !== currentTargetKey ? "page changed" : currentDocumentId && binding.documentId !== currentDocumentId ? "page changed" : !currentDocumentId && !currentTargetKey ? "current" : "current";
}
async function scopedText(url, scope, budget, request = fetch, assessmentOrigin = new URL(url).origin) {
  let target = url;
  for (let hop = 0; hop < 5; hop++) {
    if (!inScope(target, scope, new URL(target).origin !== assessmentOrigin))
      throw new Error("Bundle destination is outside the authorized scope.");
    await budget.reserve(target);
    const r = await request(target, {
      credentials: "omit",
      redirect: "manual",
      cache: "no-store",
      signal: AbortSignal.timeout(scope.timeoutMs)
    });
    if (r.status >= 300 && r.status < 400) {
      await r.body?.cancel();
      const location2 = r.headers.get("location");
      if (!location2) throw new Error("Redirect destination unavailable.");
      target = new URL(location2, target).href;
      continue;
    }
    if (!r.ok) throw new Error(`Response unavailable (${r.status}).`);
    const contentType = (r.headers.get("content-type") || "").split(";")[0].trim().toLowerCase();
    if (contentType && ![
      "application/javascript",
      "text/javascript",
      "application/x-javascript",
      "text/plain",
      "application/octet-stream"
    ].includes(contentType)) {
      await r.body?.cancel();
      throw new Error("Response is not a JavaScript bundle.");
    }
    const reader = r.body?.getReader();
    if (!reader) throw new Error("No body.");
    const chunks = [];
    let size = 0;
    for (; ; ) {
      const { value, done } = await reader.read();
      if (done) break;
      size += value.length;
      if (size > scope.maxBytes) {
        await reader.cancel();
        throw new Error("Response exceeds byte limit.");
      }
      chunks.push(value);
    }
    const bytes = new Uint8Array(size);
    let p = 0;
    for (const c of chunks) {
      bytes.set(c, p);
      p += c.length;
    }
    return {
      text: new TextDecoder().decode(bytes),
      url: redactUrl(target),
      bytes: size,
      status: r.status
    };
  }
  throw new Error("Redirect limit exceeded.");
}

// ../../packages/assessment-engine/src/backup.ts
var statuses = /* @__PURE__ */ new Set([
  "protection_observed",
  "potential_weakness",
  "informational",
  "not_applicable",
  "unable_to_assess"
]);
function validateBackup(input) {
  if (!input || typeof input !== "object")
    throw new Error("Choose an assessment or backup object.");
  const box = input;
  if (box.backupVersion !== void 0 && box.backupVersion !== 1)
    throw new Error("Unsupported backup version.");
  const source = Array.isArray(box.assessments) ? box.assessments : [input];
  if (!source.length || source.length > 200) throw new Error("Import 1\u2013200 assessments.");
  const scrub = (value, depth = 0, key2 = "") => {
    if (depth > 20) throw new Error("Evidence nesting exceeds limit.");
    if (["code", "inlineScripts", "sourcesContent", "rawValue", "windowKeys"].includes(key2))
      throw new Error("Raw source/credential fields are not accepted in backups.");
    if (key2 === "value") {
      if (value !== "[REDACTED]") throw new Error("Raw values are not accepted in backups.");
      return value;
    }
    if (key2 === "valueRedacted") return "[REDACTED]";
    if (typeof value === "string") {
      if (value.length > 32e3) throw new Error("Evidence text exceeds limit.");
      return /^https?:\/\//.test(value) ? redactUrl(value) : redactHeader(value);
    }
    if (Array.isArray(value)) {
      if (value.length > 5e3) throw new Error("Evidence array exceeds limit.");
      return value.map((v) => scrub(v, depth + 1));
    }
    if (value && typeof value === "object") {
      const out = {};
      for (const [k, v] of Object.entries(value)) {
        if (["__proto__", "constructor", "prototype"].includes(k))
          throw new Error("Unsafe field name.");
        out[k] = scrub(v, depth + 1, k);
      }
      return out;
    }
    return value;
  };
  const assessments = source.map((value) => {
    const a = value;
    if (!a || ![1, 2].includes(a.schemaVersion) || typeof a.id !== "string" || !a.id || !/^https?:\/\//.test(a.url) || !a.targetKey || !Number.isFinite(Date.parse(a.createdAt)))
      throw new Error("Unsupported assessment metadata.");
    for (const k of [
      "findings",
      "evidence",
      "resources",
      "forms",
      "frames",
      "cookies",
      "technologies",
      "coverage",
      "limits"
    ])
      if (!Array.isArray(a[k]) || a[k].length > 5e3)
        throw new Error("Missing or oversized assessment array: " + k);
    const strings = (value2, keys) => !!value2 && typeof value2 === "object" && keys.every((k) => typeof value2[k] === "string");
    if (a.technologies.some(
      (t) => t.signals !== void 0 && (!Array.isArray(t.signals) || t.signals.some(
        (s) => !strings(s, ["type", "source", "observation", "confidence"]) || ![
          "dom",
          "meta",
          "resource",
          "header",
          "cookie",
          "inference",
          "runtime",
          "stylesheet",
          "bundle"
        ].includes(s.type) || !["low", "medium", "high"].includes(s.confidence)
      ))
    ))
      throw new Error("Invalid technology signals.");
    try {
      if (new URL(a.url).origin !== a.origin || !["http:", "https:"].includes(new URL(a.url).protocol))
        throw new Error();
    } catch {
      throw new Error("Invalid assessment URL/origin.");
    }
    if (a.scope) validateScope(a.scope);
    for (const k of [
      "requests",
      "apiEndpoints",
      "advisoryMatches",
      "enabledChecks",
      "disabledChecks",
      "permissionsGranted",
      "timeouts"
    ])
      if (a[k] !== void 0 && !Array.isArray(a[k]))
        throw new Error("Invalid optional array: " + k);
    if ((a.apiEndpoints || []).some(
      (r) => !strings(r, ["url", "category", "initiator", "relationship", "authentication"])
    ) || (a.requests || []).some(
      (r) => !strings(r, ["url", "method", "type", "initiator", "authentication"])
    ))
      throw new Error("Invalid request metadata.");
    if ((a.advisoryMatches || []).some(
      (r) => !strings(r, [
        "id",
        "component",
        "affectedRange",
        "fixedVersion",
        "source",
        "detectedVersion"
      ])
    ))
      throw new Error("Invalid advisory details.");
    for (const e of a.evidence) {
      const d = e?.data;
      if (e?.type === "header" && e.label !== "CORS relationships" && (!strings(d, ["name", "availability"]) || !(d.values === null || Array.isArray(d.values) && d.values.every((v) => typeof v === "string"))))
        throw new Error("Invalid header evidence.");
      if (e?.label === "Redacted configuration patterns" && (!Array.isArray(d) || d.some(
        (s) => !strings(s, ["key", "source", "category", "confidence", "valueRedacted"]) || typeof s.isSecret !== "boolean"
      )))
        throw new Error("Invalid configuration evidence.");
      if (e?.label === "Client-side AST observations" && d !== null && d !== void 0 && (!strings(d, ["limitation"]) || !["apis", "sources", "flows", "handlers"].every((k) => Array.isArray(d[k])) || !Number.isFinite(d.parsed) || !Number.isFinite(d.failed)))
        throw new Error("Invalid script analysis evidence.");
    }
    if (!strings(a, ["version", "origin", "browser"]) || !["full", "verification"].includes(a.kind) || !Number.isFinite(a.durationMs) || !Number.isFinite(a.checksCompleted) || !Number.isFinite(a.checksTotal) || !a.limits.every((s) => typeof s === "string"))
      throw new Error("Invalid assessment details.");
    if (a.resources.some(
      (r) => !strings(r, ["url", "type"]) || !(r.integrity === null || typeof r.integrity === "string") || !(r.crossorigin === null || typeof r.crossorigin === "string")
    ) || a.forms.some((f) => !strings(f, ["action", "method"]) || typeof f.password !== "boolean") || a.frames.some(
      (f) => !strings(f, ["url"]) || !(f.sandbox === null || typeof f.sandbox === "string")
    ) || a.technologies.some(
      (t) => !strings(t, ["name", "layer", "observation", "version"]) || !["low", "medium", "high"].includes(t.confidence)
    ) || a.coverage.some((c) => !strings(c, ["area", "status", "detail"])))
      throw new Error("Invalid resource, technology or coverage details.");
    if (a.cookies.some(
      (c) => !strings(c, ["name", "domain", "path", "sameSite"]) || c.value !== "[REDACTED]" || ["secure", "httpOnly", "hostOnly", "session", "partitioned"].some(
        (k) => typeof c[k] !== "boolean"
      )
    ))
      throw new Error("Invalid or unredacted cookie metadata.");
    if (a.evidence.some(
      (e) => !strings(e, ["id", "type", "label", "source", "collectedAt"]) || typeof e.redacted !== "boolean"
    ))
      throw new Error("Invalid evidence details.");
    if (a.findings.some(
      (f) => !strings(f, [
        "id",
        "checkId",
        "title",
        "category",
        "affectedUrl",
        "observation",
        "impact",
        "limitation",
        "recommendation",
        "validation",
        "createdAt",
        "firstObserved"
      ]) || !["low", "medium", "high"].includes(f.confidence) || !["informational", "low", "medium", "high", "critical"].includes(f.severity) || ![
        "new",
        "acknowledged",
        "investigating",
        "accepted risk",
        "fixed",
        "needs verification",
        "verified",
        "false positive"
      ].includes(f.lifecycle) || !Array.isArray(f.references) || !f.references.every((r) => typeof r === "string")
    ))
      throw new Error("Invalid finding details.");
    const ids = new Set(a.evidence.map((e) => e.id));
    if (ids.size !== a.evidence.length || a.evidence.some((e) => !e.id || !Number.isFinite(Date.parse(e.collectedAt))))
      throw new Error("Invalid evidence identities/timestamps.");
    if (a.findings.some(
      (f) => !/^SL-[A-Z]+-\d+$/.test(f.checkId) || !statuses.has(f.status) || !Array.isArray(f.evidenceIds) || f.evidenceIds.some((id) => !ids.has(id))
    ))
      throw new Error("Invalid finding or evidence references.");
    const clean = scrub(a);
    clean.schemaVersion = 2;
    clean.importedAt = (/* @__PURE__ */ new Date()).toISOString();
    clean.originalId = a.originalId || a.id;
    clean.limits = [
      ...clean.limits,
      ...a.schemaVersion === 1 ? [
        "Compatible schema 1 record migrated; absent provenance/version metadata remains unknown."
      ] : []
    ];
    return clean;
  });
  if (box.events !== void 0 && !Array.isArray(box.events))
    throw new Error("Invalid lifecycle events.");
  const events = (box.events || []).filter(
    (e) => e && typeof e.note === "string" && Number.isFinite(Date.parse(e.at)) && assessments.some(
      (a) => a.id === e.assessmentId && a.targetKey === e.targetKey && a.findings.some((f) => f.checkId === e.checkId)
    )
  );
  if (events.length > 2e3) throw new Error("Too many lifecycle events.");
  return { assessments, events: scrub(events) };
}
function validateReportOptions(input) {
  if (!input || typeof input !== "object" || Array.isArray(input))
    throw new Error("Invalid report options.");
  const a = input, out = {};
  for (const key2 of ["assessor", "organization", "project"]) {
    if (a[key2] !== void 0) {
      if (typeof a[key2] !== "string" || a[key2].length > 128)
        throw new Error("Report labels must be 128 characters or fewer.");
      out[key2] = a[key2];
    }
  }
  if (a.audience !== void 0) {
    if (!["complete", "executive", "developer"].includes(a.audience))
      throw new Error("Invalid report audience.");
    out.audience = a.audience;
  }
  if (a.logo !== void 0) {
    if (!["sitelens", "none"].includes(a.logo)) throw new Error("Invalid report logo.");
    out.logo = a.logo;
  }
  if (a.selectedCheckIds !== void 0) {
    if (!Array.isArray(a.selectedCheckIds) || a.selectedCheckIds.length > 200 || a.selectedCheckIds.some((id) => typeof id !== "string" || !/^SL-[A-Z]+-\d+$/.test(id)))
      throw new Error("Invalid selected checks.");
    out.selectedCheckIds = [...new Set(a.selectedCheckIds)];
  }
  if (a.customLogo) {
    if (typeof a.customLogo !== "string" || a.customLogo.length > 28e4 || !/^data:image\/(?:png|jpeg);base64,[A-Za-z0-9+/]+=*$/.test(a.customLogo) || !(a.customLogo.startsWith("data:image/png;base64,iVBORw0KGgo") || a.customLogo.startsWith("data:image/jpeg;base64,/9j/")))
      throw new Error("Use a PNG or JPEG logo up to 200 KB.");
    out.customLogo = a.customLogo;
  }
  return out;
}

// ../../node_modules/acorn/dist/acorn.mjs
var astralIdentifierCodes = [509, 0, 227, 0, 150, 4, 294, 9, 1368, 2, 2, 1, 6, 3, 41, 2, 5, 0, 166, 1, 574, 3, 9, 9, 7, 9, 32, 4, 318, 1, 78, 5, 71, 10, 50, 3, 123, 2, 54, 14, 32, 10, 3, 1, 11, 3, 46, 10, 8, 0, 46, 9, 7, 2, 37, 13, 2, 9, 6, 1, 45, 0, 13, 2, 49, 13, 9, 3, 2, 11, 83, 11, 7, 0, 3, 0, 158, 11, 6, 9, 7, 3, 56, 1, 2, 6, 3, 1, 3, 2, 10, 0, 11, 1, 3, 6, 4, 4, 68, 8, 2, 0, 3, 0, 2, 3, 2, 4, 2, 0, 15, 1, 83, 17, 10, 9, 5, 0, 82, 19, 13, 9, 214, 6, 3, 8, 28, 1, 83, 16, 16, 9, 82, 12, 9, 9, 7, 19, 58, 14, 5, 9, 243, 14, 166, 9, 71, 5, 2, 1, 3, 3, 2, 0, 2, 1, 13, 9, 120, 6, 3, 6, 4, 0, 29, 9, 41, 6, 2, 3, 9, 0, 10, 10, 47, 15, 199, 7, 137, 9, 54, 7, 2, 7, 17, 9, 57, 21, 2, 13, 123, 5, 4, 0, 2, 1, 2, 6, 2, 0, 9, 9, 49, 4, 2, 1, 2, 4, 9, 9, 55, 9, 266, 3, 10, 1, 2, 0, 49, 6, 4, 4, 14, 10, 5350, 0, 7, 14, 11465, 27, 2343, 9, 87, 9, 39, 4, 60, 6, 26, 9, 535, 9, 470, 0, 2, 54, 8, 3, 82, 0, 12, 1, 19628, 1, 4178, 9, 519, 45, 3, 22, 543, 4, 4, 5, 9, 7, 3, 6, 31, 3, 149, 2, 1418, 49, 513, 54, 5, 49, 9, 0, 15, 0, 23, 4, 2, 14, 1361, 6, 2, 16, 3, 6, 2, 1, 2, 4, 101, 0, 161, 6, 10, 9, 357, 0, 62, 13, 499, 13, 245, 1, 2, 9, 233, 0, 3, 0, 8, 1, 6, 0, 475, 6, 110, 6, 6, 9, 4759, 9, 787719, 239];
var astralIdentifierStartCodes = [0, 11, 2, 25, 2, 18, 2, 1, 2, 14, 3, 13, 35, 122, 70, 52, 268, 28, 4, 48, 48, 31, 14, 29, 6, 37, 11, 29, 3, 35, 5, 7, 2, 4, 43, 157, 19, 35, 5, 35, 5, 39, 9, 51, 13, 10, 2, 14, 2, 6, 2, 1, 2, 10, 2, 14, 2, 6, 2, 1, 4, 51, 13, 310, 10, 21, 11, 7, 25, 5, 2, 41, 2, 8, 70, 5, 3, 0, 2, 43, 2, 1, 4, 0, 3, 22, 11, 22, 10, 30, 66, 18, 2, 1, 11, 21, 11, 25, 7, 25, 39, 55, 7, 1, 65, 0, 16, 3, 2, 2, 2, 28, 43, 28, 4, 28, 36, 7, 2, 27, 28, 53, 11, 21, 11, 18, 14, 17, 111, 72, 56, 50, 14, 50, 14, 35, 39, 27, 10, 22, 251, 41, 7, 1, 17, 5, 57, 28, 11, 0, 9, 21, 43, 17, 47, 20, 28, 22, 13, 52, 58, 1, 3, 0, 14, 44, 33, 24, 27, 35, 30, 0, 3, 0, 9, 34, 4, 0, 13, 47, 15, 3, 22, 0, 2, 0, 36, 17, 2, 24, 20, 1, 64, 6, 2, 0, 2, 3, 2, 14, 2, 9, 8, 46, 39, 7, 3, 1, 3, 21, 2, 6, 2, 1, 2, 4, 4, 0, 19, 0, 13, 4, 31, 9, 2, 0, 3, 0, 2, 37, 2, 0, 26, 0, 2, 0, 45, 52, 19, 3, 21, 2, 31, 47, 21, 1, 2, 0, 185, 46, 42, 3, 37, 47, 21, 0, 60, 42, 14, 0, 72, 26, 38, 6, 186, 43, 117, 63, 32, 7, 3, 0, 3, 7, 2, 1, 2, 23, 16, 0, 2, 0, 95, 7, 3, 38, 17, 0, 2, 0, 29, 0, 11, 39, 8, 0, 22, 0, 12, 45, 20, 0, 19, 72, 200, 32, 32, 8, 2, 36, 18, 0, 50, 29, 113, 6, 2, 1, 2, 37, 22, 0, 26, 5, 2, 1, 2, 31, 15, 0, 24, 43, 261, 18, 16, 0, 2, 12, 2, 33, 125, 0, 80, 921, 103, 110, 18, 195, 2637, 96, 16, 1071, 18, 5, 26, 3994, 6, 582, 6842, 29, 1763, 568, 8, 30, 18, 78, 18, 29, 19, 47, 17, 3, 32, 20, 6, 18, 433, 44, 212, 63, 33, 24, 3, 24, 45, 74, 6, 0, 67, 12, 65, 1, 2, 0, 15, 4, 10, 7381, 42, 31, 98, 114, 8702, 3, 2, 6, 2, 1, 2, 290, 16, 0, 30, 2, 3, 0, 15, 3, 9, 395, 2309, 106, 6, 12, 4, 8, 8, 9, 5991, 84, 2, 70, 2, 1, 3, 0, 3, 1, 3, 3, 2, 11, 2, 0, 2, 6, 2, 64, 2, 3, 3, 7, 2, 6, 2, 27, 2, 3, 2, 4, 2, 0, 4, 6, 2, 339, 3, 24, 2, 24, 2, 30, 2, 24, 2, 30, 2, 24, 2, 30, 2, 24, 2, 30, 2, 24, 2, 7, 1845, 30, 7, 5, 262, 61, 147, 44, 11, 6, 17, 0, 322, 29, 19, 43, 485, 27, 229, 29, 3, 0, 208, 30, 2, 2, 2, 1, 2, 6, 3, 4, 10, 1, 225, 6, 2, 3, 2, 1, 2, 14, 2, 196, 60, 67, 8, 0, 1205, 3, 2, 26, 2, 1, 2, 0, 3, 0, 2, 9, 2, 3, 2, 0, 2, 0, 7, 0, 5, 0, 2, 0, 2, 0, 2, 2, 2, 1, 2, 0, 3, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 1, 2, 0, 3, 3, 2, 6, 2, 3, 2, 3, 2, 0, 2, 9, 2, 16, 6, 2, 2, 4, 2, 16, 4421, 42719, 33, 4381, 3, 5773, 3, 7472, 16, 621, 2467, 541, 1507, 4938, 6, 8489];
var nonASCIIidentifierChars = "\u200C\u200D\xB7\u0300-\u036F\u0387\u0483-\u0487\u0591-\u05BD\u05BF\u05C1\u05C2\u05C4\u05C5\u05C7\u0610-\u061A\u064B-\u0669\u0670\u06D6-\u06DC\u06DF-\u06E4\u06E7\u06E8\u06EA-\u06ED\u06F0-\u06F9\u0711\u0730-\u074A\u07A6-\u07B0\u07C0-\u07C9\u07EB-\u07F3\u07FD\u0816-\u0819\u081B-\u0823\u0825-\u0827\u0829-\u082D\u0859-\u085B\u0897-\u089F\u08CA-\u08E1\u08E3-\u0903\u093A-\u093C\u093E-\u094F\u0951-\u0957\u0962\u0963\u0966-\u096F\u0981-\u0983\u09BC\u09BE-\u09C4\u09C7\u09C8\u09CB-\u09CD\u09D7\u09E2\u09E3\u09E6-\u09EF\u09FE\u0A01-\u0A03\u0A3C\u0A3E-\u0A42\u0A47\u0A48\u0A4B-\u0A4D\u0A51\u0A66-\u0A71\u0A75\u0A81-\u0A83\u0ABC\u0ABE-\u0AC5\u0AC7-\u0AC9\u0ACB-\u0ACD\u0AE2\u0AE3\u0AE6-\u0AEF\u0AFA-\u0AFF\u0B01-\u0B03\u0B3C\u0B3E-\u0B44\u0B47\u0B48\u0B4B-\u0B4D\u0B55-\u0B57\u0B62\u0B63\u0B66-\u0B6F\u0B82\u0BBE-\u0BC2\u0BC6-\u0BC8\u0BCA-\u0BCD\u0BD7\u0BE6-\u0BEF\u0C00-\u0C04\u0C3C\u0C3E-\u0C44\u0C46-\u0C48\u0C4A-\u0C4D\u0C55\u0C56\u0C62\u0C63\u0C66-\u0C6F\u0C81-\u0C83\u0CBC\u0CBE-\u0CC4\u0CC6-\u0CC8\u0CCA-\u0CCD\u0CD5\u0CD6\u0CE2\u0CE3\u0CE6-\u0CEF\u0CF3\u0D00-\u0D03\u0D3B\u0D3C\u0D3E-\u0D44\u0D46-\u0D48\u0D4A-\u0D4D\u0D57\u0D62\u0D63\u0D66-\u0D6F\u0D81-\u0D83\u0DCA\u0DCF-\u0DD4\u0DD6\u0DD8-\u0DDF\u0DE6-\u0DEF\u0DF2\u0DF3\u0E31\u0E34-\u0E3A\u0E47-\u0E4E\u0E50-\u0E59\u0EB1\u0EB4-\u0EBC\u0EC8-\u0ECE\u0ED0-\u0ED9\u0F18\u0F19\u0F20-\u0F29\u0F35\u0F37\u0F39\u0F3E\u0F3F\u0F71-\u0F84\u0F86\u0F87\u0F8D-\u0F97\u0F99-\u0FBC\u0FC6\u102B-\u103E\u1040-\u1049\u1056-\u1059\u105E-\u1060\u1062-\u1064\u1067-\u106D\u1071-\u1074\u1082-\u108D\u108F-\u109D\u135D-\u135F\u1369-\u1371\u1712-\u1715\u1732-\u1734\u1752\u1753\u1772\u1773\u17B4-\u17D3\u17DD\u17E0-\u17E9\u180B-\u180D\u180F-\u1819\u18A9\u1920-\u192B\u1930-\u193B\u1946-\u194F\u19D0-\u19DA\u1A17-\u1A1B\u1A55-\u1A5E\u1A60-\u1A7C\u1A7F-\u1A89\u1A90-\u1A99\u1AB0-\u1ABD\u1ABF-\u1ADD\u1AE0-\u1AEB\u1B00-\u1B04\u1B34-\u1B44\u1B50-\u1B59\u1B6B-\u1B73\u1B80-\u1B82\u1BA1-\u1BAD\u1BB0-\u1BB9\u1BE6-\u1BF3\u1C24-\u1C37\u1C40-\u1C49\u1C50-\u1C59\u1CD0-\u1CD2\u1CD4-\u1CE8\u1CED\u1CF4\u1CF7-\u1CF9\u1DC0-\u1DFF\u200C\u200D\u203F\u2040\u2054\u20D0-\u20DC\u20E1\u20E5-\u20F0\u2CEF-\u2CF1\u2D7F\u2DE0-\u2DFF\u302A-\u302F\u3099\u309A\u30FB\uA620-\uA629\uA66F\uA674-\uA67D\uA69E\uA69F\uA6F0\uA6F1\uA802\uA806\uA80B\uA823-\uA827\uA82C\uA880\uA881\uA8B4-\uA8C5\uA8D0-\uA8D9\uA8E0-\uA8F1\uA8FF-\uA909\uA926-\uA92D\uA947-\uA953\uA980-\uA983\uA9B3-\uA9C0\uA9D0-\uA9D9\uA9E5\uA9F0-\uA9F9\uAA29-\uAA36\uAA43\uAA4C\uAA4D\uAA50-\uAA59\uAA7B-\uAA7D\uAAB0\uAAB2-\uAAB4\uAAB7\uAAB8\uAABE\uAABF\uAAC1\uAAEB-\uAAEF\uAAF5\uAAF6\uABE3-\uABEA\uABEC\uABED\uABF0-\uABF9\uFB1E\uFE00-\uFE0F\uFE20-\uFE2F\uFE33\uFE34\uFE4D-\uFE4F\uFF10-\uFF19\uFF3F\uFF65";
var nonASCIIidentifierStartChars = "\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0560-\u0588\u05D0-\u05EA\u05EF-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u0870-\u0887\u0889-\u088F\u08A0-\u08C9\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C5C\u0C5D\u0C60\u0C61\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDC-\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D04-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D5F-\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u1711\u171F-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1878\u1880-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4C\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1C80-\u1C8A\u1C90-\u1CBA\u1CBD-\u1CBF\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5\u1CF6\u1CFA\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2118-\u211D\u2124\u2126\u2128\u212A-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303C\u3041-\u3096\u309B-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u31A0-\u31BF\u31F0-\u31FF\u3400-\u4DBF\u4E00-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6EF\uA717-\uA71F\uA722-\uA788\uA78B-\uA7DC\uA7F1-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA8FD\uA8FE\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uA9E0-\uA9E4\uA9E6-\uA9EF\uA9FA-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB69\uAB70-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC";
var reservedWords = {
  3: "abstract boolean byte char class double enum export extends final float goto implements import int interface long native package private protected public short static super synchronized throws transient volatile",
  5: "class enum extends super const export import",
  6: "enum",
  strict: "implements interface let package private protected public static yield",
  strictBind: "eval arguments"
};
var ecma5AndLessKeywords = "break case catch continue debugger default do else finally for function if return switch throw try var while with null true false instanceof typeof void delete new in this";
var keywords$1 = {
  5: ecma5AndLessKeywords,
  "5module": ecma5AndLessKeywords + " export import",
  6: ecma5AndLessKeywords + " const class extends export import super"
};
var keywordRelationalOperator = /^in(stanceof)?$/;
var nonASCIIidentifierStart = new RegExp("[" + nonASCIIidentifierStartChars + "]");
var nonASCIIidentifier = new RegExp("[" + nonASCIIidentifierStartChars + nonASCIIidentifierChars + "]");
function isInAstralSet(code, set) {
  var pos = 65536;
  for (var i2 = 0; i2 < set.length; i2 += 2) {
    pos += set[i2];
    if (pos > code) {
      return false;
    }
    pos += set[i2 + 1];
    if (pos >= code) {
      return true;
    }
  }
  return false;
}
function isIdentifierStart(code, astral) {
  if (code < 65) {
    return code === 36;
  }
  if (code < 91) {
    return true;
  }
  if (code < 97) {
    return code === 95;
  }
  if (code < 123) {
    return true;
  }
  if (code <= 65535) {
    return code >= 170 && nonASCIIidentifierStart.test(String.fromCharCode(code));
  }
  if (astral === false) {
    return false;
  }
  return isInAstralSet(code, astralIdentifierStartCodes);
}
function isIdentifierChar(code, astral) {
  if (code < 48) {
    return code === 36;
  }
  if (code < 58) {
    return true;
  }
  if (code < 65) {
    return false;
  }
  if (code < 91) {
    return true;
  }
  if (code < 97) {
    return code === 95;
  }
  if (code < 123) {
    return true;
  }
  if (code <= 65535) {
    return code >= 170 && nonASCIIidentifier.test(String.fromCharCode(code));
  }
  if (astral === false) {
    return false;
  }
  return isInAstralSet(code, astralIdentifierStartCodes) || isInAstralSet(code, astralIdentifierCodes);
}
var TokenType = function TokenType2(label, conf) {
  if (conf === void 0) conf = {};
  this.label = label;
  this.keyword = conf.keyword;
  this.beforeExpr = !!conf.beforeExpr;
  this.startsExpr = !!conf.startsExpr;
  this.isLoop = !!conf.isLoop;
  this.isAssign = !!conf.isAssign;
  this.prefix = !!conf.prefix;
  this.postfix = !!conf.postfix;
  this.binop = conf.binop || null;
  this.updateContext = null;
};
function binop(name, prec) {
  return new TokenType(name, { beforeExpr: true, binop: prec });
}
var beforeExpr = { beforeExpr: true };
var startsExpr = { startsExpr: true };
var keywords = {};
function kw(name, options) {
  if (options === void 0) options = {};
  options.keyword = name;
  return keywords[name] = new TokenType(name, options);
}
var types$1 = {
  num: new TokenType("num", startsExpr),
  regexp: new TokenType("regexp", startsExpr),
  string: new TokenType("string", startsExpr),
  name: new TokenType("name", startsExpr),
  privateId: new TokenType("privateId", startsExpr),
  eof: new TokenType("eof"),
  // Punctuation token types.
  bracketL: new TokenType("[", { beforeExpr: true, startsExpr: true }),
  bracketR: new TokenType("]"),
  braceL: new TokenType("{", { beforeExpr: true, startsExpr: true }),
  braceR: new TokenType("}"),
  parenL: new TokenType("(", { beforeExpr: true, startsExpr: true }),
  parenR: new TokenType(")"),
  comma: new TokenType(",", beforeExpr),
  semi: new TokenType(";", beforeExpr),
  colon: new TokenType(":", beforeExpr),
  dot: new TokenType("."),
  question: new TokenType("?", beforeExpr),
  questionDot: new TokenType("?."),
  arrow: new TokenType("=>", beforeExpr),
  template: new TokenType("template"),
  invalidTemplate: new TokenType("invalidTemplate"),
  ellipsis: new TokenType("...", beforeExpr),
  backQuote: new TokenType("`", startsExpr),
  dollarBraceL: new TokenType("${", { beforeExpr: true, startsExpr: true }),
  // Operators. These carry several kinds of properties to help the
  // parser use them properly (the presence of these properties is
  // what categorizes them as operators).
  //
  // `binop`, when present, specifies that this operator is a binary
  // operator, and will refer to its precedence.
  //
  // `prefix` and `postfix` mark the operator as a prefix or postfix
  // unary operator.
  //
  // `isAssign` marks all of `=`, `+=`, `-=` etcetera, which act as
  // binary operators with a very low precedence, that should result
  // in AssignmentExpression nodes.
  eq: new TokenType("=", { beforeExpr: true, isAssign: true }),
  assign: new TokenType("_=", { beforeExpr: true, isAssign: true }),
  incDec: new TokenType("++/--", { prefix: true, postfix: true, startsExpr: true }),
  prefix: new TokenType("!/~", { beforeExpr: true, prefix: true, startsExpr: true }),
  logicalOR: binop("||", 1),
  logicalAND: binop("&&", 2),
  bitwiseOR: binop("|", 3),
  bitwiseXOR: binop("^", 4),
  bitwiseAND: binop("&", 5),
  equality: binop("==/!=/===/!==", 6),
  relational: binop("</>/<=/>=", 7),
  bitShift: binop("<</>>/>>>", 8),
  plusMin: new TokenType("+/-", { beforeExpr: true, binop: 9, prefix: true, startsExpr: true }),
  modulo: binop("%", 10),
  star: binop("*", 10),
  slash: binop("/", 10),
  starstar: new TokenType("**", { beforeExpr: true }),
  coalesce: binop("??", 1),
  // Keyword token types.
  _break: kw("break"),
  _case: kw("case", beforeExpr),
  _catch: kw("catch"),
  _continue: kw("continue"),
  _debugger: kw("debugger"),
  _default: kw("default", beforeExpr),
  _do: kw("do", { isLoop: true, beforeExpr: true }),
  _else: kw("else", beforeExpr),
  _finally: kw("finally"),
  _for: kw("for", { isLoop: true }),
  _function: kw("function", startsExpr),
  _if: kw("if"),
  _return: kw("return", beforeExpr),
  _switch: kw("switch"),
  _throw: kw("throw", beforeExpr),
  _try: kw("try"),
  _var: kw("var"),
  _const: kw("const"),
  _while: kw("while", { isLoop: true }),
  _with: kw("with"),
  _new: kw("new", { beforeExpr: true, startsExpr: true }),
  _this: kw("this", startsExpr),
  _super: kw("super", startsExpr),
  _class: kw("class", startsExpr),
  _extends: kw("extends", beforeExpr),
  _export: kw("export"),
  _import: kw("import", startsExpr),
  _null: kw("null", startsExpr),
  _true: kw("true", startsExpr),
  _false: kw("false", startsExpr),
  _in: kw("in", { beforeExpr: true, binop: 7 }),
  _instanceof: kw("instanceof", { beforeExpr: true, binop: 7 }),
  _typeof: kw("typeof", { beforeExpr: true, prefix: true, startsExpr: true }),
  _void: kw("void", { beforeExpr: true, prefix: true, startsExpr: true }),
  _delete: kw("delete", { beforeExpr: true, prefix: true, startsExpr: true })
};
var lineBreak = /\r\n?|\n|\u2028|\u2029/;
var lineBreakG = new RegExp(lineBreak.source, "g");
function isNewLine(code) {
  return code === 10 || code === 13 || code === 8232 || code === 8233;
}
function nextLineBreak(code, from, end) {
  if (end === void 0) end = code.length;
  for (var i2 = from; i2 < end; i2++) {
    var next = code.charCodeAt(i2);
    if (isNewLine(next)) {
      return i2 < end - 1 && next === 13 && code.charCodeAt(i2 + 1) === 10 ? i2 + 2 : i2 + 1;
    }
  }
  return -1;
}
var nonASCIIwhitespace = /[\u1680\u2000-\u200a\u202f\u205f\u3000\ufeff]/;
var skipWhiteSpace = /(?:\s|\/\/.*|\/\*[^]*?\*\/)*/g;
var ref = Object.prototype;
var hasOwnProperty = ref.hasOwnProperty;
var toString = ref.toString;
var hasOwn = Object.hasOwn || (function(obj, propName) {
  return hasOwnProperty.call(obj, propName);
});
var isArray = Array.isArray || (function(obj) {
  return toString.call(obj) === "[object Array]";
});
var regexpCache = /* @__PURE__ */ Object.create(null);
function wordsRegexp(words) {
  return regexpCache[words] || (regexpCache[words] = new RegExp("^(?:" + words.replace(/ /g, "|") + ")$"));
}
function codePointToString(code) {
  if (code <= 65535) {
    return String.fromCharCode(code);
  }
  code -= 65536;
  return String.fromCharCode((code >> 10) + 55296, (code & 1023) + 56320);
}
var loneSurrogate = /(?:[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF])/;
var Position = function Position2(line, col) {
  this.line = line;
  this.column = col;
};
Position.prototype.offset = function offset(n) {
  return new Position(this.line, this.column + n);
};
var SourceLocation = function SourceLocation2(p, start, end) {
  this.start = start;
  this.end = end;
  if (p.sourceFile !== null) {
    this.source = p.sourceFile;
  }
};
function getLineInfo(input, offset2) {
  for (var line = 1, cur = 0; ; ) {
    var nextBreak = nextLineBreak(input, cur, offset2);
    if (nextBreak < 0) {
      return new Position(line, offset2 - cur);
    }
    ++line;
    cur = nextBreak;
  }
}
var defaultOptions = {
  // `ecmaVersion` indicates the ECMAScript version to parse. Must be
  // either 3, 5, 6 (or 2015), 7 (2016), 8 (2017), 9 (2018), 10
  // (2019), 11 (2020), 12 (2021), 13 (2022), 14 (2023), or `"latest"`
  // (the latest version the library supports). This influences
  // support for strict mode, the set of reserved words, and support
  // for new syntax features.
  ecmaVersion: null,
  // `sourceType` indicates the mode the code should be parsed in.
  // Can be either `"script"`, `"module"` or `"commonjs"`. This influences global
  // strict mode and parsing of `import` and `export` declarations.
  sourceType: "script",
  // When set to true, enable strict parsing mode even if `sourceType`
  // is `"script"`.
  strict: false,
  // `onInsertedSemicolon` can be a callback that will be called when
  // a semicolon is automatically inserted. It will be passed the
  // position of the inserted semicolon as an offset, and if
  // `locations` is enabled, it is given the location as a `{line,
  // column}` object as second argument.
  onInsertedSemicolon: null,
  // `onTrailingComma` is similar to `onInsertedSemicolon`, but for
  // trailing commas.
  onTrailingComma: null,
  // By default, reserved words are only enforced if ecmaVersion >= 5.
  // Set `allowReserved` to a boolean value to explicitly turn this on
  // an off. When this option has the value "never", reserved words
  // and keywords can also not be used as property names.
  allowReserved: null,
  // When enabled, a return at the top level is not considered an
  // error.
  allowReturnOutsideFunction: false,
  // When enabled, import/export statements are not constrained to
  // appearing at the top of the program, and an import.meta expression
  // in a script isn't considered an error.
  allowImportExportEverywhere: false,
  // By default, await identifiers are allowed to appear at the top-level scope only if ecmaVersion >= 2022.
  // When enabled, await identifiers are allowed to appear at the top-level scope,
  // but they are still not allowed in non-async functions.
  allowAwaitOutsideFunction: null,
  // When enabled, super identifiers are not constrained to
  // appearing in methods and do not raise an error when they appear elsewhere.
  allowSuperOutsideMethod: null,
  // When enabled, hashbang directive in the beginning of file is
  // allowed and treated as a line comment. Enabled by default when
  // `ecmaVersion` >= 2023.
  allowHashBang: false,
  // By default, the parser will verify that private properties are
  // only used in places where they are valid and have been declared.
  // Set this to false to turn such checks off.
  checkPrivateFields: true,
  // When `locations` is on, `loc` properties holding objects with
  // `start` and `end` properties in `{line, column}` form (with
  // line being 1-based and column 0-based) will be attached to the
  // nodes.
  locations: false,
  // Pass an optional `{line, column}` object to use for the start of
  // the parse. This is mostly useful when using `parseExpressionAt`
  // with `locations: true`, to prevent the parser from having to
  // determine the line position at the start position.
  startLocation: null,
  // A function can be passed as `onToken` option, which will
  // cause Acorn to call that function with object in the same
  // format as tokens returned from `tokenizer().getToken()`. Note
  // that you are not allowed to call the parser from the
  // callback—that will corrupt its internal state.
  onToken: null,
  // A function can be passed as `onComment` option, which will
  // cause Acorn to call that function with `(block, text, start,
  // end)` parameters whenever a comment is skipped. `block` is a
  // boolean indicating whether this is a block (`/* */`) comment,
  // `text` is the content of the comment, and `start` and `end` are
  // character offsets that denote the start and end of the comment.
  // When the `locations` option is on, two more parameters are
  // passed, the full `{line, column}` locations of the start and
  // end of the comments. Note that you are not allowed to call the
  // parser from the callback—that will corrupt its internal state.
  // When this option has an array as value, objects representing the
  // comments are pushed to it.
  onComment: null,
  // Nodes have their start and end characters offsets recorded in
  // `start` and `end` properties (directly on the node, rather than
  // the `loc` object, which holds line/column data. To also add a
  // [semi-standardized][range] `range` property holding a `[start,
  // end]` array with the same numbers, set the `ranges` option to
  // `true`.
  //
  // [range]: https://bugzilla.mozilla.org/show_bug.cgi?id=745678
  ranges: false,
  // It is possible to parse multiple files into a single AST by
  // passing the tree produced by parsing the first file as
  // `program` option in subsequent parses. This will add the
  // toplevel forms of the parsed file to the `Program` (top) node
  // of an existing parse tree.
  program: null,
  // When `locations` is on, you can pass this to record the source
  // file in every node's `loc` object.
  sourceFile: null,
  // This value, if given, is stored in every node, whether
  // `locations` is on or off.
  directSourceFile: null,
  // When enabled, parenthesized expressions are represented by
  // (non-standard) ParenthesizedExpression nodes
  preserveParens: false
};
var warnedAboutEcmaVersion = false;
function getOptions(opts) {
  var options = {};
  for (var opt in defaultOptions) {
    options[opt] = opts && hasOwn(opts, opt) ? opts[opt] : defaultOptions[opt];
  }
  if (options.ecmaVersion === "latest") {
    options.ecmaVersion = 1e8;
  } else if (options.ecmaVersion == null) {
    if (!warnedAboutEcmaVersion && typeof console === "object" && console.warn) {
      warnedAboutEcmaVersion = true;
      console.warn("Since Acorn 8.0.0, options.ecmaVersion is required.\nDefaulting to 2020, but this will stop working in the future.");
    }
    options.ecmaVersion = 11;
  } else if (options.ecmaVersion >= 2015) {
    options.ecmaVersion -= 2009;
  }
  if (options.allowReserved == null) {
    options.allowReserved = options.ecmaVersion < 5;
  }
  if (!opts || opts.allowHashBang == null) {
    options.allowHashBang = options.ecmaVersion >= 14;
  }
  if (isArray(options.onToken)) {
    var tokens = options.onToken;
    options.onToken = function(token) {
      return tokens.push(token);
    };
  }
  if (isArray(options.onComment)) {
    options.onComment = pushComment(options, options.onComment);
  }
  if (options.sourceType === "commonjs" && options.allowAwaitOutsideFunction) {
    throw new Error("Cannot use allowAwaitOutsideFunction with sourceType: commonjs");
  }
  return options;
}
function pushComment(options, array) {
  return function(block, text2, start, end, startLoc, endLoc) {
    var comment = {
      type: block ? "Block" : "Line",
      value: text2,
      start,
      end
    };
    if (options.locations) {
      comment.loc = new SourceLocation(this, startLoc, endLoc);
    }
    if (options.ranges) {
      comment.range = [start, end];
    }
    array.push(comment);
  };
}
var SCOPE_TOP = 1;
var SCOPE_FUNCTION = 2;
var SCOPE_ASYNC = 4;
var SCOPE_GENERATOR = 8;
var SCOPE_ARROW = 16;
var SCOPE_SIMPLE_CATCH = 32;
var SCOPE_SUPER = 64;
var SCOPE_DIRECT_SUPER = 128;
var SCOPE_CLASS_STATIC_BLOCK = 256;
var SCOPE_CLASS_FIELD_INIT = 512;
var SCOPE_SWITCH = 1024;
var SCOPE_VAR = SCOPE_TOP | SCOPE_FUNCTION | SCOPE_CLASS_STATIC_BLOCK;
function functionFlags(async, generator2) {
  return SCOPE_FUNCTION | (async ? SCOPE_ASYNC : 0) | (generator2 ? SCOPE_GENERATOR : 0);
}
var BIND_NONE = 0;
var BIND_VAR = 1;
var BIND_LEXICAL = 2;
var BIND_FUNCTION = 3;
var BIND_SIMPLE_CATCH = 4;
var BIND_OUTSIDE = 5;
var Parser = function Parser2(options, input, startPos) {
  this.options = options = getOptions(options);
  this.sourceFile = options.sourceFile;
  this.keywords = wordsRegexp(keywords$1[options.ecmaVersion >= 6 ? 6 : options.sourceType === "module" ? "5module" : 5]);
  var reserved = "";
  if (options.allowReserved !== true) {
    reserved = reservedWords[options.ecmaVersion >= 6 ? 6 : options.ecmaVersion === 5 ? 5 : 3];
    if (options.sourceType === "module") {
      reserved += " await";
    }
  }
  this.reservedWords = wordsRegexp(reserved);
  var reservedStrict = (reserved ? reserved + " " : "") + reservedWords.strict;
  this.reservedWordsStrict = wordsRegexp(reservedStrict);
  this.reservedWordsStrictBind = wordsRegexp(reservedStrict + " " + reservedWords.strictBind);
  this.input = String(input);
  this.containsEsc = false;
  this.pos = startPos || 0;
  this.curLine = 1;
  if (options.startLocation) {
    this.lineStart = this.pos - options.startLocation.column;
    this.curLine = options.startLocation.line;
  } else if (startPos) {
    this.lineStart = this.input.lastIndexOf("\n", startPos - 1) + 1;
    if (this.options.locations) {
      this.curLine = this.input.slice(0, this.lineStart).split(lineBreak).length;
    }
  } else {
    this.lineStart = 0;
  }
  this.type = types$1.eof;
  this.value = null;
  this.start = this.end = this.pos;
  this.startLoc = this.endLoc = this.curPosition();
  this.lastTokEndLoc = this.lastTokStartLoc = null;
  this.lastTokStart = this.lastTokEnd = this.pos;
  this.context = this.initialContext();
  this.exprAllowed = true;
  this.inModule = options.sourceType === "module";
  this.strict = this.inModule || options.strict === true || this.strictDirective(this.pos);
  this.potentialArrowAt = -1;
  this.potentialArrowInForAwait = false;
  this.yieldPos = this.awaitPos = this.awaitIdentPos = 0;
  this.labels = [];
  this.undefinedExports = /* @__PURE__ */ Object.create(null);
  if (this.pos === 0 && options.allowHashBang && this.input.slice(0, 2) === "#!") {
    this.skipLineComment(2);
  }
  this.scopeStack = [];
  this.enterScope(
    this.options.sourceType === "commonjs" ? SCOPE_FUNCTION : SCOPE_TOP
  );
  this.regexpState = null;
  this.privateNameStack = [];
};
var prototypeAccessors = { inFunction: { configurable: true }, inGenerator: { configurable: true }, inAsync: { configurable: true }, canAwait: { configurable: true }, allowReturn: { configurable: true }, allowSuper: { configurable: true }, allowDirectSuper: { configurable: true }, treatFunctionsAsVar: { configurable: true }, allowNewDotTarget: { configurable: true }, allowUsing: { configurable: true }, inClassStaticBlock: { configurable: true } };
Parser.prototype.parse = function parse() {
  var this$1$1 = this;
  var node = this.options.program || this.startNode();
  this.nextToken();
  return this.catchStackOverflow(function() {
    return this$1$1.parseTopLevel(node);
  });
};
prototypeAccessors.inFunction.get = function() {
  return (this.currentVarScope().flags & SCOPE_FUNCTION) > 0;
};
prototypeAccessors.inGenerator.get = function() {
  return (this.currentVarScope().flags & SCOPE_GENERATOR) > 0;
};
prototypeAccessors.inAsync.get = function() {
  return (this.currentVarScope().flags & SCOPE_ASYNC) > 0;
};
prototypeAccessors.canAwait.get = function() {
  for (var i2 = this.scopeStack.length - 1; i2 >= 0; i2--) {
    var ref2 = this.scopeStack[i2];
    var flags = ref2.flags;
    if (flags & (SCOPE_CLASS_STATIC_BLOCK | SCOPE_CLASS_FIELD_INIT)) {
      return false;
    }
    if (flags & SCOPE_FUNCTION) {
      return (flags & SCOPE_ASYNC) > 0;
    }
  }
  return this.inModule && this.options.ecmaVersion >= 13 || this.options.allowAwaitOutsideFunction;
};
prototypeAccessors.allowReturn.get = function() {
  if (this.inFunction) {
    return true;
  }
  if (this.options.allowReturnOutsideFunction && this.currentVarScope().flags & SCOPE_TOP) {
    return true;
  }
  return false;
};
prototypeAccessors.allowSuper.get = function() {
  var ref2 = this.currentThisScope();
  var flags = ref2.flags;
  return (flags & SCOPE_SUPER) > 0 || this.options.allowSuperOutsideMethod;
};
prototypeAccessors.allowDirectSuper.get = function() {
  return (this.currentThisScope().flags & SCOPE_DIRECT_SUPER) > 0;
};
prototypeAccessors.treatFunctionsAsVar.get = function() {
  return this.treatFunctionsAsVarInScope(this.currentScope());
};
prototypeAccessors.allowNewDotTarget.get = function() {
  for (var i2 = this.scopeStack.length - 1; i2 >= 0; i2--) {
    var ref2 = this.scopeStack[i2];
    var flags = ref2.flags;
    if (flags & (SCOPE_CLASS_STATIC_BLOCK | SCOPE_CLASS_FIELD_INIT) || flags & SCOPE_FUNCTION && !(flags & SCOPE_ARROW)) {
      return true;
    }
  }
  return false;
};
prototypeAccessors.allowUsing.get = function() {
  var ref2 = this.currentScope();
  var flags = ref2.flags;
  if (flags & SCOPE_SWITCH) {
    return false;
  }
  if (!this.inModule && flags & SCOPE_TOP) {
    return false;
  }
  return true;
};
prototypeAccessors.inClassStaticBlock.get = function() {
  return (this.currentVarScope().flags & SCOPE_CLASS_STATIC_BLOCK) > 0;
};
Parser.extend = function extend() {
  var plugins = [], len = arguments.length;
  while (len--) plugins[len] = arguments[len];
  var cls = this;
  for (var i2 = 0; i2 < plugins.length; i2++) {
    cls = plugins[i2](cls);
  }
  return cls;
};
Parser.parse = function parse2(input, options) {
  return new this(options, input).parse();
};
Parser.parseExpressionAt = function parseExpressionAt(input, pos, options) {
  var parser = new this(options, input, pos);
  parser.nextToken();
  return parser.parseExpression();
};
Parser.tokenizer = function tokenizer(input, options) {
  return new this(options, input);
};
Object.defineProperties(Parser.prototype, prototypeAccessors);
var pp$9 = Parser.prototype;
var literal = /^(?:'((?:\\[^]|[^'\\])*?)'|"((?:\\[^]|[^"\\])*?)")/;
pp$9.strictDirective = function(start) {
  if (this.options.ecmaVersion < 5) {
    return false;
  }
  for (; ; ) {
    skipWhiteSpace.lastIndex = start;
    start += skipWhiteSpace.exec(this.input)[0].length;
    var match = literal.exec(this.input.slice(start));
    if (!match) {
      return false;
    }
    if ((match[1] || match[2]) === "use strict") {
      skipWhiteSpace.lastIndex = start + match[0].length;
      var spaceAfter = skipWhiteSpace.exec(this.input), end = spaceAfter.index + spaceAfter[0].length;
      var next = this.input.charAt(end);
      return next === ";" || next === "}" || lineBreak.test(spaceAfter[0]) && !(/[(`.[+\-/*%<>=,?^&]/.test(next) || next === "!" && this.input.charAt(end + 1) === "=");
    }
    start += match[0].length;
    skipWhiteSpace.lastIndex = start;
    start += skipWhiteSpace.exec(this.input)[0].length;
    if (this.input[start] === ";") {
      start++;
    }
  }
};
pp$9.eat = function(type) {
  if (this.type === type) {
    this.next();
    return true;
  } else {
    return false;
  }
};
pp$9.isContextual = function(name) {
  return this.type === types$1.name && this.value === name && !this.containsEsc;
};
pp$9.eatContextual = function(name) {
  if (!this.isContextual(name)) {
    return false;
  }
  this.next();
  return true;
};
pp$9.catchStackOverflow = function(f) {
  try {
    return f();
  } catch (e) {
    if (e instanceof Error && (/\bstack\b.*\b(exceeded|overflow)\b/i.test(e.message) || /\btoo much recursion\b/i.test(e.message))) {
      this.raise(this.start, "Not enough stack space to parse input");
    } else {
      throw e;
    }
  }
};
pp$9.expectContextual = function(name) {
  if (!this.eatContextual(name)) {
    this.unexpected();
  }
};
pp$9.canInsertSemicolon = function() {
  return this.type === types$1.eof || this.type === types$1.braceR || lineBreak.test(this.input.slice(this.lastTokEnd, this.start));
};
pp$9.insertSemicolon = function() {
  if (this.canInsertSemicolon()) {
    if (this.options.onInsertedSemicolon) {
      this.options.onInsertedSemicolon(this.lastTokEnd, this.lastTokEndLoc);
    }
    return true;
  }
};
pp$9.semicolon = function() {
  if (!this.eat(types$1.semi) && !this.insertSemicolon()) {
    this.unexpected();
  }
};
pp$9.afterTrailingComma = function(tokType, notNext) {
  if (this.type === tokType) {
    if (this.options.onTrailingComma) {
      this.options.onTrailingComma(this.lastTokStart, this.lastTokStartLoc);
    }
    if (!notNext) {
      this.next();
    }
    return true;
  }
};
pp$9.expect = function(type) {
  this.eat(type) || this.unexpected();
};
pp$9.unexpected = function(pos) {
  this.raise(pos != null ? pos : this.start, "Unexpected token");
};
var DestructuringErrors = function DestructuringErrors2() {
  this.shorthandAssign = this.trailingComma = this.parenthesizedAssign = this.parenthesizedBind = this.doubleProto = -1;
};
pp$9.checkPatternErrors = function(refDestructuringErrors, isAssign) {
  if (!refDestructuringErrors) {
    return;
  }
  if (refDestructuringErrors.trailingComma > -1) {
    this.raiseRecoverable(refDestructuringErrors.trailingComma, "Comma is not permitted after the rest element");
  }
  var parens = isAssign ? refDestructuringErrors.parenthesizedAssign : refDestructuringErrors.parenthesizedBind;
  if (parens > -1) {
    this.raiseRecoverable(parens, isAssign ? "Assigning to rvalue" : "Parenthesized pattern");
  }
};
pp$9.checkExpressionErrors = function(refDestructuringErrors, andThrow) {
  if (!refDestructuringErrors) {
    return false;
  }
  var shorthandAssign = refDestructuringErrors.shorthandAssign;
  var doubleProto = refDestructuringErrors.doubleProto;
  if (!andThrow) {
    return shorthandAssign >= 0 || doubleProto >= 0;
  }
  if (shorthandAssign >= 0) {
    this.raise(shorthandAssign, "Shorthand property assignments are valid only in destructuring patterns");
  }
  if (doubleProto >= 0) {
    this.raiseRecoverable(doubleProto, "Redefinition of __proto__ property");
  }
};
pp$9.checkYieldAwaitInDefaultParams = function() {
  if (this.yieldPos && (!this.awaitPos || this.yieldPos < this.awaitPos)) {
    this.raise(this.yieldPos, "Yield expression cannot be a default value");
  }
  if (this.awaitPos) {
    this.raise(this.awaitPos, "Await expression cannot be a default value");
  }
};
pp$9.isSimpleAssignTarget = function(expr) {
  if (expr.type === "ParenthesizedExpression") {
    return this.isSimpleAssignTarget(expr.expression);
  }
  return expr.type === "Identifier" || expr.type === "MemberExpression";
};
var pp$8 = Parser.prototype;
pp$8.parseTopLevel = function(node) {
  var exports$1 = /* @__PURE__ */ Object.create(null);
  if (!node.body) {
    node.body = [];
  }
  while (this.type !== types$1.eof) {
    var stmt = this.parseStatement(null, true, exports$1);
    node.body.push(stmt);
  }
  if (this.inModule) {
    for (var i2 = 0, list2 = Object.keys(this.undefinedExports); i2 < list2.length; i2 += 1) {
      var name = list2[i2];
      this.raiseRecoverable(this.undefinedExports[name].start, "Export '" + name + "' is not defined");
    }
  }
  this.adaptDirectivePrologue(node.body);
  this.next();
  node.sourceType = this.options.sourceType === "commonjs" ? "script" : this.options.sourceType;
  return this.finishNode(node, "Program");
};
var loopLabel = { kind: "loop" };
var switchLabel = { kind: "switch" };
pp$8.isLet = function(context) {
  if (this.options.ecmaVersion < 6 || !this.isContextual("let")) {
    return false;
  }
  skipWhiteSpace.lastIndex = this.pos;
  var skip = skipWhiteSpace.exec(this.input);
  var next = this.pos + skip[0].length, nextCh = this.fullCharCodeAt(next);
  if (nextCh === 91 || nextCh === 92) {
    return true;
  }
  if (context) {
    return false;
  }
  if (nextCh === 123) {
    return true;
  }
  if (isIdentifierStart(nextCh)) {
    var start = next;
    do {
      next += nextCh <= 65535 ? 1 : 2;
    } while (isIdentifierChar(nextCh = this.fullCharCodeAt(next)));
    if (nextCh === 92) {
      return true;
    }
    var ident = this.input.slice(start, next);
    if (!keywordRelationalOperator.test(ident)) {
      return true;
    }
  }
  return false;
};
pp$8.isAsyncFunction = function() {
  if (this.options.ecmaVersion < 8 || !this.isContextual("async")) {
    return false;
  }
  skipWhiteSpace.lastIndex = this.pos;
  var skip = skipWhiteSpace.exec(this.input);
  var next = this.pos + skip[0].length, after;
  return !lineBreak.test(this.input.slice(this.pos, next)) && this.input.slice(next, next + 8) === "function" && (next + 8 === this.input.length || !(isIdentifierChar(after = this.fullCharCodeAt(next + 8)) || after === 92));
};
pp$8.isUsingKeyword = function(isAwaitUsing, isFor) {
  if (this.options.ecmaVersion < 17 || !this.isContextual(isAwaitUsing ? "await" : "using")) {
    return false;
  }
  skipWhiteSpace.lastIndex = this.pos;
  var skip = skipWhiteSpace.exec(this.input);
  var next = this.pos + skip[0].length;
  if (lineBreak.test(this.input.slice(this.pos, next))) {
    return false;
  }
  if (isAwaitUsing) {
    var usingEndPos = next + 5, after;
    if (this.input.slice(next, usingEndPos) !== "using" || usingEndPos === this.input.length || isIdentifierChar(after = this.fullCharCodeAt(usingEndPos)) || after === 92) {
      return false;
    }
    skipWhiteSpace.lastIndex = usingEndPos;
    var skipAfterUsing = skipWhiteSpace.exec(this.input);
    next = usingEndPos + skipAfterUsing[0].length;
    if (skipAfterUsing && lineBreak.test(this.input.slice(usingEndPos, next))) {
      return false;
    }
  }
  var ch = this.fullCharCodeAt(next);
  if (!isIdentifierStart(ch) && ch !== 92) {
    return false;
  }
  var idStart = next;
  do {
    next += ch <= 65535 ? 1 : 2;
  } while (isIdentifierChar(ch = this.fullCharCodeAt(next)));
  if (ch === 92) {
    return true;
  }
  var id = this.input.slice(idStart, next);
  if (keywordRelationalOperator.test(id)) {
    return false;
  }
  if (isFor && !isAwaitUsing && id === "of") {
    skipWhiteSpace.lastIndex = next;
    var skipAfterOf = skipWhiteSpace.exec(this.input);
    next = next + skipAfterOf[0].length;
    if (this.input.charCodeAt(next) !== 61 || // Check for ==, === and => operators
    (ch = this.input.charCodeAt(next + 1)) === 61 || ch === 62) {
      return false;
    }
  }
  return true;
};
pp$8.isAwaitUsing = function(isFor) {
  return this.isUsingKeyword(true, isFor);
};
pp$8.isUsing = function(isFor) {
  return this.isUsingKeyword(false, isFor);
};
pp$8.parseStatement = function(context, topLevel, exports$1) {
  var starttype = this.type, node = this.startNode(), kind;
  if (this.isLet(context)) {
    starttype = types$1._var;
    kind = "let";
  }
  switch (starttype) {
    case types$1._break:
    case types$1._continue:
      return this.parseBreakContinueStatement(node, starttype.keyword);
    case types$1._debugger:
      return this.parseDebuggerStatement(node);
    case types$1._do:
      return this.parseDoStatement(node);
    case types$1._for:
      return this.parseForStatement(node);
    case types$1._function:
      if (context && (this.strict || context !== "if" && context !== "label") && this.options.ecmaVersion >= 6) {
        this.unexpected();
      }
      return this.parseFunctionStatement(node, false, !context);
    case types$1._class:
      if (context) {
        this.unexpected();
      }
      return this.parseClass(node, true);
    case types$1._if:
      return this.parseIfStatement(node);
    case types$1._return:
      return this.parseReturnStatement(node);
    case types$1._switch:
      return this.parseSwitchStatement(node);
    case types$1._throw:
      return this.parseThrowStatement(node);
    case types$1._try:
      return this.parseTryStatement(node);
    case types$1._const:
    case types$1._var:
      kind = kind || this.value;
      if (context && kind !== "var") {
        this.unexpected();
      }
      return this.parseVarStatement(node, kind);
    case types$1._while:
      return this.parseWhileStatement(node);
    case types$1._with:
      return this.parseWithStatement(node);
    case types$1.braceL:
      return this.parseBlock(true, node);
    case types$1.semi:
      return this.parseEmptyStatement(node);
    case types$1._export:
    case types$1._import:
      if (this.options.ecmaVersion > 10 && starttype === types$1._import) {
        skipWhiteSpace.lastIndex = this.pos;
        var skip = skipWhiteSpace.exec(this.input);
        var next = this.pos + skip[0].length, nextCh = this.input.charCodeAt(next);
        if (nextCh === 40 || nextCh === 46) {
          return this.parseExpressionStatement(node, this.parseExpression());
        }
      }
      if (!this.options.allowImportExportEverywhere) {
        if (!topLevel) {
          this.raise(this.start, "'import' and 'export' may only appear at the top level");
        }
        if (!this.inModule) {
          this.raise(this.start, "'import' and 'export' may appear only with 'sourceType: module'");
        }
      }
      return starttype === types$1._import ? this.parseImport(node) : this.parseExport(node, exports$1);
    // If the statement does not start with a statement keyword or a
    // brace, it's an ExpressionStatement or LabeledStatement. We
    // simply start parsing an expression, and afterwards, if the
    // next token is a colon and the expression was a simple
    // Identifier node, we switch to interpreting it as a label.
    default:
      if (this.isAsyncFunction()) {
        if (context) {
          this.unexpected();
        }
        this.next();
        return this.parseFunctionStatement(node, true, !context);
      }
      var usingKind = this.isAwaitUsing(false) ? "await using" : this.isUsing(false) ? "using" : null;
      if (usingKind) {
        if (!this.allowUsing) {
          this.raise(this.start, "Using declaration cannot appear in the top level when source type is `script` or in the bare case statement");
        }
        if (context) {
          this.raise(this.start, "Using declaration is not allowed in single-statement positions");
        }
        if (usingKind === "await using") {
          if (!this.canAwait) {
            this.raise(this.start, "Await using cannot appear outside of async function");
          }
          this.next();
        }
        this.next();
        this.parseVar(node, false, usingKind);
        this.semicolon();
        return this.finishNode(node, "VariableDeclaration");
      }
      var maybeName = this.value, expr = this.parseExpression();
      if (starttype === types$1.name && expr.type === "Identifier" && this.eat(types$1.colon)) {
        return this.parseLabeledStatement(node, maybeName, expr, context);
      } else {
        return this.parseExpressionStatement(node, expr);
      }
  }
};
pp$8.parseBreakContinueStatement = function(node, keyword) {
  var isBreak = keyword === "break";
  this.next();
  if (this.eat(types$1.semi) || this.insertSemicolon()) {
    node.label = null;
  } else if (this.type !== types$1.name) {
    this.unexpected();
  } else {
    node.label = this.parseIdent();
    this.semicolon();
  }
  var i2 = 0;
  for (; i2 < this.labels.length; ++i2) {
    var lab = this.labels[i2];
    if (node.label == null || lab.name === node.label.name) {
      if (lab.kind != null && (isBreak || lab.kind === "loop")) {
        break;
      }
      if (node.label && isBreak) {
        break;
      }
    }
  }
  if (i2 === this.labels.length) {
    this.raise(node.start, "Unsyntactic " + keyword);
  }
  return this.finishNode(node, isBreak ? "BreakStatement" : "ContinueStatement");
};
pp$8.parseDebuggerStatement = function(node) {
  this.next();
  this.semicolon();
  return this.finishNode(node, "DebuggerStatement");
};
pp$8.parseDoStatement = function(node) {
  this.next();
  this.labels.push(loopLabel);
  node.body = this.parseStatement("do");
  this.labels.pop();
  this.expect(types$1._while);
  node.test = this.parseParenExpression();
  if (this.options.ecmaVersion >= 6) {
    this.eat(types$1.semi);
  } else {
    this.semicolon();
  }
  return this.finishNode(node, "DoWhileStatement");
};
pp$8.parseForStatement = function(node) {
  this.next();
  var awaitAt = this.options.ecmaVersion >= 9 && this.canAwait && this.eatContextual("await") ? this.lastTokStart : -1;
  this.labels.push(loopLabel);
  this.enterScope(0);
  this.expect(types$1.parenL);
  if (this.type === types$1.semi) {
    if (awaitAt > -1) {
      this.unexpected(awaitAt);
    }
    return this.parseFor(node, null);
  }
  var isLet = this.isLet();
  if (this.type === types$1._var || this.type === types$1._const || isLet) {
    var init$1 = this.startNode(), kind = isLet ? "let" : this.value;
    this.next();
    this.parseVar(init$1, true, kind);
    this.finishNode(init$1, "VariableDeclaration");
    return this.parseForAfterInit(node, init$1, awaitAt);
  }
  var startsWithLet = this.isContextual("let"), isForOf = false;
  var usingKind = this.isUsing(true) ? "using" : this.isAwaitUsing(true) ? "await using" : null;
  if (usingKind) {
    var init$2 = this.startNode();
    this.next();
    if (usingKind === "await using") {
      if (!this.canAwait) {
        this.raise(this.start, "Await using cannot appear outside of async function");
      }
      this.next();
    }
    this.parseVar(init$2, true, usingKind);
    this.finishNode(init$2, "VariableDeclaration");
    return this.parseForAfterInit(node, init$2, awaitAt);
  }
  var containsEsc = this.containsEsc;
  var refDestructuringErrors = new DestructuringErrors();
  var initPos = this.start;
  var init = awaitAt > -1 ? this.parseExprSubscripts(refDestructuringErrors, "await") : this.parseExpression(true, refDestructuringErrors);
  if (this.type === types$1._in || (isForOf = this.options.ecmaVersion >= 6 && this.isContextual("of"))) {
    if (awaitAt > -1) {
      if (this.type === types$1._in) {
        this.unexpected(awaitAt);
      }
      node.await = true;
    } else if (isForOf && this.options.ecmaVersion >= 8) {
      if (init.start === initPos && !containsEsc && init.type === "Identifier" && init.name === "async") {
        this.unexpected();
      } else if (this.options.ecmaVersion >= 9) {
        node.await = false;
      }
    }
    if (startsWithLet && isForOf) {
      this.raise(init.start, "The left-hand side of a for-of loop may not start with 'let'.");
    }
    this.toAssignable(init, false, refDestructuringErrors);
    this.checkLValPattern(init);
    return this.parseForIn(node, init);
  } else {
    this.checkExpressionErrors(refDestructuringErrors, true);
  }
  if (awaitAt > -1) {
    this.unexpected(awaitAt);
  }
  return this.parseFor(node, init);
};
pp$8.parseForAfterInit = function(node, init, awaitAt) {
  if ((this.type === types$1._in || this.options.ecmaVersion >= 6 && this.isContextual("of")) && init.declarations.length === 1) {
    if (this.type === types$1._in) {
      if ((init.kind === "using" || init.kind === "await using") && !init.declarations[0].init) {
        this.raise(this.start, "Using declaration is not allowed in for-in loops");
      }
      if (this.options.ecmaVersion >= 9 && awaitAt > -1) {
        this.unexpected(awaitAt);
      }
    } else if (this.options.ecmaVersion >= 9) {
      node.await = awaitAt > -1;
    }
    return this.parseForIn(node, init);
  }
  if (awaitAt > -1) {
    this.unexpected(awaitAt);
  }
  return this.parseFor(node, init);
};
pp$8.parseFunctionStatement = function(node, isAsync, declarationPosition) {
  this.next();
  return this.parseFunction(node, FUNC_STATEMENT | (declarationPosition ? 0 : FUNC_HANGING_STATEMENT), false, isAsync);
};
pp$8.parseIfStatement = function(node) {
  this.next();
  node.test = this.parseParenExpression();
  node.consequent = this.parseStatement("if");
  node.alternate = this.eat(types$1._else) ? this.parseStatement("if") : null;
  return this.finishNode(node, "IfStatement");
};
pp$8.parseReturnStatement = function(node) {
  if (!this.allowReturn) {
    this.raise(this.start, "'return' outside of function");
  }
  this.next();
  if (this.eat(types$1.semi) || this.insertSemicolon()) {
    node.argument = null;
  } else {
    node.argument = this.parseExpression();
    this.semicolon();
  }
  return this.finishNode(node, "ReturnStatement");
};
pp$8.parseSwitchStatement = function(node) {
  this.next();
  node.discriminant = this.parseParenExpression();
  node.cases = [];
  this.expect(types$1.braceL);
  this.labels.push(switchLabel);
  this.enterScope(SCOPE_SWITCH);
  var cur;
  for (var sawDefault = false; this.type !== types$1.braceR; ) {
    if (this.type === types$1._case || this.type === types$1._default) {
      var isCase = this.type === types$1._case;
      if (cur) {
        this.finishNode(cur, "SwitchCase");
      }
      node.cases.push(cur = this.startNode());
      cur.consequent = [];
      this.next();
      if (isCase) {
        cur.test = this.parseExpression();
      } else {
        if (sawDefault) {
          this.raiseRecoverable(this.lastTokStart, "Multiple default clauses");
        }
        sawDefault = true;
        cur.test = null;
      }
      this.expect(types$1.colon);
    } else {
      if (!cur) {
        this.unexpected();
      }
      cur.consequent.push(this.parseStatement(null));
    }
  }
  this.exitScope();
  if (cur) {
    this.finishNode(cur, "SwitchCase");
  }
  this.next();
  this.labels.pop();
  return this.finishNode(node, "SwitchStatement");
};
pp$8.parseThrowStatement = function(node) {
  this.next();
  if (lineBreak.test(this.input.slice(this.lastTokEnd, this.start))) {
    this.raise(this.lastTokEnd, "Illegal newline after throw");
  }
  node.argument = this.parseExpression();
  this.semicolon();
  return this.finishNode(node, "ThrowStatement");
};
var empty$1 = [];
pp$8.parseCatchClauseParam = function() {
  var param = this.parseBindingAtom();
  var simple = param.type === "Identifier";
  this.enterScope(simple ? SCOPE_SIMPLE_CATCH : 0);
  this.checkLValPattern(param, simple ? BIND_SIMPLE_CATCH : BIND_LEXICAL);
  this.expect(types$1.parenR);
  return param;
};
pp$8.parseTryStatement = function(node) {
  this.next();
  node.block = this.parseBlock();
  node.handler = null;
  if (this.type === types$1._catch) {
    var clause = this.startNode();
    this.next();
    if (this.eat(types$1.parenL)) {
      clause.param = this.parseCatchClauseParam();
    } else {
      if (this.options.ecmaVersion < 10) {
        this.unexpected();
      }
      clause.param = null;
      this.enterScope(0);
    }
    clause.body = this.parseBlock(false);
    this.exitScope();
    node.handler = this.finishNode(clause, "CatchClause");
  }
  node.finalizer = this.eat(types$1._finally) ? this.parseBlock() : null;
  if (!node.handler && !node.finalizer) {
    this.raise(node.start, "Missing catch or finally clause");
  }
  return this.finishNode(node, "TryStatement");
};
pp$8.parseVarStatement = function(node, kind, allowMissingInitializer) {
  this.next();
  this.parseVar(node, false, kind, allowMissingInitializer);
  this.semicolon();
  return this.finishNode(node, "VariableDeclaration");
};
pp$8.parseWhileStatement = function(node) {
  this.next();
  node.test = this.parseParenExpression();
  this.labels.push(loopLabel);
  node.body = this.parseStatement("while");
  this.labels.pop();
  return this.finishNode(node, "WhileStatement");
};
pp$8.parseWithStatement = function(node) {
  if (this.strict) {
    this.raise(this.start, "'with' in strict mode");
  }
  this.next();
  node.object = this.parseParenExpression();
  node.body = this.parseStatement("with");
  return this.finishNode(node, "WithStatement");
};
pp$8.parseEmptyStatement = function(node) {
  this.next();
  return this.finishNode(node, "EmptyStatement");
};
pp$8.parseLabeledStatement = function(node, maybeName, expr, context) {
  for (var i$1 = 0, list2 = this.labels; i$1 < list2.length; i$1 += 1) {
    var label = list2[i$1];
    if (label.name === maybeName) {
      this.raise(expr.start, "Label '" + maybeName + "' is already declared");
    }
  }
  var kind = this.type.isLoop ? "loop" : this.type === types$1._switch ? "switch" : null;
  for (var i2 = this.labels.length - 1; i2 >= 0; i2--) {
    var label$1 = this.labels[i2];
    if (label$1.statementStart === node.start) {
      label$1.statementStart = this.start;
      label$1.kind = kind;
    } else {
      break;
    }
  }
  this.labels.push({ name: maybeName, kind, statementStart: this.start });
  node.body = this.parseStatement(context ? context.indexOf("label") === -1 ? context + "label" : context : "label");
  this.labels.pop();
  node.label = expr;
  return this.finishNode(node, "LabeledStatement");
};
pp$8.parseExpressionStatement = function(node, expr) {
  node.expression = expr;
  this.semicolon();
  return this.finishNode(node, "ExpressionStatement");
};
pp$8.parseBlock = function(createNewLexicalScope, node, exitStrict) {
  if (createNewLexicalScope === void 0) createNewLexicalScope = true;
  if (node === void 0) node = this.startNode();
  node.body = [];
  this.expect(types$1.braceL);
  if (createNewLexicalScope) {
    this.enterScope(0);
  }
  while (this.type !== types$1.braceR) {
    var stmt = this.parseStatement(null);
    node.body.push(stmt);
  }
  if (exitStrict) {
    this.strict = false;
  }
  this.next();
  if (createNewLexicalScope) {
    this.exitScope();
  }
  return this.finishNode(node, "BlockStatement");
};
pp$8.parseFor = function(node, init) {
  node.init = init;
  this.expect(types$1.semi);
  node.test = this.type === types$1.semi ? null : this.parseExpression();
  this.expect(types$1.semi);
  node.update = this.type === types$1.parenR ? null : this.parseExpression();
  this.expect(types$1.parenR);
  node.body = this.parseStatement("for");
  this.exitScope();
  this.labels.pop();
  return this.finishNode(node, "ForStatement");
};
pp$8.parseForIn = function(node, init) {
  var isForIn = this.type === types$1._in;
  this.next();
  if (init.type === "VariableDeclaration" && init.declarations[0].init != null && (!isForIn || this.options.ecmaVersion < 8 || this.strict || init.kind !== "var" || init.declarations[0].id.type !== "Identifier")) {
    this.raise(
      init.start,
      (isForIn ? "for-in" : "for-of") + " loop variable declaration may not have an initializer"
    );
  }
  node.left = init;
  node.right = isForIn ? this.parseExpression() : this.parseMaybeAssign();
  this.expect(types$1.parenR);
  node.body = this.parseStatement("for");
  this.exitScope();
  this.labels.pop();
  return this.finishNode(node, isForIn ? "ForInStatement" : "ForOfStatement");
};
pp$8.parseVar = function(node, isFor, kind, allowMissingInitializer) {
  node.declarations = [];
  node.kind = kind;
  for (; ; ) {
    var decl = this.startNode();
    this.parseVarId(decl, kind);
    if (this.eat(types$1.eq)) {
      decl.init = this.parseMaybeAssign(isFor);
    } else if (!allowMissingInitializer && kind === "const" && !(this.type === types$1._in || this.options.ecmaVersion >= 6 && this.isContextual("of"))) {
      this.unexpected();
    } else if (!allowMissingInitializer && (kind === "using" || kind === "await using") && this.options.ecmaVersion >= 17 && this.type !== types$1._in && !this.isContextual("of")) {
      this.raise(this.lastTokEnd, "Missing initializer in " + kind + " declaration");
    } else if (!allowMissingInitializer && decl.id.type !== "Identifier" && !(isFor && (this.type === types$1._in || this.isContextual("of")))) {
      this.raise(this.lastTokEnd, "Complex binding patterns require an initialization value");
    } else {
      decl.init = null;
    }
    node.declarations.push(this.finishNode(decl, "VariableDeclarator"));
    if (!this.eat(types$1.comma)) {
      break;
    }
  }
  return node;
};
pp$8.parseVarId = function(decl, kind) {
  decl.id = kind === "using" || kind === "await using" ? this.parseIdent() : this.parseBindingAtom();
  this.checkLValPattern(decl.id, kind === "var" ? BIND_VAR : BIND_LEXICAL, false);
};
var FUNC_STATEMENT = 1;
var FUNC_HANGING_STATEMENT = 2;
var FUNC_NULLABLE_ID = 4;
pp$8.parseFunction = function(node, statement, allowExpressionBody, isAsync, forInit) {
  this.initFunction(node);
  if (this.options.ecmaVersion >= 9 || this.options.ecmaVersion >= 6 && !isAsync) {
    if (this.type === types$1.star && statement & FUNC_HANGING_STATEMENT) {
      this.unexpected();
    }
    node.generator = this.eat(types$1.star);
  }
  if (this.options.ecmaVersion >= 8) {
    node.async = !!isAsync;
  }
  if (statement & FUNC_STATEMENT) {
    node.id = statement & FUNC_NULLABLE_ID && this.type !== types$1.name ? null : this.parseIdent();
    if (node.id && !(statement & FUNC_HANGING_STATEMENT)) {
      this.checkLValSimple(node.id, this.strict || node.generator || node.async ? this.treatFunctionsAsVar ? BIND_VAR : BIND_LEXICAL : BIND_FUNCTION);
    }
  }
  var oldYieldPos = this.yieldPos, oldAwaitPos = this.awaitPos, oldAwaitIdentPos = this.awaitIdentPos;
  this.yieldPos = 0;
  this.awaitPos = 0;
  this.awaitIdentPos = 0;
  this.enterScope(functionFlags(node.async, node.generator));
  if (!(statement & FUNC_STATEMENT)) {
    node.id = this.type === types$1.name ? this.parseIdent() : null;
  }
  this.parseFunctionParams(node);
  this.parseFunctionBody(node, allowExpressionBody, false, forInit);
  this.yieldPos = oldYieldPos;
  this.awaitPos = oldAwaitPos;
  this.awaitIdentPos = oldAwaitIdentPos;
  return this.finishNode(node, statement & FUNC_STATEMENT ? "FunctionDeclaration" : "FunctionExpression");
};
pp$8.parseFunctionParams = function(node) {
  this.expect(types$1.parenL);
  node.params = this.parseBindingList(types$1.parenR, false, this.options.ecmaVersion >= 8);
  this.checkYieldAwaitInDefaultParams();
};
pp$8.parseClass = function(node, isStatement) {
  this.next();
  var oldStrict = this.strict;
  this.strict = true;
  this.parseClassId(node, isStatement);
  this.parseClassSuper(node);
  var privateNameMap = this.enterClassBody();
  var classBody = this.startNode();
  var hadConstructor = false;
  classBody.body = [];
  this.expect(types$1.braceL);
  while (this.type !== types$1.braceR) {
    var element = this.parseClassElement(node.superClass !== null);
    if (element) {
      classBody.body.push(element);
      if (element.type === "MethodDefinition" && element.kind === "constructor") {
        if (hadConstructor) {
          this.raiseRecoverable(element.start, "Duplicate constructor in the same class");
        }
        hadConstructor = true;
      } else if (element.key && element.key.type === "PrivateIdentifier" && isPrivateNameConflicted(privateNameMap, element)) {
        this.raiseRecoverable(element.key.start, "Identifier '#" + element.key.name + "' has already been declared");
      }
    }
  }
  this.strict = oldStrict;
  this.next();
  node.body = this.finishNode(classBody, "ClassBody");
  this.exitClassBody();
  return this.finishNode(node, isStatement ? "ClassDeclaration" : "ClassExpression");
};
pp$8.parseClassElement = function(constructorAllowsSuper) {
  if (this.eat(types$1.semi)) {
    return null;
  }
  var ecmaVersion2 = this.options.ecmaVersion;
  var node = this.startNode();
  var keyName = "";
  var isGenerator = false;
  var isAsync = false;
  var kind = "method";
  var isStatic = false;
  if (this.eatContextual("static")) {
    if (ecmaVersion2 >= 13 && this.eat(types$1.braceL)) {
      this.parseClassStaticBlock(node);
      return node;
    }
    if (this.isClassElementNameStart() || this.type === types$1.star) {
      isStatic = true;
    } else {
      keyName = "static";
    }
  }
  node.static = isStatic;
  if (!keyName && ecmaVersion2 >= 8 && this.eatContextual("async")) {
    if ((this.isClassElementNameStart() || this.type === types$1.star) && !this.canInsertSemicolon()) {
      isAsync = true;
    } else {
      keyName = "async";
    }
  }
  if (!keyName && (ecmaVersion2 >= 9 || !isAsync) && this.eat(types$1.star)) {
    isGenerator = true;
  }
  if (!keyName && !isAsync && !isGenerator) {
    var lastValue = this.value;
    if (this.eatContextual("get") || this.eatContextual("set")) {
      if (this.isClassElementNameStart()) {
        kind = lastValue;
      } else {
        keyName = lastValue;
      }
    }
  }
  if (keyName) {
    node.computed = false;
    node.key = this.startNodeAt(this.lastTokStart, this.lastTokStartLoc);
    node.key.name = keyName;
    this.finishNode(node.key, "Identifier");
  } else {
    this.parseClassElementName(node);
  }
  if (ecmaVersion2 < 13 || this.type === types$1.parenL || kind !== "method" || isGenerator || isAsync) {
    var isConstructor = !node.static && checkKeyName(node, "constructor");
    var allowsDirectSuper = isConstructor && constructorAllowsSuper;
    if (isConstructor && kind !== "method") {
      this.raise(node.key.start, "Constructor can't have get/set modifier");
    }
    node.kind = isConstructor ? "constructor" : kind;
    this.parseClassMethod(node, isGenerator, isAsync, allowsDirectSuper);
  } else {
    this.parseClassField(node);
  }
  return node;
};
pp$8.isClassElementNameStart = function() {
  return this.type === types$1.name || this.type === types$1.privateId || this.type === types$1.num || this.type === types$1.string || this.type === types$1.bracketL || this.type.keyword;
};
pp$8.parseClassElementName = function(element) {
  if (this.type === types$1.privateId) {
    if (this.value === "constructor") {
      this.raise(this.start, "Classes can't have an element named '#constructor'");
    }
    element.computed = false;
    element.key = this.parsePrivateIdent();
  } else {
    this.parsePropertyName(element);
  }
};
pp$8.parseClassMethod = function(method, isGenerator, isAsync, allowsDirectSuper) {
  var key2 = method.key;
  if (method.kind === "constructor") {
    if (isGenerator) {
      this.raise(key2.start, "Constructor can't be a generator");
    }
    if (isAsync) {
      this.raise(key2.start, "Constructor can't be an async method");
    }
  } else if (method.static && checkKeyName(method, "prototype")) {
    this.raise(key2.start, "Classes may not have a static property named prototype");
  }
  var value = method.value = this.parseMethod(isGenerator, isAsync, allowsDirectSuper);
  if (method.kind === "get" && value.params.length !== 0) {
    this.raiseRecoverable(value.start, "getter should have no params");
  }
  if (method.kind === "set" && value.params.length !== 1) {
    this.raiseRecoverable(value.start, "setter should have exactly one param");
  }
  if (method.kind === "set" && value.params[0].type === "RestElement") {
    this.raiseRecoverable(value.params[0].start, "Setter cannot use rest params");
  }
  return this.finishNode(method, "MethodDefinition");
};
pp$8.parseClassField = function(field) {
  if (checkKeyName(field, "constructor")) {
    this.raise(field.key.start, "Classes can't have a field named 'constructor'");
  } else if (field.static && checkKeyName(field, "prototype")) {
    this.raise(field.key.start, "Classes can't have a static field named 'prototype'");
  }
  if (this.eat(types$1.eq)) {
    this.enterScope(SCOPE_CLASS_FIELD_INIT | SCOPE_SUPER);
    field.value = this.parseMaybeAssign();
    this.exitScope();
  } else {
    field.value = null;
  }
  this.semicolon();
  return this.finishNode(field, "PropertyDefinition");
};
pp$8.parseClassStaticBlock = function(node) {
  node.body = [];
  var oldLabels = this.labels;
  this.labels = [];
  this.enterScope(SCOPE_CLASS_STATIC_BLOCK | SCOPE_SUPER);
  while (this.type !== types$1.braceR) {
    var stmt = this.parseStatement(null);
    node.body.push(stmt);
  }
  this.next();
  this.exitScope();
  this.labels = oldLabels;
  return this.finishNode(node, "StaticBlock");
};
pp$8.parseClassId = function(node, isStatement) {
  if (this.type === types$1.name) {
    node.id = this.parseIdent();
    if (isStatement) {
      this.checkLValSimple(node.id, BIND_LEXICAL, false);
    }
  } else {
    if (isStatement === true) {
      this.unexpected();
    }
    node.id = null;
  }
};
pp$8.parseClassSuper = function(node) {
  node.superClass = this.eat(types$1._extends) ? this.parseExprSubscripts(null, false) : null;
};
pp$8.enterClassBody = function() {
  var element = { declared: /* @__PURE__ */ Object.create(null), used: [] };
  this.privateNameStack.push(element);
  return element.declared;
};
pp$8.exitClassBody = function() {
  var ref2 = this.privateNameStack.pop();
  var declared = ref2.declared;
  var used = ref2.used;
  if (!this.options.checkPrivateFields) {
    return;
  }
  var len = this.privateNameStack.length;
  var parent = len === 0 ? null : this.privateNameStack[len - 1];
  for (var i2 = 0; i2 < used.length; ++i2) {
    var id = used[i2];
    if (!hasOwn(declared, id.name)) {
      if (parent) {
        parent.used.push(id);
      } else {
        this.raiseRecoverable(id.start, "Private field '#" + id.name + "' must be declared in an enclosing class");
      }
    }
  }
};
function isPrivateNameConflicted(privateNameMap, element) {
  var name = element.key.name;
  var curr = privateNameMap[name];
  var next = "true";
  if (element.type === "MethodDefinition" && (element.kind === "get" || element.kind === "set")) {
    next = (element.static ? "s" : "i") + element.kind;
  }
  if (curr === "iget" && next === "iset" || curr === "iset" && next === "iget" || curr === "sget" && next === "sset" || curr === "sset" && next === "sget") {
    privateNameMap[name] = "true";
    return false;
  } else if (!curr) {
    privateNameMap[name] = next;
    return false;
  } else {
    return true;
  }
}
function checkKeyName(node, name) {
  var computed = node.computed;
  var key2 = node.key;
  return !computed && (key2.type === "Identifier" && key2.name === name || key2.type === "Literal" && key2.value === name);
}
pp$8.parseExportAllDeclaration = function(node, exports$1) {
  if (this.options.ecmaVersion >= 11) {
    if (this.eatContextual("as")) {
      node.exported = this.parseModuleExportName();
      this.checkExport(exports$1, node.exported, this.lastTokStart);
    } else {
      node.exported = null;
    }
  }
  this.expectContextual("from");
  if (this.type !== types$1.string) {
    this.unexpected();
  }
  node.source = this.parseExprAtom();
  if (this.options.ecmaVersion >= 16) {
    node.attributes = this.parseWithClause();
  }
  this.semicolon();
  return this.finishNode(node, "ExportAllDeclaration");
};
pp$8.parseExport = function(node, exports$1) {
  this.next();
  if (this.eat(types$1.star)) {
    return this.parseExportAllDeclaration(node, exports$1);
  }
  if (this.eat(types$1._default)) {
    this.checkExport(exports$1, "default", this.lastTokStart);
    node.declaration = this.parseExportDefaultDeclaration();
    return this.finishNode(node, "ExportDefaultDeclaration");
  }
  if (this.shouldParseExportStatement()) {
    node.declaration = this.parseExportDeclaration(node);
    if (node.declaration.type === "VariableDeclaration") {
      this.checkVariableExport(exports$1, node.declaration.declarations);
    } else {
      this.checkExport(exports$1, node.declaration.id, node.declaration.id.start);
    }
    node.specifiers = [];
    node.source = null;
    if (this.options.ecmaVersion >= 16) {
      node.attributes = [];
    }
  } else {
    node.declaration = null;
    node.specifiers = this.parseExportSpecifiers(exports$1);
    if (this.eatContextual("from")) {
      if (this.type !== types$1.string) {
        this.unexpected();
      }
      node.source = this.parseExprAtom();
      if (this.options.ecmaVersion >= 16) {
        node.attributes = this.parseWithClause();
      }
    } else {
      for (var i2 = 0, list2 = node.specifiers; i2 < list2.length; i2 += 1) {
        var spec = list2[i2];
        this.checkUnreserved(spec.local);
        this.checkLocalExport(spec.local);
        if (spec.local.type === "Literal") {
          this.raise(spec.local.start, "A string literal cannot be used as an exported binding without `from`.");
        }
      }
      node.source = null;
      if (this.options.ecmaVersion >= 16) {
        node.attributes = [];
      }
    }
    this.semicolon();
  }
  return this.finishNode(node, "ExportNamedDeclaration");
};
pp$8.parseExportDeclaration = function(node) {
  return this.parseStatement(null);
};
pp$8.parseExportDefaultDeclaration = function() {
  var isAsync;
  if (this.type === types$1._function || (isAsync = this.isAsyncFunction())) {
    var fNode = this.startNode();
    this.next();
    if (isAsync) {
      this.next();
    }
    return this.parseFunction(fNode, FUNC_STATEMENT | FUNC_NULLABLE_ID, false, isAsync);
  } else if (this.type === types$1._class) {
    var cNode = this.startNode();
    return this.parseClass(cNode, "nullableID");
  } else {
    var declaration = this.parseMaybeAssign();
    this.semicolon();
    return declaration;
  }
};
pp$8.checkExport = function(exports$1, name, pos) {
  if (!exports$1) {
    return;
  }
  if (typeof name !== "string") {
    name = name.type === "Identifier" ? name.name : name.value;
  }
  if (hasOwn(exports$1, name)) {
    this.raiseRecoverable(pos, "Duplicate export '" + name + "'");
  }
  exports$1[name] = true;
};
pp$8.checkPatternExport = function(exports$1, pat) {
  var type = pat.type;
  if (type === "Identifier") {
    this.checkExport(exports$1, pat, pat.start);
  } else if (type === "ObjectPattern") {
    for (var i2 = 0, list2 = pat.properties; i2 < list2.length; i2 += 1) {
      var prop = list2[i2];
      this.checkPatternExport(exports$1, prop);
    }
  } else if (type === "ArrayPattern") {
    for (var i$1 = 0, list$1 = pat.elements; i$1 < list$1.length; i$1 += 1) {
      var elt = list$1[i$1];
      if (elt) {
        this.checkPatternExport(exports$1, elt);
      }
    }
  } else if (type === "Property") {
    this.checkPatternExport(exports$1, pat.value);
  } else if (type === "AssignmentPattern") {
    this.checkPatternExport(exports$1, pat.left);
  } else if (type === "RestElement") {
    this.checkPatternExport(exports$1, pat.argument);
  }
};
pp$8.checkVariableExport = function(exports$1, decls) {
  if (!exports$1) {
    return;
  }
  for (var i2 = 0, list2 = decls; i2 < list2.length; i2 += 1) {
    var decl = list2[i2];
    this.checkPatternExport(exports$1, decl.id);
  }
};
pp$8.shouldParseExportStatement = function() {
  return this.type.keyword === "var" || this.type.keyword === "const" || this.type.keyword === "class" || this.type.keyword === "function" || this.isLet() || this.isAsyncFunction();
};
pp$8.parseExportSpecifier = function(exports$1) {
  var node = this.startNode();
  node.local = this.parseModuleExportName();
  node.exported = this.eatContextual("as") ? this.parseModuleExportName() : node.local;
  this.checkExport(
    exports$1,
    node.exported,
    node.exported.start
  );
  return this.finishNode(node, "ExportSpecifier");
};
pp$8.parseExportSpecifiers = function(exports$1) {
  var nodes = [], first = true;
  this.expect(types$1.braceL);
  while (!this.eat(types$1.braceR)) {
    if (!first) {
      this.expect(types$1.comma);
      if (this.afterTrailingComma(types$1.braceR)) {
        break;
      }
    } else {
      first = false;
    }
    nodes.push(this.parseExportSpecifier(exports$1));
  }
  return nodes;
};
pp$8.parseImport = function(node) {
  this.next();
  if (this.type === types$1.string) {
    node.specifiers = empty$1;
    node.source = this.parseExprAtom();
  } else {
    node.specifiers = this.parseImportSpecifiers();
    this.expectContextual("from");
    node.source = this.type === types$1.string ? this.parseExprAtom() : this.unexpected();
  }
  if (this.options.ecmaVersion >= 16) {
    node.attributes = this.parseWithClause();
  }
  this.semicolon();
  return this.finishNode(node, "ImportDeclaration");
};
pp$8.parseImportSpecifier = function() {
  var node = this.startNode();
  node.imported = this.parseModuleExportName();
  if (this.eatContextual("as")) {
    node.local = this.parseIdent();
  } else {
    this.checkUnreserved(node.imported);
    node.local = node.imported;
  }
  this.checkLValSimple(node.local, BIND_LEXICAL);
  return this.finishNode(node, "ImportSpecifier");
};
pp$8.parseImportDefaultSpecifier = function() {
  var node = this.startNode();
  node.local = this.parseIdent();
  this.checkLValSimple(node.local, BIND_LEXICAL);
  return this.finishNode(node, "ImportDefaultSpecifier");
};
pp$8.parseImportNamespaceSpecifier = function() {
  var node = this.startNode();
  this.next();
  this.expectContextual("as");
  node.local = this.parseIdent();
  this.checkLValSimple(node.local, BIND_LEXICAL);
  return this.finishNode(node, "ImportNamespaceSpecifier");
};
pp$8.parseImportSpecifiers = function() {
  var nodes = [], first = true;
  if (this.type === types$1.name) {
    nodes.push(this.parseImportDefaultSpecifier());
    if (!this.eat(types$1.comma)) {
      return nodes;
    }
  }
  if (this.type === types$1.star) {
    nodes.push(this.parseImportNamespaceSpecifier());
    return nodes;
  }
  this.expect(types$1.braceL);
  while (!this.eat(types$1.braceR)) {
    if (!first) {
      this.expect(types$1.comma);
      if (this.afterTrailingComma(types$1.braceR)) {
        break;
      }
    } else {
      first = false;
    }
    nodes.push(this.parseImportSpecifier());
  }
  return nodes;
};
pp$8.parseWithClause = function() {
  var nodes = [];
  if (!this.eat(types$1._with)) {
    return nodes;
  }
  this.expect(types$1.braceL);
  var attributeKeys = {};
  var first = true;
  while (!this.eat(types$1.braceR)) {
    if (!first) {
      this.expect(types$1.comma);
      if (this.afterTrailingComma(types$1.braceR)) {
        break;
      }
    } else {
      first = false;
    }
    var attr = this.parseImportAttribute();
    var keyName = attr.key.type === "Identifier" ? attr.key.name : attr.key.value;
    if (hasOwn(attributeKeys, keyName)) {
      this.raiseRecoverable(attr.key.start, "Duplicate attribute key '" + keyName + "'");
    }
    attributeKeys[keyName] = true;
    nodes.push(attr);
  }
  return nodes;
};
pp$8.parseImportAttribute = function() {
  var node = this.startNode();
  node.key = this.type === types$1.string ? this.parseExprAtom() : this.parseIdent(this.options.allowReserved !== "never");
  this.expect(types$1.colon);
  if (this.type !== types$1.string) {
    this.unexpected();
  }
  node.value = this.parseExprAtom();
  return this.finishNode(node, "ImportAttribute");
};
pp$8.parseModuleExportName = function() {
  if (this.options.ecmaVersion >= 13 && this.type === types$1.string) {
    var stringLiteral = this.parseLiteral(this.value);
    if (loneSurrogate.test(stringLiteral.value)) {
      this.raise(stringLiteral.start, "An export name cannot include a lone surrogate.");
    }
    return stringLiteral;
  }
  return this.parseIdent(true);
};
pp$8.adaptDirectivePrologue = function(statements) {
  for (var i2 = 0; i2 < statements.length && this.isDirectiveCandidate(statements[i2]); ++i2) {
    statements[i2].directive = statements[i2].expression.raw.slice(1, -1);
  }
};
pp$8.isDirectiveCandidate = function(statement) {
  return this.options.ecmaVersion >= 5 && statement.type === "ExpressionStatement" && statement.expression.type === "Literal" && typeof statement.expression.value === "string" && // Reject parenthesized strings.
  (this.input[statement.start] === '"' || this.input[statement.start] === "'");
};
var pp$7 = Parser.prototype;
pp$7.toAssignable = function(node, isBinding, refDestructuringErrors) {
  if (this.options.ecmaVersion >= 6 && node) {
    switch (node.type) {
      case "Identifier":
        if (this.inAsync && node.name === "await") {
          this.raise(node.start, "Cannot use 'await' as identifier inside an async function");
        }
        break;
      case "ObjectPattern":
      case "ArrayPattern":
      case "AssignmentPattern":
      case "RestElement":
        break;
      case "ObjectExpression":
        node.type = "ObjectPattern";
        if (refDestructuringErrors) {
          this.checkPatternErrors(refDestructuringErrors, true);
        }
        for (var i2 = 0, list2 = node.properties; i2 < list2.length; i2 += 1) {
          var prop = list2[i2];
          this.toAssignable(prop, isBinding);
          if (prop.type === "RestElement" && (prop.argument.type === "ArrayPattern" || prop.argument.type === "ObjectPattern")) {
            this.raise(prop.argument.start, "Unexpected token");
          }
        }
        break;
      case "Property":
        if (node.kind !== "init") {
          this.raise(node.key.start, "Object pattern can't contain getter or setter");
        }
        this.toAssignable(node.value, isBinding);
        break;
      case "ArrayExpression":
        node.type = "ArrayPattern";
        if (refDestructuringErrors) {
          this.checkPatternErrors(refDestructuringErrors, true);
        }
        this.toAssignableList(node.elements, isBinding);
        break;
      case "SpreadElement":
        node.type = "RestElement";
        this.toAssignable(node.argument, isBinding);
        if (node.argument.type === "AssignmentPattern") {
          this.raise(node.argument.start, "Rest elements cannot have a default value");
        }
        break;
      case "AssignmentExpression":
        if (node.operator !== "=") {
          this.raise(node.left.end, "Only '=' operator can be used for specifying default value.");
        }
        node.type = "AssignmentPattern";
        delete node.operator;
        this.toAssignable(node.left, isBinding);
        break;
      case "ParenthesizedExpression":
        this.toAssignable(node.expression, isBinding, refDestructuringErrors);
        break;
      case "ChainExpression":
        this.raiseRecoverable(node.start, "Optional chaining cannot appear in left-hand side");
        break;
      case "MemberExpression":
        if (!isBinding) {
          break;
        }
      default:
        this.raise(node.start, "Assigning to rvalue");
    }
  } else if (refDestructuringErrors) {
    this.checkPatternErrors(refDestructuringErrors, true);
  }
  return node;
};
pp$7.toAssignableList = function(exprList, isBinding) {
  var end = exprList.length;
  for (var i2 = 0; i2 < end; i2++) {
    var elt = exprList[i2];
    if (elt) {
      this.toAssignable(elt, isBinding);
    }
  }
  if (end) {
    var last = exprList[end - 1];
    if (this.options.ecmaVersion === 6 && isBinding && last && last.type === "RestElement" && last.argument.type !== "Identifier") {
      this.unexpected(last.argument.start);
    }
  }
  return exprList;
};
pp$7.parseSpread = function(refDestructuringErrors) {
  var node = this.startNode();
  this.next();
  node.argument = this.parseMaybeAssign(false, refDestructuringErrors);
  return this.finishNode(node, "SpreadElement");
};
pp$7.parseRestBinding = function() {
  var node = this.startNode();
  this.next();
  if (this.options.ecmaVersion === 6 && this.type !== types$1.name) {
    this.unexpected();
  }
  node.argument = this.parseBindingAtom();
  return this.finishNode(node, "RestElement");
};
pp$7.parseBindingAtom = function() {
  if (this.options.ecmaVersion >= 6) {
    switch (this.type) {
      case types$1.bracketL:
        var node = this.startNode();
        this.next();
        node.elements = this.parseBindingList(types$1.bracketR, true, true);
        return this.finishNode(node, "ArrayPattern");
      case types$1.braceL:
        return this.parseObj(true);
    }
  }
  return this.parseIdent();
};
pp$7.parseBindingList = function(close, allowEmpty, allowTrailingComma, allowModifiers) {
  var elts = [], first = true;
  while (!this.eat(close)) {
    if (first) {
      first = false;
    } else {
      this.expect(types$1.comma);
    }
    if (allowEmpty && this.type === types$1.comma) {
      elts.push(null);
    } else if (allowTrailingComma && this.afterTrailingComma(close)) {
      break;
    } else if (this.type === types$1.ellipsis) {
      var rest = this.parseRestBinding();
      this.parseBindingListItem(rest);
      elts.push(rest);
      if (this.type === types$1.comma) {
        this.raiseRecoverable(this.start, "Comma is not permitted after the rest element");
      }
      this.expect(close);
      break;
    } else {
      elts.push(this.parseAssignableListItem(allowModifiers));
    }
  }
  return elts;
};
pp$7.parseAssignableListItem = function(allowModifiers) {
  var elem = this.parseMaybeDefault(this.start, this.startLoc);
  this.parseBindingListItem(elem);
  return elem;
};
pp$7.parseBindingListItem = function(param) {
  return param;
};
pp$7.parseMaybeDefault = function(startPos, startLoc, left) {
  left = left || this.parseBindingAtom();
  if (this.options.ecmaVersion < 6 || !this.eat(types$1.eq)) {
    return left;
  }
  var node = this.startNodeAt(startPos, startLoc);
  node.left = left;
  node.right = this.parseMaybeAssign();
  return this.finishNode(node, "AssignmentPattern");
};
pp$7.checkLValSimple = function(expr, bindingType, checkClashes) {
  if (bindingType === void 0) bindingType = BIND_NONE;
  var isBind = bindingType !== BIND_NONE;
  switch (expr.type) {
    case "Identifier":
      if (this.strict && this.reservedWordsStrictBind.test(expr.name)) {
        this.raiseRecoverable(expr.start, (isBind ? "Binding " : "Assigning to ") + expr.name + " in strict mode");
      }
      if (isBind) {
        if (bindingType === BIND_LEXICAL && expr.name === "let") {
          this.raiseRecoverable(expr.start, "let is disallowed as a lexically bound name");
        }
        if (checkClashes) {
          if (hasOwn(checkClashes, expr.name)) {
            this.raiseRecoverable(expr.start, "Argument name clash");
          }
          checkClashes[expr.name] = true;
        }
        if (bindingType !== BIND_OUTSIDE) {
          this.declareName(expr.name, bindingType, expr.start);
        }
      }
      break;
    case "ChainExpression":
      this.raiseRecoverable(expr.start, "Optional chaining cannot appear in left-hand side");
      break;
    case "MemberExpression":
      if (isBind) {
        this.raiseRecoverable(expr.start, "Binding member expression");
      }
      break;
    case "ParenthesizedExpression":
      if (isBind) {
        this.raiseRecoverable(expr.start, "Binding parenthesized expression");
      }
      return this.checkLValSimple(expr.expression, bindingType, checkClashes);
    default:
      this.raise(expr.start, (isBind ? "Binding" : "Assigning to") + " rvalue");
  }
};
pp$7.checkLValPattern = function(expr, bindingType, checkClashes) {
  if (bindingType === void 0) bindingType = BIND_NONE;
  switch (expr.type) {
    case "ObjectPattern":
      for (var i2 = 0, list2 = expr.properties; i2 < list2.length; i2 += 1) {
        var prop = list2[i2];
        this.checkLValInnerPattern(prop, bindingType, checkClashes);
      }
      break;
    case "ArrayPattern":
      for (var i$1 = 0, list$1 = expr.elements; i$1 < list$1.length; i$1 += 1) {
        var elem = list$1[i$1];
        if (elem) {
          this.checkLValInnerPattern(elem, bindingType, checkClashes);
        }
      }
      break;
    default:
      this.checkLValSimple(expr, bindingType, checkClashes);
  }
};
pp$7.checkLValInnerPattern = function(expr, bindingType, checkClashes) {
  if (bindingType === void 0) bindingType = BIND_NONE;
  switch (expr.type) {
    case "Property":
      this.checkLValInnerPattern(expr.value, bindingType, checkClashes);
      break;
    case "AssignmentPattern":
      this.checkLValPattern(expr.left, bindingType, checkClashes);
      break;
    case "RestElement":
      this.checkLValPattern(expr.argument, bindingType, checkClashes);
      break;
    default:
      this.checkLValPattern(expr, bindingType, checkClashes);
  }
};
var TokContext = function TokContext2(token, isExpr, preserveSpace, override, generator2) {
  this.token = token;
  this.isExpr = !!isExpr;
  this.preserveSpace = !!preserveSpace;
  this.override = override;
  this.generator = !!generator2;
};
var types = {
  b_stat: new TokContext("{", false),
  b_expr: new TokContext("{", true),
  b_tmpl: new TokContext("${", false),
  p_stat: new TokContext("(", false),
  p_expr: new TokContext("(", true),
  q_tmpl: new TokContext("`", true, true, function(p) {
    return p.tryReadTemplateToken();
  }),
  f_stat: new TokContext("function", false),
  f_expr: new TokContext("function", true),
  f_expr_gen: new TokContext("function", true, false, null, true),
  f_gen: new TokContext("function", false, false, null, true)
};
var pp$6 = Parser.prototype;
pp$6.initialContext = function() {
  return [types.b_stat];
};
pp$6.curContext = function() {
  return this.context[this.context.length - 1];
};
pp$6.braceIsBlock = function(prevType) {
  var parent = this.curContext();
  if (parent === types.f_expr || parent === types.f_stat) {
    return true;
  }
  if (prevType === types$1.colon && (parent === types.b_stat || parent === types.b_expr)) {
    return !parent.isExpr;
  }
  if (prevType === types$1._return || prevType === types$1.name && this.exprAllowed) {
    return lineBreak.test(this.input.slice(this.lastTokEnd, this.start));
  }
  if (prevType === types$1._else || prevType === types$1.semi || prevType === types$1.eof || prevType === types$1.parenR || prevType === types$1.arrow) {
    return true;
  }
  if (prevType === types$1.braceL) {
    return parent === types.b_stat;
  }
  if (prevType === types$1._var || prevType === types$1._const || prevType === types$1.name) {
    return false;
  }
  return !this.exprAllowed;
};
pp$6.inGeneratorContext = function() {
  for (var i2 = this.context.length - 1; i2 >= 1; i2--) {
    var context = this.context[i2];
    if (context.token === "function") {
      return context.generator;
    }
  }
  return false;
};
pp$6.updateContext = function(prevType) {
  var update, type = this.type;
  if (type.keyword && prevType === types$1.dot) {
    this.exprAllowed = false;
  } else if (update = type.updateContext) {
    update.call(this, prevType);
  } else {
    this.exprAllowed = type.beforeExpr;
  }
};
pp$6.overrideContext = function(tokenCtx) {
  if (this.curContext() !== tokenCtx) {
    this.context[this.context.length - 1] = tokenCtx;
  }
};
types$1.parenR.updateContext = types$1.braceR.updateContext = function() {
  if (this.context.length === 1) {
    this.exprAllowed = true;
    return;
  }
  var out = this.context.pop();
  if (out === types.b_stat && this.curContext().token === "function") {
    out = this.context.pop();
  }
  this.exprAllowed = !out.isExpr;
};
types$1.braceL.updateContext = function(prevType) {
  this.context.push(this.braceIsBlock(prevType) ? types.b_stat : types.b_expr);
  this.exprAllowed = true;
};
types$1.dollarBraceL.updateContext = function() {
  this.context.push(types.b_tmpl);
  this.exprAllowed = true;
};
types$1.parenL.updateContext = function(prevType) {
  var statementParens = prevType === types$1._if || prevType === types$1._for || prevType === types$1._with || prevType === types$1._while;
  this.context.push(statementParens ? types.p_stat : types.p_expr);
  this.exprAllowed = true;
};
types$1.incDec.updateContext = function() {
};
types$1._function.updateContext = types$1._class.updateContext = function(prevType) {
  if (prevType.beforeExpr && prevType !== types$1._else && !(prevType === types$1.semi && this.curContext() !== types.p_stat) && !(prevType === types$1._return && lineBreak.test(this.input.slice(this.lastTokEnd, this.start))) && !((prevType === types$1.colon || prevType === types$1.braceL) && this.curContext() === types.b_stat)) {
    this.context.push(types.f_expr);
  } else {
    this.context.push(types.f_stat);
  }
  this.exprAllowed = false;
};
types$1.colon.updateContext = function() {
  if (this.curContext().token === "function") {
    this.context.pop();
  }
  this.exprAllowed = true;
};
types$1.backQuote.updateContext = function() {
  if (this.curContext() === types.q_tmpl) {
    this.context.pop();
  } else {
    this.context.push(types.q_tmpl);
  }
  this.exprAllowed = false;
};
types$1.star.updateContext = function(prevType) {
  if (prevType === types$1._function) {
    var index = this.context.length - 1;
    if (this.context[index] === types.f_expr) {
      this.context[index] = types.f_expr_gen;
    } else {
      this.context[index] = types.f_gen;
    }
  }
  this.exprAllowed = true;
};
types$1.name.updateContext = function(prevType) {
  var allowed = false;
  if (this.options.ecmaVersion >= 6 && prevType !== types$1.dot) {
    if (this.value === "of" && !this.exprAllowed || this.value === "yield" && this.inGeneratorContext()) {
      allowed = true;
    }
  }
  this.exprAllowed = allowed;
};
var pp$5 = Parser.prototype;
pp$5.checkPropClash = function(prop, propHash, refDestructuringErrors) {
  if (this.options.ecmaVersion >= 9 && prop.type === "SpreadElement") {
    return;
  }
  if (this.options.ecmaVersion >= 6 && (prop.computed || prop.method || prop.shorthand)) {
    return;
  }
  var key2 = prop.key;
  var name;
  switch (key2.type) {
    case "Identifier":
      name = key2.name;
      break;
    case "Literal":
      name = String(key2.value);
      break;
    default:
      return;
  }
  var kind = prop.kind;
  if (this.options.ecmaVersion >= 6) {
    if (name === "__proto__" && kind === "init") {
      if (propHash.proto) {
        if (refDestructuringErrors) {
          if (refDestructuringErrors.doubleProto < 0) {
            refDestructuringErrors.doubleProto = key2.start;
          }
        } else {
          this.raiseRecoverable(key2.start, "Redefinition of __proto__ property");
        }
      }
      propHash.proto = true;
    }
    return;
  }
  name = "$" + name;
  var other = propHash[name];
  if (other) {
    var redefinition;
    if (kind === "init") {
      redefinition = this.strict && other.init || other.get || other.set;
    } else {
      redefinition = other.init || other[kind];
    }
    if (redefinition) {
      this.raiseRecoverable(key2.start, "Redefinition of property");
    }
  } else {
    other = propHash[name] = {
      init: false,
      get: false,
      set: false
    };
  }
  other[kind] = true;
};
pp$5.parseExpression = function(forInit, refDestructuringErrors) {
  var this$1$1 = this;
  return this.catchStackOverflow(function() {
    var startPos = this$1$1.start, startLoc = this$1$1.startLoc;
    var expr = this$1$1.parseMaybeAssign(forInit, refDestructuringErrors);
    if (this$1$1.type === types$1.comma) {
      var node = this$1$1.startNodeAt(startPos, startLoc);
      node.expressions = [expr];
      while (this$1$1.eat(types$1.comma)) {
        node.expressions.push(this$1$1.parseMaybeAssign(forInit, refDestructuringErrors));
      }
      return this$1$1.finishNode(node, "SequenceExpression");
    }
    return expr;
  });
};
pp$5.parseMaybeAssign = function(forInit, refDestructuringErrors, afterLeftParse) {
  if (this.isContextual("yield")) {
    if (this.inGenerator) {
      return this.parseYield(forInit);
    } else {
      this.exprAllowed = false;
    }
  }
  var ownDestructuringErrors = false, oldParenAssign = -1, oldTrailingComma = -1, oldDoubleProto = -1;
  if (refDestructuringErrors) {
    oldParenAssign = refDestructuringErrors.parenthesizedAssign;
    oldTrailingComma = refDestructuringErrors.trailingComma;
    oldDoubleProto = refDestructuringErrors.doubleProto;
    refDestructuringErrors.parenthesizedAssign = refDestructuringErrors.trailingComma = -1;
  } else {
    refDestructuringErrors = new DestructuringErrors();
    ownDestructuringErrors = true;
  }
  var startPos = this.start, startLoc = this.startLoc;
  if (this.type === types$1.parenL || this.type === types$1.name) {
    this.potentialArrowAt = this.start;
    this.potentialArrowInForAwait = forInit === "await";
  }
  var left = this.parseMaybeConditional(forInit, refDestructuringErrors);
  if (afterLeftParse) {
    left = afterLeftParse.call(this, left, startPos, startLoc);
  }
  if (this.type.isAssign) {
    var node = this.startNodeAt(startPos, startLoc);
    node.operator = this.value;
    if (this.type === types$1.eq) {
      left = this.toAssignable(left, false, refDestructuringErrors);
    }
    if (!ownDestructuringErrors) {
      refDestructuringErrors.parenthesizedAssign = refDestructuringErrors.trailingComma = refDestructuringErrors.doubleProto = -1;
    }
    if (refDestructuringErrors.shorthandAssign >= left.start) {
      refDestructuringErrors.shorthandAssign = -1;
    }
    if (this.type === types$1.eq) {
      this.checkLValPattern(left);
    } else {
      this.checkLValSimple(left);
    }
    node.left = left;
    this.next();
    node.right = this.parseMaybeAssign(forInit);
    if (oldDoubleProto > -1) {
      refDestructuringErrors.doubleProto = oldDoubleProto;
    }
    return this.finishNode(node, "AssignmentExpression");
  } else {
    if (ownDestructuringErrors) {
      this.checkExpressionErrors(refDestructuringErrors, true);
    }
  }
  if (oldParenAssign > -1) {
    refDestructuringErrors.parenthesizedAssign = oldParenAssign;
  }
  if (oldTrailingComma > -1) {
    refDestructuringErrors.trailingComma = oldTrailingComma;
  }
  return left;
};
pp$5.parseMaybeConditional = function(forInit, refDestructuringErrors) {
  var startPos = this.start, startLoc = this.startLoc;
  var expr = this.parseExprOps(forInit, refDestructuringErrors);
  if (this.checkExpressionErrors(refDestructuringErrors)) {
    return expr;
  }
  if (!(expr.type === "ArrowFunctionExpression" && expr.start === startPos) && this.eat(types$1.question)) {
    var node = this.startNodeAt(startPos, startLoc);
    node.test = expr;
    node.consequent = this.parseMaybeAssign();
    this.expect(types$1.colon);
    node.alternate = this.parseMaybeAssign(forInit);
    return this.finishNode(node, "ConditionalExpression");
  }
  return expr;
};
pp$5.parseExprOps = function(forInit, refDestructuringErrors) {
  var startPos = this.start, startLoc = this.startLoc;
  var expr = this.parseMaybeUnary(refDestructuringErrors, false, false, forInit);
  if (this.checkExpressionErrors(refDestructuringErrors)) {
    return expr;
  }
  return expr.start === startPos && expr.type === "ArrowFunctionExpression" ? expr : this.parseExprOp(expr, startPos, startLoc, -1, forInit);
};
pp$5.parseExprOp = function(left, leftStartPos, leftStartLoc, minPrec, forInit) {
  var prec = this.type.binop;
  if (prec != null && (!forInit || this.type !== types$1._in)) {
    if (prec > minPrec) {
      var logical = this.type === types$1.logicalOR || this.type === types$1.logicalAND;
      var coalesce = this.type === types$1.coalesce;
      if (coalesce) {
        prec = types$1.logicalAND.binop;
      }
      var op = this.value;
      this.next();
      var startPos = this.start, startLoc = this.startLoc;
      var right = this.parseExprOp(this.parseMaybeUnary(null, false, false, forInit), startPos, startLoc, prec, forInit);
      var node = this.buildBinary(leftStartPos, leftStartLoc, left, right, op, logical || coalesce);
      if (logical && this.type === types$1.coalesce || coalesce && (this.type === types$1.logicalOR || this.type === types$1.logicalAND)) {
        this.raiseRecoverable(this.start, "Logical expressions and coalesce expressions cannot be mixed. Wrap either by parentheses");
      }
      return this.parseExprOp(node, leftStartPos, leftStartLoc, minPrec, forInit);
    }
  }
  return left;
};
pp$5.buildBinary = function(startPos, startLoc, left, right, op, logical) {
  if (right.type === "PrivateIdentifier") {
    this.raise(right.start, "Private identifier can only be left side of binary expression");
  }
  var node = this.startNodeAt(startPos, startLoc);
  node.left = left;
  node.operator = op;
  node.right = right;
  return this.finishNode(node, logical ? "LogicalExpression" : "BinaryExpression");
};
pp$5.parseMaybeUnary = function(refDestructuringErrors, sawUnary, incDec, forInit) {
  var startPos = this.start, startLoc = this.startLoc, expr;
  if (this.isContextual("await") && this.canAwait) {
    expr = this.parseAwait(forInit);
    sawUnary = true;
  } else if (this.type.prefix) {
    var node = this.startNode(), update = this.type === types$1.incDec;
    node.operator = this.value;
    node.prefix = true;
    this.next();
    node.argument = this.parseMaybeUnary(null, true, update, forInit);
    this.checkExpressionErrors(refDestructuringErrors, true);
    if (update) {
      this.checkLValSimple(node.argument);
    } else if (this.strict && node.operator === "delete" && isLocalVariableAccess(node.argument)) {
      this.raiseRecoverable(node.start, "Deleting local variable in strict mode");
    } else if (node.operator === "delete" && isPrivateFieldAccess(node.argument)) {
      this.raiseRecoverable(node.start, "Private fields can not be deleted");
    } else {
      sawUnary = true;
    }
    expr = this.finishNode(node, update ? "UpdateExpression" : "UnaryExpression");
  } else if (!sawUnary && this.type === types$1.privateId) {
    if ((forInit || this.privateNameStack.length === 0) && this.options.checkPrivateFields) {
      this.unexpected();
    }
    expr = this.parsePrivateIdent();
    if (this.type !== types$1._in) {
      this.unexpected();
    }
  } else {
    expr = this.parseExprSubscripts(refDestructuringErrors, forInit);
    if (this.checkExpressionErrors(refDestructuringErrors)) {
      return expr;
    }
    while (this.type.postfix && !this.canInsertSemicolon()) {
      var node$1 = this.startNodeAt(startPos, startLoc);
      node$1.operator = this.value;
      node$1.prefix = false;
      node$1.argument = expr;
      this.checkLValSimple(expr);
      this.next();
      expr = this.finishNode(node$1, "UpdateExpression");
    }
  }
  if (!incDec && !(expr.type === "ArrowFunctionExpression" && expr.start === startPos) && this.eat(types$1.starstar)) {
    if (sawUnary) {
      this.unexpected(this.lastTokStart);
    } else {
      return this.buildBinary(startPos, startLoc, expr, this.parseMaybeUnary(null, false, false, forInit), "**", false);
    }
  } else {
    return expr;
  }
};
function isLocalVariableAccess(node) {
  return node.type === "Identifier" || node.type === "ParenthesizedExpression" && isLocalVariableAccess(node.expression);
}
function isPrivateFieldAccess(node) {
  return node.type === "MemberExpression" && node.property.type === "PrivateIdentifier" || node.type === "ChainExpression" && isPrivateFieldAccess(node.expression) || node.type === "ParenthesizedExpression" && isPrivateFieldAccess(node.expression);
}
pp$5.parseExprSubscripts = function(refDestructuringErrors, forInit) {
  var startPos = this.start, startLoc = this.startLoc;
  var expr = this.parseExprAtom(refDestructuringErrors, forInit);
  if (expr.type === "ArrowFunctionExpression" && this.input.slice(this.lastTokStart, this.lastTokEnd) !== ")") {
    return expr;
  }
  var result = this.parseSubscripts(expr, startPos, startLoc, false, forInit);
  if (refDestructuringErrors && result.type === "MemberExpression") {
    if (refDestructuringErrors.parenthesizedAssign >= result.start) {
      refDestructuringErrors.parenthesizedAssign = -1;
    }
    if (refDestructuringErrors.parenthesizedBind >= result.start) {
      refDestructuringErrors.parenthesizedBind = -1;
    }
    if (refDestructuringErrors.trailingComma >= result.start) {
      refDestructuringErrors.trailingComma = -1;
    }
  }
  return result;
};
pp$5.parseSubscripts = function(base5, startPos, startLoc, noCalls, forInit) {
  var maybeAsyncArrow = this.options.ecmaVersion >= 8 && base5.type === "Identifier" && base5.name === "async" && this.lastTokEnd === base5.end && !this.canInsertSemicolon() && base5.end - base5.start === 5 && this.potentialArrowAt === base5.start;
  var optionalChained = false;
  while (true) {
    var element = this.parseSubscript(base5, startPos, startLoc, noCalls, maybeAsyncArrow, optionalChained, forInit);
    if (element.optional) {
      optionalChained = true;
    }
    if (element === base5 || element.type === "ArrowFunctionExpression") {
      if (optionalChained) {
        var chainNode = this.startNodeAt(startPos, startLoc);
        chainNode.expression = element;
        element = this.finishNode(chainNode, "ChainExpression");
      }
      return element;
    }
    base5 = element;
  }
};
pp$5.shouldParseAsyncArrow = function() {
  return !this.canInsertSemicolon() && this.eat(types$1.arrow);
};
pp$5.parseSubscriptAsyncArrow = function(startPos, startLoc, exprList, forInit) {
  return this.parseArrowExpression(this.startNodeAt(startPos, startLoc), exprList, true, forInit);
};
pp$5.parseSubscript = function(base5, startPos, startLoc, noCalls, maybeAsyncArrow, optionalChained, forInit) {
  var optionalSupported = this.options.ecmaVersion >= 11;
  var optional = optionalSupported && this.eat(types$1.questionDot);
  if (noCalls && optional) {
    this.raise(this.lastTokStart, "Optional chaining cannot appear in the callee of new expressions");
  }
  var computed = this.eat(types$1.bracketL);
  if (computed || optional && this.type !== types$1.parenL && this.type !== types$1.backQuote || this.eat(types$1.dot)) {
    var node = this.startNodeAt(startPos, startLoc);
    node.object = base5;
    if (computed) {
      node.property = this.parseExpression();
      this.expect(types$1.bracketR);
    } else if (this.type === types$1.privateId && base5.type !== "Super") {
      node.property = this.parsePrivateIdent();
    } else {
      node.property = this.parseIdent(this.options.allowReserved !== "never");
    }
    node.computed = !!computed;
    if (optionalSupported) {
      node.optional = optional;
    }
    base5 = this.finishNode(node, "MemberExpression");
  } else if (!noCalls && this.eat(types$1.parenL)) {
    var refDestructuringErrors = new DestructuringErrors(), oldYieldPos = this.yieldPos, oldAwaitPos = this.awaitPos, oldAwaitIdentPos = this.awaitIdentPos;
    this.yieldPos = 0;
    this.awaitPos = 0;
    this.awaitIdentPos = 0;
    var exprList = this.parseExprList(types$1.parenR, this.options.ecmaVersion >= 8, false, refDestructuringErrors);
    if (maybeAsyncArrow && !optional && this.shouldParseAsyncArrow()) {
      this.checkPatternErrors(refDestructuringErrors, false);
      this.checkYieldAwaitInDefaultParams();
      if (this.awaitIdentPos > 0) {
        this.raise(this.awaitIdentPos, "Cannot use 'await' as identifier inside an async function");
      }
      this.yieldPos = oldYieldPos;
      this.awaitPos = oldAwaitPos;
      this.awaitIdentPos = oldAwaitIdentPos;
      return this.parseSubscriptAsyncArrow(startPos, startLoc, exprList, forInit);
    }
    this.checkExpressionErrors(refDestructuringErrors, true);
    this.yieldPos = oldYieldPos || this.yieldPos;
    this.awaitPos = oldAwaitPos || this.awaitPos;
    this.awaitIdentPos = oldAwaitIdentPos || this.awaitIdentPos;
    var node$1 = this.startNodeAt(startPos, startLoc);
    node$1.callee = base5;
    node$1.arguments = exprList;
    if (optionalSupported) {
      node$1.optional = optional;
    }
    base5 = this.finishNode(node$1, "CallExpression");
  } else if (this.type === types$1.backQuote) {
    if (optional || optionalChained) {
      this.raise(this.start, "Optional chaining cannot appear in the tag of tagged template expressions");
    }
    var node$2 = this.startNodeAt(startPos, startLoc);
    node$2.tag = base5;
    node$2.quasi = this.parseTemplate({ isTagged: true });
    base5 = this.finishNode(node$2, "TaggedTemplateExpression");
  }
  return base5;
};
pp$5.parseExprAtom = function(refDestructuringErrors, forInit, forNew) {
  if (this.type === types$1.slash) {
    this.readRegexp();
  }
  var node, canBeArrow = this.potentialArrowAt === this.start;
  switch (this.type) {
    case types$1._super:
      if (!this.allowSuper) {
        this.raise(this.start, "'super' keyword outside a method");
      }
      node = this.startNode();
      this.next();
      if (this.type === types$1.parenL && !this.allowDirectSuper) {
        this.raise(node.start, "super() call outside constructor of a subclass");
      }
      if (this.type !== types$1.dot && this.type !== types$1.bracketL && this.type !== types$1.parenL) {
        this.unexpected();
      }
      return this.finishNode(node, "Super");
    case types$1._this:
      node = this.startNode();
      this.next();
      return this.finishNode(node, "ThisExpression");
    case types$1.name:
      var startPos = this.start, startLoc = this.startLoc, containsEsc = this.containsEsc;
      var id = this.parseIdent(false);
      if (this.options.ecmaVersion >= 8 && !containsEsc && id.name === "async" && !this.canInsertSemicolon() && this.eat(types$1._function)) {
        this.overrideContext(types.f_expr);
        return this.parseFunction(this.startNodeAt(startPos, startLoc), 0, false, true, forInit);
      }
      if (canBeArrow && !this.canInsertSemicolon()) {
        if (this.eat(types$1.arrow)) {
          return this.parseArrowExpression(this.startNodeAt(startPos, startLoc), [id], false, forInit);
        }
        if (this.options.ecmaVersion >= 8 && id.name === "async" && this.type === types$1.name && !containsEsc && (!this.potentialArrowInForAwait || this.value !== "of" || this.containsEsc)) {
          id = this.parseIdent(false);
          if (this.canInsertSemicolon() || !this.eat(types$1.arrow)) {
            this.unexpected();
          }
          return this.parseArrowExpression(this.startNodeAt(startPos, startLoc), [id], true, forInit);
        }
      }
      return id;
    case types$1.regexp:
      var value = this.value;
      node = this.parseLiteral(value.value);
      node.regex = { pattern: value.pattern, flags: value.flags };
      return node;
    case types$1.num:
    case types$1.string:
      return this.parseLiteral(this.value);
    case types$1._null:
    case types$1._true:
    case types$1._false:
      node = this.startNode();
      node.value = this.type === types$1._null ? null : this.type === types$1._true;
      node.raw = this.type.keyword;
      this.next();
      return this.finishNode(node, "Literal");
    case types$1.parenL:
      var start = this.start, expr = this.parseParenAndDistinguishExpression(canBeArrow, forInit);
      if (refDestructuringErrors) {
        if (refDestructuringErrors.parenthesizedAssign < 0 && !this.isSimpleAssignTarget(expr)) {
          refDestructuringErrors.parenthesizedAssign = start;
        }
        if (refDestructuringErrors.parenthesizedBind < 0) {
          refDestructuringErrors.parenthesizedBind = start;
        }
      }
      return expr;
    case types$1.bracketL:
      node = this.startNode();
      this.next();
      node.elements = this.parseExprList(types$1.bracketR, true, true, refDestructuringErrors);
      return this.finishNode(node, "ArrayExpression");
    case types$1.braceL:
      this.overrideContext(types.b_expr);
      return this.parseObj(false, refDestructuringErrors);
    case types$1._function:
      node = this.startNode();
      this.next();
      return this.parseFunction(node, 0);
    case types$1._class:
      return this.parseClass(this.startNode(), false);
    case types$1._new:
      return this.parseNew();
    case types$1.backQuote:
      return this.parseTemplate();
    case types$1._import:
      if (this.options.ecmaVersion >= 11) {
        return this.parseExprImport(forNew);
      } else {
        return this.unexpected();
      }
    default:
      return this.parseExprAtomDefault();
  }
};
pp$5.parseExprAtomDefault = function() {
  this.unexpected();
};
pp$5.parseExprImport = function(forNew) {
  var node = this.startNode();
  if (this.containsEsc) {
    this.raiseRecoverable(this.start, "Escape sequence in keyword import");
  }
  this.next();
  if (this.type === types$1.parenL && !forNew) {
    return this.parseDynamicImport(node);
  } else if (this.type === types$1.dot) {
    var meta = this.startNodeAt(node.start, node.loc && node.loc.start);
    meta.name = "import";
    node.meta = this.finishNode(meta, "Identifier");
    return this.parseImportMeta(node);
  } else {
    this.unexpected();
  }
};
pp$5.parseDynamicImport = function(node) {
  this.next();
  node.source = this.parseMaybeAssign();
  if (this.options.ecmaVersion >= 16) {
    if (!this.eat(types$1.parenR)) {
      this.expect(types$1.comma);
      if (!this.afterTrailingComma(types$1.parenR)) {
        node.options = this.parseMaybeAssign();
        if (!this.eat(types$1.parenR)) {
          this.expect(types$1.comma);
          if (!this.afterTrailingComma(types$1.parenR)) {
            this.unexpected();
          }
        }
      } else {
        node.options = null;
      }
    } else {
      node.options = null;
    }
  } else {
    if (!this.eat(types$1.parenR)) {
      var errorPos = this.start;
      if (this.eat(types$1.comma) && this.eat(types$1.parenR)) {
        this.raiseRecoverable(errorPos, "Trailing comma is not allowed in import()");
      } else {
        this.unexpected(errorPos);
      }
    }
  }
  return this.finishNode(node, "ImportExpression");
};
pp$5.parseImportMeta = function(node) {
  this.next();
  var containsEsc = this.containsEsc;
  node.property = this.parseIdent(true);
  if (node.property.name !== "meta") {
    this.raiseRecoverable(node.property.start, "The only valid meta property for import is 'import.meta'");
  }
  if (containsEsc) {
    this.raiseRecoverable(node.start, "'import.meta' must not contain escaped characters");
  }
  if (this.options.sourceType !== "module" && !this.options.allowImportExportEverywhere) {
    this.raiseRecoverable(node.start, "Cannot use 'import.meta' outside a module");
  }
  return this.finishNode(node, "MetaProperty");
};
pp$5.parseLiteral = function(value) {
  var node = this.startNode();
  node.value = value;
  node.raw = this.input.slice(this.start, this.end);
  if (node.raw.charCodeAt(node.raw.length - 1) === 110) {
    node.bigint = node.value != null ? node.value.toString() : node.raw.slice(0, -1).replace(/_/g, "");
  }
  this.next();
  return this.finishNode(node, "Literal");
};
pp$5.parseParenExpression = function() {
  this.expect(types$1.parenL);
  var val = this.parseExpression();
  this.expect(types$1.parenR);
  return val;
};
pp$5.shouldParseArrow = function(exprList) {
  return !this.canInsertSemicolon();
};
pp$5.parseParenAndDistinguishExpression = function(canBeArrow, forInit) {
  var startPos = this.start, startLoc = this.startLoc, val, allowTrailingComma = this.options.ecmaVersion >= 8;
  if (this.options.ecmaVersion >= 6) {
    this.next();
    var innerStartPos = this.start, innerStartLoc = this.startLoc;
    var exprList = [], first = true, lastIsComma = false;
    var refDestructuringErrors = new DestructuringErrors(), oldYieldPos = this.yieldPos, oldAwaitPos = this.awaitPos, spreadStart;
    this.yieldPos = 0;
    this.awaitPos = 0;
    while (this.type !== types$1.parenR) {
      first ? first = false : this.expect(types$1.comma);
      if (allowTrailingComma && this.afterTrailingComma(types$1.parenR, true)) {
        lastIsComma = true;
        break;
      } else if (this.type === types$1.ellipsis) {
        spreadStart = this.start;
        exprList.push(this.parseParenItem(this.parseRestBinding()));
        if (this.type === types$1.comma) {
          this.raiseRecoverable(
            this.start,
            "Comma is not permitted after the rest element"
          );
        }
        break;
      } else {
        exprList.push(this.parseMaybeAssign(false, refDestructuringErrors, this.parseParenItem));
      }
    }
    var innerEndPos = this.lastTokEnd, innerEndLoc = this.lastTokEndLoc;
    this.expect(types$1.parenR);
    if (canBeArrow && this.shouldParseArrow(exprList) && this.eat(types$1.arrow)) {
      this.checkPatternErrors(refDestructuringErrors, false);
      this.checkYieldAwaitInDefaultParams();
      this.yieldPos = oldYieldPos;
      this.awaitPos = oldAwaitPos;
      return this.parseParenArrowList(startPos, startLoc, exprList, forInit);
    }
    if (!exprList.length || lastIsComma) {
      this.unexpected(this.lastTokStart);
    }
    if (spreadStart) {
      this.unexpected(spreadStart);
    }
    this.checkExpressionErrors(refDestructuringErrors, true);
    this.yieldPos = oldYieldPos || this.yieldPos;
    this.awaitPos = oldAwaitPos || this.awaitPos;
    if (exprList.length > 1) {
      val = this.startNodeAt(innerStartPos, innerStartLoc);
      val.expressions = exprList;
      this.finishNodeAt(val, "SequenceExpression", innerEndPos, innerEndLoc);
    } else {
      val = exprList[0];
    }
  } else {
    val = this.parseParenExpression();
  }
  if (this.options.preserveParens) {
    var par = this.startNodeAt(startPos, startLoc);
    par.expression = val;
    return this.finishNode(par, "ParenthesizedExpression");
  } else {
    return val;
  }
};
pp$5.parseParenItem = function(item) {
  return item;
};
pp$5.parseParenArrowList = function(startPos, startLoc, exprList, forInit) {
  return this.parseArrowExpression(this.startNodeAt(startPos, startLoc), exprList, false, forInit);
};
var empty = [];
pp$5.parseNew = function() {
  if (this.containsEsc) {
    this.raiseRecoverable(this.start, "Escape sequence in keyword new");
  }
  var node = this.startNode();
  this.next();
  if (this.options.ecmaVersion >= 6 && this.type === types$1.dot) {
    var meta = this.startNodeAt(node.start, node.loc && node.loc.start);
    meta.name = "new";
    node.meta = this.finishNode(meta, "Identifier");
    this.next();
    var containsEsc = this.containsEsc;
    node.property = this.parseIdent(true);
    if (node.property.name !== "target") {
      this.raiseRecoverable(node.property.start, "The only valid meta property for new is 'new.target'");
    }
    if (containsEsc) {
      this.raiseRecoverable(node.start, "'new.target' must not contain escaped characters");
    }
    if (!this.allowNewDotTarget) {
      this.raiseRecoverable(node.start, "'new.target' can only be used in functions and class static block");
    }
    return this.finishNode(node, "MetaProperty");
  }
  var startPos = this.start, startLoc = this.startLoc;
  node.callee = this.parseSubscripts(this.parseExprAtom(null, false, true), startPos, startLoc, true, false);
  if (node.callee.type === "Super") {
    this.raiseRecoverable(startPos, "Invalid use of 'super'");
  }
  if (this.eat(types$1.parenL)) {
    node.arguments = this.parseExprList(types$1.parenR, this.options.ecmaVersion >= 8, false);
  } else {
    node.arguments = empty;
  }
  return this.finishNode(node, "NewExpression");
};
pp$5.parseTemplateElement = function(ref2) {
  var isTagged = ref2.isTagged;
  var elem = this.startNode();
  if (this.type === types$1.invalidTemplate) {
    if (!isTagged) {
      this.raiseRecoverable(this.start, "Bad escape sequence in untagged template literal");
    }
    elem.value = {
      raw: this.value.replace(/\r\n?/g, "\n"),
      cooked: null
    };
  } else {
    elem.value = {
      raw: this.input.slice(this.start, this.end).replace(/\r\n?/g, "\n"),
      cooked: this.value
    };
  }
  this.next();
  elem.tail = this.type === types$1.backQuote;
  return this.finishNode(elem, "TemplateElement");
};
pp$5.parseTemplate = function(ref2) {
  if (ref2 === void 0) ref2 = {};
  var isTagged = ref2.isTagged;
  if (isTagged === void 0) isTagged = false;
  var node = this.startNode();
  this.next();
  node.expressions = [];
  var curElt = this.parseTemplateElement({ isTagged });
  node.quasis = [curElt];
  while (!curElt.tail) {
    if (this.type === types$1.eof) {
      this.raise(this.pos, "Unterminated template literal");
    }
    this.expect(types$1.dollarBraceL);
    node.expressions.push(this.parseExpression());
    this.expect(types$1.braceR);
    node.quasis.push(curElt = this.parseTemplateElement({ isTagged }));
  }
  this.next();
  return this.finishNode(node, "TemplateLiteral");
};
pp$5.isAsyncProp = function(prop) {
  return !prop.computed && prop.key.type === "Identifier" && prop.key.name === "async" && (this.type === types$1.name || this.type === types$1.num || this.type === types$1.string || this.type === types$1.bracketL || this.type.keyword || this.options.ecmaVersion >= 9 && this.type === types$1.star) && !lineBreak.test(this.input.slice(this.lastTokEnd, this.start));
};
pp$5.parseObj = function(isPattern, refDestructuringErrors) {
  var node = this.startNode(), first = true, propHash = {};
  node.properties = [];
  this.next();
  while (!this.eat(types$1.braceR)) {
    if (!first) {
      this.expect(types$1.comma);
      if (this.options.ecmaVersion >= 5 && this.afterTrailingComma(types$1.braceR)) {
        break;
      }
    } else {
      first = false;
    }
    var prop = this.parseProperty(isPattern, refDestructuringErrors);
    if (!isPattern) {
      this.checkPropClash(prop, propHash, refDestructuringErrors);
    }
    node.properties.push(prop);
  }
  return this.finishNode(node, isPattern ? "ObjectPattern" : "ObjectExpression");
};
pp$5.parseProperty = function(isPattern, refDestructuringErrors) {
  var prop = this.startNode(), isGenerator, isAsync, startPos, startLoc;
  if (this.options.ecmaVersion >= 9 && this.eat(types$1.ellipsis)) {
    if (isPattern) {
      prop.argument = this.parseIdent(false);
      if (this.type === types$1.comma) {
        this.raiseRecoverable(this.start, "Comma is not permitted after the rest element");
      }
      return this.finishNode(prop, "RestElement");
    }
    prop.argument = this.parseMaybeAssign(false, refDestructuringErrors);
    if (this.type === types$1.comma && refDestructuringErrors && refDestructuringErrors.trailingComma < 0) {
      refDestructuringErrors.trailingComma = this.start;
    }
    return this.finishNode(prop, "SpreadElement");
  }
  if (this.options.ecmaVersion >= 6) {
    prop.method = false;
    prop.shorthand = false;
    if (isPattern || refDestructuringErrors) {
      startPos = this.start;
      startLoc = this.startLoc;
    }
    if (!isPattern) {
      isGenerator = this.eat(types$1.star);
    }
  }
  var containsEsc = this.containsEsc;
  this.parsePropertyName(prop);
  if (!isPattern && !containsEsc && this.options.ecmaVersion >= 8 && !isGenerator && this.isAsyncProp(prop)) {
    isAsync = true;
    isGenerator = this.options.ecmaVersion >= 9 && this.eat(types$1.star);
    this.parsePropertyName(prop);
  } else {
    isAsync = false;
  }
  this.parsePropertyValue(prop, isPattern, isGenerator, isAsync, startPos, startLoc, refDestructuringErrors, containsEsc);
  return this.finishNode(prop, "Property");
};
pp$5.parseGetterSetter = function(prop) {
  var kind = prop.key.name;
  this.parsePropertyName(prop);
  prop.value = this.parseMethod(false);
  prop.kind = kind;
  var paramCount = prop.kind === "get" ? 0 : 1;
  if (prop.value.params.length !== paramCount) {
    var start = prop.value.start;
    if (prop.kind === "get") {
      this.raiseRecoverable(start, "getter should have no params");
    } else {
      this.raiseRecoverable(start, "setter should have exactly one param");
    }
  } else {
    if (prop.kind === "set" && prop.value.params[0].type === "RestElement") {
      this.raiseRecoverable(prop.value.params[0].start, "Setter cannot use rest params");
    }
  }
};
pp$5.parsePropertyValue = function(prop, isPattern, isGenerator, isAsync, startPos, startLoc, refDestructuringErrors, containsEsc) {
  if ((isGenerator || isAsync) && this.type === types$1.colon) {
    this.unexpected();
  }
  if (this.eat(types$1.colon)) {
    prop.value = isPattern ? this.parseMaybeDefault(this.start, this.startLoc) : this.parseMaybeAssign(false, refDestructuringErrors);
    prop.kind = "init";
  } else if (this.options.ecmaVersion >= 6 && this.type === types$1.parenL) {
    if (isPattern) {
      this.unexpected();
    }
    prop.method = true;
    prop.value = this.parseMethod(isGenerator, isAsync);
    prop.kind = "init";
  } else if (!isPattern && !containsEsc && this.options.ecmaVersion >= 5 && !prop.computed && prop.key.type === "Identifier" && (prop.key.name === "get" || prop.key.name === "set") && (this.type !== types$1.comma && this.type !== types$1.braceR && this.type !== types$1.eq)) {
    if (isGenerator || isAsync) {
      this.unexpected();
    }
    this.parseGetterSetter(prop);
  } else if (this.options.ecmaVersion >= 6 && !prop.computed && prop.key.type === "Identifier") {
    if (isGenerator || isAsync) {
      this.unexpected();
    }
    this.checkUnreserved(prop.key);
    if (prop.key.name === "await" && !this.awaitIdentPos) {
      this.awaitIdentPos = startPos;
    }
    if (isPattern) {
      prop.value = this.parseMaybeDefault(startPos, startLoc, this.copyNode(prop.key));
    } else if (this.type === types$1.eq && refDestructuringErrors) {
      if (refDestructuringErrors.shorthandAssign < 0) {
        refDestructuringErrors.shorthandAssign = this.start;
      }
      prop.value = this.parseMaybeDefault(startPos, startLoc, this.copyNode(prop.key));
    } else {
      prop.value = this.copyNode(prop.key);
    }
    prop.kind = "init";
    prop.shorthand = true;
  } else {
    this.unexpected();
  }
};
pp$5.parsePropertyName = function(prop) {
  if (this.options.ecmaVersion >= 6) {
    if (this.eat(types$1.bracketL)) {
      prop.computed = true;
      prop.key = this.parseMaybeAssign();
      this.expect(types$1.bracketR);
      return prop.key;
    } else {
      prop.computed = false;
    }
  }
  return prop.key = this.type === types$1.num || this.type === types$1.string ? this.parseExprAtom() : this.parseIdent(this.options.allowReserved !== "never");
};
pp$5.initFunction = function(node) {
  node.id = null;
  if (this.options.ecmaVersion >= 6) {
    node.generator = node.expression = false;
  }
  if (this.options.ecmaVersion >= 8) {
    node.async = false;
  }
};
pp$5.parseMethod = function(isGenerator, isAsync, allowDirectSuper) {
  var node = this.startNode(), oldYieldPos = this.yieldPos, oldAwaitPos = this.awaitPos, oldAwaitIdentPos = this.awaitIdentPos;
  this.initFunction(node);
  if (this.options.ecmaVersion >= 6) {
    node.generator = isGenerator;
  }
  if (this.options.ecmaVersion >= 8) {
    node.async = !!isAsync;
  }
  this.yieldPos = 0;
  this.awaitPos = 0;
  this.awaitIdentPos = 0;
  this.enterScope(functionFlags(isAsync, node.generator) | SCOPE_SUPER | (allowDirectSuper ? SCOPE_DIRECT_SUPER : 0));
  this.expect(types$1.parenL);
  node.params = this.parseBindingList(types$1.parenR, false, this.options.ecmaVersion >= 8);
  this.checkYieldAwaitInDefaultParams();
  this.parseFunctionBody(node, false, true, false);
  this.yieldPos = oldYieldPos;
  this.awaitPos = oldAwaitPos;
  this.awaitIdentPos = oldAwaitIdentPos;
  return this.finishNode(node, "FunctionExpression");
};
pp$5.parseArrowExpression = function(node, params, isAsync, forInit) {
  var oldYieldPos = this.yieldPos, oldAwaitPos = this.awaitPos, oldAwaitIdentPos = this.awaitIdentPos;
  this.enterScope(functionFlags(isAsync, false) | SCOPE_ARROW);
  this.initFunction(node);
  if (this.options.ecmaVersion >= 8) {
    node.async = !!isAsync;
  }
  this.yieldPos = 0;
  this.awaitPos = 0;
  this.awaitIdentPos = 0;
  node.params = this.toAssignableList(params, true);
  this.parseFunctionBody(node, true, false, forInit);
  this.yieldPos = oldYieldPos;
  this.awaitPos = oldAwaitPos;
  this.awaitIdentPos = oldAwaitIdentPos;
  return this.finishNode(node, "ArrowFunctionExpression");
};
pp$5.parseFunctionBody = function(node, isArrowFunction, isMethod, forInit) {
  var isExpression = isArrowFunction && this.type !== types$1.braceL;
  var oldStrict = this.strict, useStrict = false;
  if (isExpression) {
    node.body = this.parseMaybeAssign(forInit);
    node.expression = true;
    this.checkParams(node, false);
  } else {
    var nonSimple = this.options.ecmaVersion >= 7 && !this.isSimpleParamList(node.params);
    if (!oldStrict || nonSimple) {
      useStrict = this.strictDirective(this.end);
      if (useStrict && nonSimple) {
        this.raiseRecoverable(node.start, "Illegal 'use strict' directive in function with non-simple parameter list");
      }
    }
    var oldLabels = this.labels;
    this.labels = [];
    if (useStrict) {
      this.strict = true;
    }
    this.checkParams(node, !oldStrict && !useStrict && !isArrowFunction && !isMethod && this.isSimpleParamList(node.params));
    if (this.strict && node.id) {
      this.checkLValSimple(node.id, BIND_OUTSIDE);
    }
    node.body = this.parseBlock(false, void 0, useStrict && !oldStrict);
    node.expression = false;
    this.adaptDirectivePrologue(node.body.body);
    this.labels = oldLabels;
  }
  this.exitScope();
};
pp$5.isSimpleParamList = function(params) {
  for (var i2 = 0, list2 = params; i2 < list2.length; i2 += 1) {
    var param = list2[i2];
    if (param.type !== "Identifier") {
      return false;
    }
  }
  return true;
};
pp$5.checkParams = function(node, allowDuplicates) {
  var nameHash = /* @__PURE__ */ Object.create(null);
  for (var i2 = 0, list2 = node.params; i2 < list2.length; i2 += 1) {
    var param = list2[i2];
    this.checkLValInnerPattern(param, BIND_VAR, allowDuplicates ? null : nameHash);
  }
};
pp$5.parseExprList = function(close, allowTrailingComma, allowEmpty, refDestructuringErrors) {
  var elts = [], first = true;
  while (!this.eat(close)) {
    if (!first) {
      this.expect(types$1.comma);
      if (allowTrailingComma && this.afterTrailingComma(close)) {
        break;
      }
    } else {
      first = false;
    }
    var elt = void 0;
    if (allowEmpty && this.type === types$1.comma) {
      elt = null;
    } else if (this.type === types$1.ellipsis) {
      elt = this.parseSpread(refDestructuringErrors);
      if (refDestructuringErrors && this.type === types$1.comma && refDestructuringErrors.trailingComma < 0) {
        refDestructuringErrors.trailingComma = this.start;
      }
    } else {
      elt = this.parseMaybeAssign(false, refDestructuringErrors);
    }
    elts.push(elt);
  }
  return elts;
};
pp$5.checkUnreserved = function(ref2) {
  var start = ref2.start;
  var end = ref2.end;
  var name = ref2.name;
  if (this.inGenerator && name === "yield") {
    this.raiseRecoverable(start, "Cannot use 'yield' as identifier inside a generator");
  }
  if (this.inAsync && name === "await") {
    this.raiseRecoverable(start, "Cannot use 'await' as identifier inside an async function");
  }
  if (!(this.currentThisScope().flags & SCOPE_VAR) && name === "arguments") {
    this.raiseRecoverable(start, "Cannot use 'arguments' in class field initializer");
  }
  if (this.inClassStaticBlock && (name === "arguments" || name === "await")) {
    this.raise(start, "Cannot use " + name + " in class static initialization block");
  }
  if (this.keywords.test(name)) {
    this.raise(start, "Unexpected keyword '" + name + "'");
  }
  if (this.options.ecmaVersion < 6 && this.input.slice(start, end).indexOf("\\") !== -1) {
    return;
  }
  var re = this.strict ? this.reservedWordsStrict : this.reservedWords;
  if (re.test(name)) {
    if (!this.inAsync && name === "await") {
      this.raiseRecoverable(start, "Cannot use keyword 'await' outside an async function");
    }
    this.raiseRecoverable(start, "The keyword '" + name + "' is reserved");
  }
};
pp$5.parseIdent = function(liberal) {
  var node = this.parseIdentNode();
  this.next(!!liberal);
  this.finishNode(node, "Identifier");
  if (!liberal) {
    this.checkUnreserved(node);
    if (node.name === "await" && !this.awaitIdentPos) {
      this.awaitIdentPos = node.start;
    }
  }
  return node;
};
pp$5.parseIdentNode = function() {
  var node = this.startNode();
  if (this.type === types$1.name) {
    node.name = this.value;
  } else if (this.type.keyword) {
    node.name = this.type.keyword;
    if ((node.name === "class" || node.name === "function") && (this.lastTokEnd !== this.lastTokStart + 1 || this.input.charCodeAt(this.lastTokStart) !== 46)) {
      this.context.pop();
    }
    this.type = types$1.name;
  } else {
    this.unexpected();
  }
  return node;
};
pp$5.parsePrivateIdent = function() {
  var node = this.startNode();
  if (this.type === types$1.privateId) {
    node.name = this.value;
  } else {
    this.unexpected();
  }
  this.next();
  this.finishNode(node, "PrivateIdentifier");
  if (this.options.checkPrivateFields) {
    if (this.privateNameStack.length === 0) {
      this.raise(node.start, "Private field '#" + node.name + "' must be declared in an enclosing class");
    } else {
      this.privateNameStack[this.privateNameStack.length - 1].used.push(node);
    }
  }
  return node;
};
pp$5.parseYield = function(forInit) {
  if (!this.yieldPos) {
    this.yieldPos = this.start;
  }
  var node = this.startNode();
  this.next();
  if (this.type === types$1.semi || this.canInsertSemicolon() || this.type !== types$1.star && !this.type.startsExpr) {
    node.delegate = false;
    node.argument = null;
  } else {
    node.delegate = this.eat(types$1.star);
    node.argument = this.parseMaybeAssign(forInit);
  }
  return this.finishNode(node, "YieldExpression");
};
pp$5.parseAwait = function(forInit) {
  if (!this.awaitPos) {
    this.awaitPos = this.start;
  }
  var node = this.startNode();
  this.next();
  node.argument = this.parseMaybeUnary(null, true, false, forInit);
  return this.finishNode(node, "AwaitExpression");
};
var pp$4 = Parser.prototype;
pp$4.raise = function(pos, message) {
  var loc = getLineInfo(this.input, pos);
  message += " (" + loc.line + ":" + loc.column + ")";
  if (this.sourceFile) {
    message += " in " + this.sourceFile;
  }
  var err = new SyntaxError(message);
  err.pos = pos;
  err.loc = loc;
  err.raisedAt = this.pos;
  throw err;
};
pp$4.raiseRecoverable = pp$4.raise;
pp$4.curPosition = function() {
  if (this.options.locations) {
    return new Position(this.curLine, this.pos - this.lineStart);
  }
};
var pp$3 = Parser.prototype;
var Scope = function Scope2(flags) {
  this.flags = flags;
  this.var = [];
  this.lexical = [];
  this.functions = [];
};
pp$3.enterScope = function(flags) {
  this.scopeStack.push(new Scope(flags));
};
pp$3.exitScope = function() {
  this.scopeStack.pop();
};
pp$3.treatFunctionsAsVarInScope = function(scope) {
  return scope.flags & SCOPE_FUNCTION || !this.inModule && scope.flags & SCOPE_TOP;
};
pp$3.declareName = function(name, bindingType, pos) {
  var redeclared = false;
  if (bindingType === BIND_LEXICAL) {
    var scope = this.currentScope();
    redeclared = scope.lexical.indexOf(name) > -1 || scope.functions.indexOf(name) > -1 || scope.var.indexOf(name) > -1;
    scope.lexical.push(name);
    if (this.inModule && scope.flags & SCOPE_TOP) {
      delete this.undefinedExports[name];
    }
  } else if (bindingType === BIND_SIMPLE_CATCH) {
    var scope$1 = this.currentScope();
    scope$1.lexical.push(name);
  } else if (bindingType === BIND_FUNCTION) {
    var scope$2 = this.currentScope();
    if (this.treatFunctionsAsVar) {
      redeclared = scope$2.lexical.indexOf(name) > -1;
    } else {
      redeclared = scope$2.lexical.indexOf(name) > -1 || scope$2.var.indexOf(name) > -1;
    }
    scope$2.functions.push(name);
  } else {
    for (var i2 = this.scopeStack.length - 1; i2 >= 0; --i2) {
      var scope$3 = this.scopeStack[i2];
      if (scope$3.lexical.indexOf(name) > -1 && !(scope$3.flags & SCOPE_SIMPLE_CATCH && scope$3.lexical[0] === name) || !this.treatFunctionsAsVarInScope(scope$3) && scope$3.functions.indexOf(name) > -1) {
        redeclared = true;
        break;
      }
      scope$3.var.push(name);
      if (this.inModule && scope$3.flags & SCOPE_TOP) {
        delete this.undefinedExports[name];
      }
      if (scope$3.flags & SCOPE_VAR) {
        break;
      }
    }
  }
  if (redeclared) {
    this.raiseRecoverable(pos, "Identifier '" + name + "' has already been declared");
  }
};
pp$3.checkLocalExport = function(id) {
  if (this.scopeStack[0].lexical.indexOf(id.name) === -1 && this.scopeStack[0].var.indexOf(id.name) === -1) {
    this.undefinedExports[id.name] = id;
  }
};
pp$3.currentScope = function() {
  return this.scopeStack[this.scopeStack.length - 1];
};
pp$3.currentVarScope = function() {
  for (var i2 = this.scopeStack.length - 1; ; i2--) {
    var scope = this.scopeStack[i2];
    if (scope.flags & (SCOPE_VAR | SCOPE_CLASS_FIELD_INIT | SCOPE_CLASS_STATIC_BLOCK)) {
      return scope;
    }
  }
};
pp$3.currentThisScope = function() {
  for (var i2 = this.scopeStack.length - 1; ; i2--) {
    var scope = this.scopeStack[i2];
    if (scope.flags & (SCOPE_VAR | SCOPE_CLASS_FIELD_INIT | SCOPE_CLASS_STATIC_BLOCK) && !(scope.flags & SCOPE_ARROW)) {
      return scope;
    }
  }
};
var Node = function Node2(parser, pos, loc) {
  this.type = "";
  this.start = pos;
  this.end = 0;
  if (parser.options.locations) {
    this.loc = new SourceLocation(parser, loc);
  }
  if (parser.options.directSourceFile) {
    this.sourceFile = parser.options.directSourceFile;
  }
  if (parser.options.ranges) {
    this.range = [pos, 0];
  }
};
var pp$2 = Parser.prototype;
pp$2.startNode = function() {
  return new Node(this, this.start, this.startLoc);
};
pp$2.startNodeAt = function(pos, loc) {
  return new Node(this, pos, loc);
};
function finishNodeAt(node, type, pos, loc) {
  node.type = type;
  node.end = pos;
  if (this.options.locations) {
    node.loc.end = loc;
  }
  if (this.options.ranges) {
    node.range[1] = pos;
  }
  return node;
}
pp$2.finishNode = function(node, type) {
  return finishNodeAt.call(this, node, type, this.lastTokEnd, this.lastTokEndLoc);
};
pp$2.finishNodeAt = function(node, type, pos, loc) {
  return finishNodeAt.call(this, node, type, pos, loc);
};
pp$2.copyNode = function(node) {
  var newNode = new Node(this, node.start, this.startLoc);
  for (var prop in node) {
    newNode[prop] = node[prop];
  }
  return newNode;
};
var scriptValuesAddedInUnicode = "Berf Beria_Erfe Gara Garay Gukh Gurung_Khema Hrkt Katakana_Or_Hiragana Kawi Kirat_Rai Krai Nag_Mundari Nagm Ol_Onal Onao Sidetic Sidt Sunu Sunuwar Tai_Yo Tayo Todhri Todr Tolong_Siki Tols Tulu_Tigalari Tutg Unknown Zzzz";
var ecma9BinaryProperties = "ASCII ASCII_Hex_Digit AHex Alphabetic Alpha Any Assigned Bidi_Control Bidi_C Bidi_Mirrored Bidi_M Case_Ignorable CI Cased Changes_When_Casefolded CWCF Changes_When_Casemapped CWCM Changes_When_Lowercased CWL Changes_When_NFKC_Casefolded CWKCF Changes_When_Titlecased CWT Changes_When_Uppercased CWU Dash Default_Ignorable_Code_Point DI Deprecated Dep Diacritic Dia Emoji Emoji_Component Emoji_Modifier Emoji_Modifier_Base Emoji_Presentation Extender Ext Grapheme_Base Gr_Base Grapheme_Extend Gr_Ext Hex_Digit Hex IDS_Binary_Operator IDSB IDS_Trinary_Operator IDST ID_Continue IDC ID_Start IDS Ideographic Ideo Join_Control Join_C Logical_Order_Exception LOE Lowercase Lower Math Noncharacter_Code_Point NChar Pattern_Syntax Pat_Syn Pattern_White_Space Pat_WS Quotation_Mark QMark Radical Regional_Indicator RI Sentence_Terminal STerm Soft_Dotted SD Terminal_Punctuation Term Unified_Ideograph UIdeo Uppercase Upper Variation_Selector VS White_Space space XID_Continue XIDC XID_Start XIDS";
var ecma10BinaryProperties = ecma9BinaryProperties + " Extended_Pictographic";
var ecma11BinaryProperties = ecma10BinaryProperties;
var ecma12BinaryProperties = ecma11BinaryProperties + " EBase EComp EMod EPres ExtPict";
var ecma13BinaryProperties = ecma12BinaryProperties;
var ecma14BinaryProperties = ecma13BinaryProperties;
var unicodeBinaryProperties = {
  9: ecma9BinaryProperties,
  10: ecma10BinaryProperties,
  11: ecma11BinaryProperties,
  12: ecma12BinaryProperties,
  13: ecma13BinaryProperties,
  14: ecma14BinaryProperties
};
var ecma14BinaryPropertiesOfStrings = "Basic_Emoji Emoji_Keycap_Sequence RGI_Emoji_Modifier_Sequence RGI_Emoji_Flag_Sequence RGI_Emoji_Tag_Sequence RGI_Emoji_ZWJ_Sequence RGI_Emoji";
var unicodeBinaryPropertiesOfStrings = {
  9: "",
  10: "",
  11: "",
  12: "",
  13: "",
  14: ecma14BinaryPropertiesOfStrings
};
var unicodeGeneralCategoryValues = "Cased_Letter LC Close_Punctuation Pe Connector_Punctuation Pc Control Cc cntrl Currency_Symbol Sc Dash_Punctuation Pd Decimal_Number Nd digit Enclosing_Mark Me Final_Punctuation Pf Format Cf Initial_Punctuation Pi Letter L Letter_Number Nl Line_Separator Zl Lowercase_Letter Ll Mark M Combining_Mark Math_Symbol Sm Modifier_Letter Lm Modifier_Symbol Sk Nonspacing_Mark Mn Number N Open_Punctuation Ps Other C Other_Letter Lo Other_Number No Other_Punctuation Po Other_Symbol So Paragraph_Separator Zp Private_Use Co Punctuation P punct Separator Z Space_Separator Zs Spacing_Mark Mc Surrogate Cs Symbol S Titlecase_Letter Lt Unassigned Cn Uppercase_Letter Lu";
var ecma9ScriptValues = "Adlam Adlm Ahom Anatolian_Hieroglyphs Hluw Arabic Arab Armenian Armn Avestan Avst Balinese Bali Bamum Bamu Bassa_Vah Bass Batak Batk Bengali Beng Bhaiksuki Bhks Bopomofo Bopo Brahmi Brah Braille Brai Buginese Bugi Buhid Buhd Canadian_Aboriginal Cans Carian Cari Caucasian_Albanian Aghb Chakma Cakm Cham Cham Cherokee Cher Common Zyyy Coptic Copt Qaac Cuneiform Xsux Cypriot Cprt Cyrillic Cyrl Deseret Dsrt Devanagari Deva Duployan Dupl Egyptian_Hieroglyphs Egyp Elbasan Elba Ethiopic Ethi Georgian Geor Glagolitic Glag Gothic Goth Grantha Gran Greek Grek Gujarati Gujr Gurmukhi Guru Han Hani Hangul Hang Hanunoo Hano Hatran Hatr Hebrew Hebr Hiragana Hira Imperial_Aramaic Armi Inherited Zinh Qaai Inscriptional_Pahlavi Phli Inscriptional_Parthian Prti Javanese Java Kaithi Kthi Kannada Knda Katakana Kana Kayah_Li Kali Kharoshthi Khar Khmer Khmr Khojki Khoj Khudawadi Sind Lao Laoo Latin Latn Lepcha Lepc Limbu Limb Linear_A Lina Linear_B Linb Lisu Lisu Lycian Lyci Lydian Lydi Mahajani Mahj Malayalam Mlym Mandaic Mand Manichaean Mani Marchen Marc Masaram_Gondi Gonm Meetei_Mayek Mtei Mende_Kikakui Mend Meroitic_Cursive Merc Meroitic_Hieroglyphs Mero Miao Plrd Modi Mongolian Mong Mro Mroo Multani Mult Myanmar Mymr Nabataean Nbat New_Tai_Lue Talu Newa Newa Nko Nkoo Nushu Nshu Ogham Ogam Ol_Chiki Olck Old_Hungarian Hung Old_Italic Ital Old_North_Arabian Narb Old_Permic Perm Old_Persian Xpeo Old_South_Arabian Sarb Old_Turkic Orkh Oriya Orya Osage Osge Osmanya Osma Pahawh_Hmong Hmng Palmyrene Palm Pau_Cin_Hau Pauc Phags_Pa Phag Phoenician Phnx Psalter_Pahlavi Phlp Rejang Rjng Runic Runr Samaritan Samr Saurashtra Saur Sharada Shrd Shavian Shaw Siddham Sidd SignWriting Sgnw Sinhala Sinh Sora_Sompeng Sora Soyombo Soyo Sundanese Sund Syloti_Nagri Sylo Syriac Syrc Tagalog Tglg Tagbanwa Tagb Tai_Le Tale Tai_Tham Lana Tai_Viet Tavt Takri Takr Tamil Taml Tangut Tang Telugu Telu Thaana Thaa Thai Thai Tibetan Tibt Tifinagh Tfng Tirhuta Tirh Ugaritic Ugar Vai Vaii Warang_Citi Wara Yi Yiii Zanabazar_Square Zanb";
var ecma10ScriptValues = ecma9ScriptValues + " Dogra Dogr Gunjala_Gondi Gong Hanifi_Rohingya Rohg Makasar Maka Medefaidrin Medf Old_Sogdian Sogo Sogdian Sogd";
var ecma11ScriptValues = ecma10ScriptValues + " Elymaic Elym Nandinagari Nand Nyiakeng_Puachue_Hmong Hmnp Wancho Wcho";
var ecma12ScriptValues = ecma11ScriptValues + " Chorasmian Chrs Diak Dives_Akuru Khitan_Small_Script Kits Yezi Yezidi";
var ecma13ScriptValues = ecma12ScriptValues + " Cypro_Minoan Cpmn Old_Uyghur Ougr Tangsa Tnsa Toto Vithkuqi Vith";
var ecma14ScriptValues = ecma13ScriptValues + " " + scriptValuesAddedInUnicode;
var unicodeScriptValues = {
  9: ecma9ScriptValues,
  10: ecma10ScriptValues,
  11: ecma11ScriptValues,
  12: ecma12ScriptValues,
  13: ecma13ScriptValues,
  14: ecma14ScriptValues
};
var data = {};
function buildUnicodeData(ecmaVersion2) {
  var d = data[ecmaVersion2] = {
    binary: wordsRegexp(unicodeBinaryProperties[ecmaVersion2] + " " + unicodeGeneralCategoryValues),
    binaryOfStrings: wordsRegexp(unicodeBinaryPropertiesOfStrings[ecmaVersion2]),
    nonBinary: {
      General_Category: wordsRegexp(unicodeGeneralCategoryValues),
      Script: wordsRegexp(unicodeScriptValues[ecmaVersion2])
    }
  };
  d.nonBinary.Script_Extensions = d.nonBinary.Script;
  d.nonBinary.gc = d.nonBinary.General_Category;
  d.nonBinary.sc = d.nonBinary.Script;
  d.nonBinary.scx = d.nonBinary.Script_Extensions;
}
for (i = 0, list = [9, 10, 11, 12, 13, 14]; i < list.length; i += 1) {
  ecmaVersion = list[i];
  buildUnicodeData(ecmaVersion);
}
var ecmaVersion;
var i;
var list;
var pp$1 = Parser.prototype;
var BranchID = function BranchID2(parent, base5) {
  this.parent = parent;
  this.base = base5 || this;
};
BranchID.prototype.separatedFrom = function separatedFrom(alt) {
  for (var self = this; self; self = self.parent) {
    for (var other = alt; other; other = other.parent) {
      if (self.base === other.base && self !== other) {
        return true;
      }
    }
  }
  return false;
};
BranchID.prototype.sibling = function sibling() {
  return new BranchID(this.parent, this.base);
};
var RegExpValidationState = function RegExpValidationState2(parser) {
  this.parser = parser;
  this.validFlags = "gim" + (parser.options.ecmaVersion >= 6 ? "uy" : "") + (parser.options.ecmaVersion >= 9 ? "s" : "") + (parser.options.ecmaVersion >= 13 ? "d" : "") + (parser.options.ecmaVersion >= 15 ? "v" : "");
  this.unicodeProperties = data[parser.options.ecmaVersion >= 14 ? 14 : parser.options.ecmaVersion];
  this.source = "";
  this.flags = "";
  this.start = 0;
  this.switchU = false;
  this.switchV = false;
  this.switchN = false;
  this.pos = 0;
  this.lastIntValue = 0;
  this.lastStringValue = "";
  this.lastAssertionIsQuantifiable = false;
  this.numCapturingParens = 0;
  this.maxBackReference = 0;
  this.groupNames = /* @__PURE__ */ Object.create(null);
  this.backReferenceNames = [];
  this.branchID = null;
};
RegExpValidationState.prototype.reset = function reset(start, pattern, flags) {
  var unicodeSets = flags.indexOf("v") !== -1;
  var unicode = flags.indexOf("u") !== -1;
  this.start = start | 0;
  this.source = pattern + "";
  this.flags = flags;
  if (unicodeSets && this.parser.options.ecmaVersion >= 15) {
    this.switchU = true;
    this.switchV = true;
    this.switchN = true;
  } else {
    this.switchU = unicode && this.parser.options.ecmaVersion >= 6;
    this.switchV = false;
    this.switchN = unicode && this.parser.options.ecmaVersion >= 9;
  }
};
RegExpValidationState.prototype.raise = function raise(message) {
  this.parser.raiseRecoverable(this.start, "Invalid regular expression: /" + this.source + "/: " + message);
};
RegExpValidationState.prototype.at = function at(i2, forceU) {
  if (forceU === void 0) forceU = false;
  var s = this.source;
  var l = s.length;
  if (i2 >= l) {
    return -1;
  }
  var c = s.charCodeAt(i2);
  if (!(forceU || this.switchU) || c <= 55295 || c >= 57344 || i2 + 1 >= l) {
    return c;
  }
  var next = s.charCodeAt(i2 + 1);
  return next >= 56320 && next <= 57343 ? (c << 10) + next - 56613888 : c;
};
RegExpValidationState.prototype.nextIndex = function nextIndex(i2, forceU) {
  if (forceU === void 0) forceU = false;
  var s = this.source;
  var l = s.length;
  if (i2 >= l) {
    return l;
  }
  var c = s.charCodeAt(i2), next;
  if (!(forceU || this.switchU) || c <= 55295 || c >= 57344 || i2 + 1 >= l || (next = s.charCodeAt(i2 + 1)) < 56320 || next > 57343) {
    return i2 + 1;
  }
  return i2 + 2;
};
RegExpValidationState.prototype.current = function current(forceU) {
  if (forceU === void 0) forceU = false;
  return this.at(this.pos, forceU);
};
RegExpValidationState.prototype.lookahead = function lookahead(forceU) {
  if (forceU === void 0) forceU = false;
  return this.at(this.nextIndex(this.pos, forceU), forceU);
};
RegExpValidationState.prototype.advance = function advance(forceU) {
  if (forceU === void 0) forceU = false;
  this.pos = this.nextIndex(this.pos, forceU);
};
RegExpValidationState.prototype.eat = function eat(ch, forceU) {
  if (forceU === void 0) forceU = false;
  if (this.current(forceU) === ch) {
    this.advance(forceU);
    return true;
  }
  return false;
};
RegExpValidationState.prototype.eatChars = function eatChars(chs, forceU) {
  if (forceU === void 0) forceU = false;
  var pos = this.pos;
  for (var i2 = 0, list2 = chs; i2 < list2.length; i2 += 1) {
    var ch = list2[i2];
    var current2 = this.at(pos, forceU);
    if (current2 === -1 || current2 !== ch) {
      return false;
    }
    pos = this.nextIndex(pos, forceU);
  }
  this.pos = pos;
  return true;
};
pp$1.validateRegExpFlags = function(state) {
  var validFlags = state.validFlags;
  var flags = state.flags;
  var u = false;
  var v = false;
  for (var i2 = 0; i2 < flags.length; i2++) {
    var flag = flags.charAt(i2);
    if (validFlags.indexOf(flag) === -1) {
      this.raise(state.start, "Invalid regular expression flag");
    }
    if (flags.indexOf(flag, i2 + 1) > -1) {
      this.raise(state.start, "Duplicate regular expression flag");
    }
    if (flag === "u") {
      u = true;
    }
    if (flag === "v") {
      v = true;
    }
  }
  if (this.options.ecmaVersion >= 15 && u && v) {
    this.raise(state.start, "Invalid regular expression flag");
  }
};
function hasProp(obj) {
  for (var _ in obj) {
    return true;
  }
  return false;
}
pp$1.validateRegExpPattern = function(state) {
  this.regexp_pattern(state);
  if (!state.switchN && this.options.ecmaVersion >= 9 && hasProp(state.groupNames)) {
    state.switchN = true;
    this.regexp_pattern(state);
  }
};
pp$1.regexp_pattern = function(state) {
  state.pos = 0;
  state.lastIntValue = 0;
  state.lastStringValue = "";
  state.lastAssertionIsQuantifiable = false;
  state.numCapturingParens = 0;
  state.maxBackReference = 0;
  state.groupNames = /* @__PURE__ */ Object.create(null);
  state.backReferenceNames.length = 0;
  state.branchID = null;
  this.regexp_disjunction(state);
  if (state.pos !== state.source.length) {
    if (state.eat(
      41
      /* ) */
    )) {
      state.raise("Unmatched ')'");
    }
    if (state.eat(
      93
      /* ] */
    ) || state.eat(
      125
      /* } */
    )) {
      state.raise("Lone quantifier brackets");
    }
  }
  if (state.maxBackReference > state.numCapturingParens) {
    state.raise("Invalid escape");
  }
  for (var i2 = 0, list2 = state.backReferenceNames; i2 < list2.length; i2 += 1) {
    var name = list2[i2];
    if (!state.groupNames[name]) {
      state.raise("Invalid named capture referenced");
    }
  }
};
pp$1.regexp_disjunction = function(state) {
  var trackDisjunction = this.options.ecmaVersion >= 16;
  if (trackDisjunction) {
    state.branchID = new BranchID(state.branchID, null);
  }
  this.regexp_alternative(state);
  while (state.eat(
    124
    /* | */
  )) {
    if (trackDisjunction) {
      state.branchID = state.branchID.sibling();
    }
    this.regexp_alternative(state);
  }
  if (trackDisjunction) {
    state.branchID = state.branchID.parent;
  }
  if (this.regexp_eatQuantifier(state, true)) {
    state.raise("Nothing to repeat");
  }
  if (state.eat(
    123
    /* { */
  )) {
    state.raise("Lone quantifier brackets");
  }
};
pp$1.regexp_alternative = function(state) {
  while (state.pos < state.source.length && this.regexp_eatTerm(state)) {
  }
};
pp$1.regexp_eatTerm = function(state) {
  if (this.regexp_eatAssertion(state)) {
    if (state.lastAssertionIsQuantifiable && this.regexp_eatQuantifier(state)) {
      if (state.switchU) {
        state.raise("Invalid quantifier");
      }
    }
    return true;
  }
  if (state.switchU ? this.regexp_eatAtom(state) : this.regexp_eatExtendedAtom(state)) {
    this.regexp_eatQuantifier(state);
    return true;
  }
  return false;
};
pp$1.regexp_eatAssertion = function(state) {
  var start = state.pos;
  state.lastAssertionIsQuantifiable = false;
  if (state.eat(
    94
    /* ^ */
  ) || state.eat(
    36
    /* $ */
  )) {
    return true;
  }
  if (state.eat(
    92
    /* \ */
  )) {
    if (state.eat(
      66
      /* B */
    ) || state.eat(
      98
      /* b */
    )) {
      return true;
    }
    state.pos = start;
  }
  if (state.eat(
    40
    /* ( */
  ) && state.eat(
    63
    /* ? */
  )) {
    var lookbehind = false;
    if (this.options.ecmaVersion >= 9) {
      lookbehind = state.eat(
        60
        /* < */
      );
    }
    if (state.eat(
      61
      /* = */
    ) || state.eat(
      33
      /* ! */
    )) {
      this.regexp_disjunction(state);
      if (!state.eat(
        41
        /* ) */
      )) {
        state.raise("Unterminated group");
      }
      state.lastAssertionIsQuantifiable = !lookbehind;
      return true;
    }
  }
  state.pos = start;
  return false;
};
pp$1.regexp_eatQuantifier = function(state, noError) {
  if (noError === void 0) noError = false;
  if (this.regexp_eatQuantifierPrefix(state, noError)) {
    state.eat(
      63
      /* ? */
    );
    return true;
  }
  return false;
};
pp$1.regexp_eatQuantifierPrefix = function(state, noError) {
  return state.eat(
    42
    /* * */
  ) || state.eat(
    43
    /* + */
  ) || state.eat(
    63
    /* ? */
  ) || this.regexp_eatBracedQuantifier(state, noError);
};
pp$1.regexp_eatBracedQuantifier = function(state, noError) {
  var start = state.pos;
  if (state.eat(
    123
    /* { */
  )) {
    var min = 0, max = -1;
    if (this.regexp_eatDecimalDigits(state)) {
      min = state.lastIntValue;
      if (state.eat(
        44
        /* , */
      ) && this.regexp_eatDecimalDigits(state)) {
        max = state.lastIntValue;
      }
      if (state.eat(
        125
        /* } */
      )) {
        if (max !== -1 && max < min && !noError) {
          state.raise("numbers out of order in {} quantifier");
        }
        return true;
      }
    }
    if (state.switchU && !noError) {
      state.raise("Incomplete quantifier");
    }
    state.pos = start;
  }
  return false;
};
pp$1.regexp_eatAtom = function(state) {
  return this.regexp_eatPatternCharacters(state) || state.eat(
    46
    /* . */
  ) || this.regexp_eatReverseSolidusAtomEscape(state) || this.regexp_eatCharacterClass(state) || this.regexp_eatUncapturingGroup(state) || this.regexp_eatCapturingGroup(state);
};
pp$1.regexp_eatReverseSolidusAtomEscape = function(state) {
  var start = state.pos;
  if (state.eat(
    92
    /* \ */
  )) {
    if (this.regexp_eatAtomEscape(state)) {
      return true;
    }
    state.pos = start;
  }
  return false;
};
pp$1.regexp_eatUncapturingGroup = function(state) {
  var start = state.pos;
  if (state.eat(
    40
    /* ( */
  )) {
    if (state.eat(
      63
      /* ? */
    )) {
      if (this.options.ecmaVersion >= 16) {
        var addModifiers = this.regexp_eatModifiers(state);
        var hasHyphen = state.eat(
          45
          /* - */
        );
        if (addModifiers || hasHyphen) {
          for (var i2 = 0; i2 < addModifiers.length; i2++) {
            var modifier = addModifiers.charAt(i2);
            if (addModifiers.indexOf(modifier, i2 + 1) > -1) {
              state.raise("Duplicate regular expression modifiers");
            }
          }
          if (hasHyphen) {
            var removeModifiers = this.regexp_eatModifiers(state);
            if (!addModifiers && !removeModifiers && state.current() === 58) {
              state.raise("Invalid regular expression modifiers");
            }
            for (var i$1 = 0; i$1 < removeModifiers.length; i$1++) {
              var modifier$1 = removeModifiers.charAt(i$1);
              if (removeModifiers.indexOf(modifier$1, i$1 + 1) > -1 || addModifiers.indexOf(modifier$1) > -1) {
                state.raise("Duplicate regular expression modifiers");
              }
            }
          }
        }
      }
      if (state.eat(
        58
        /* : */
      )) {
        this.regexp_disjunction(state);
        if (state.eat(
          41
          /* ) */
        )) {
          return true;
        }
        state.raise("Unterminated group");
      }
    }
    state.pos = start;
  }
  return false;
};
pp$1.regexp_eatCapturingGroup = function(state) {
  if (state.eat(
    40
    /* ( */
  )) {
    if (this.options.ecmaVersion >= 9) {
      this.regexp_groupSpecifier(state);
    } else if (state.current() === 63) {
      state.raise("Invalid group");
    }
    this.regexp_disjunction(state);
    if (state.eat(
      41
      /* ) */
    )) {
      state.numCapturingParens += 1;
      return true;
    }
    state.raise("Unterminated group");
  }
  return false;
};
pp$1.regexp_eatModifiers = function(state) {
  var modifiers = "";
  var ch = 0;
  while ((ch = state.current()) !== -1 && isRegularExpressionModifier(ch)) {
    modifiers += codePointToString(ch);
    state.advance();
  }
  return modifiers;
};
function isRegularExpressionModifier(ch) {
  return ch === 105 || ch === 109 || ch === 115;
}
pp$1.regexp_eatExtendedAtom = function(state) {
  return state.eat(
    46
    /* . */
  ) || this.regexp_eatReverseSolidusAtomEscape(state) || this.regexp_eatCharacterClass(state) || this.regexp_eatUncapturingGroup(state) || this.regexp_eatCapturingGroup(state) || this.regexp_eatInvalidBracedQuantifier(state) || this.regexp_eatExtendedPatternCharacter(state);
};
pp$1.regexp_eatInvalidBracedQuantifier = function(state) {
  if (this.regexp_eatBracedQuantifier(state, true)) {
    state.raise("Nothing to repeat");
  }
  return false;
};
pp$1.regexp_eatSyntaxCharacter = function(state) {
  var ch = state.current();
  if (isSyntaxCharacter(ch)) {
    state.lastIntValue = ch;
    state.advance();
    return true;
  }
  return false;
};
function isSyntaxCharacter(ch) {
  return ch === 36 || ch >= 40 && ch <= 43 || ch === 46 || ch === 63 || ch >= 91 && ch <= 94 || ch >= 123 && ch <= 125;
}
pp$1.regexp_eatPatternCharacters = function(state) {
  var start = state.pos;
  var ch = 0;
  while ((ch = state.current()) !== -1 && !isSyntaxCharacter(ch)) {
    state.advance();
  }
  return state.pos !== start;
};
pp$1.regexp_eatExtendedPatternCharacter = function(state) {
  var ch = state.current();
  if (ch !== -1 && ch !== 36 && !(ch >= 40 && ch <= 43) && ch !== 46 && ch !== 63 && ch !== 91 && ch !== 94 && ch !== 124) {
    state.advance();
    return true;
  }
  return false;
};
pp$1.regexp_groupSpecifier = function(state) {
  if (state.eat(
    63
    /* ? */
  )) {
    if (!this.regexp_eatGroupName(state)) {
      state.raise("Invalid group");
    }
    var trackDisjunction = this.options.ecmaVersion >= 16;
    var known = state.groupNames[state.lastStringValue];
    if (known) {
      if (trackDisjunction) {
        for (var i2 = 0, list2 = known; i2 < list2.length; i2 += 1) {
          var altID = list2[i2];
          if (!altID.separatedFrom(state.branchID)) {
            state.raise("Duplicate capture group name");
          }
        }
      } else {
        state.raise("Duplicate capture group name");
      }
    }
    if (trackDisjunction) {
      (known || (state.groupNames[state.lastStringValue] = [])).push(state.branchID);
    } else {
      state.groupNames[state.lastStringValue] = true;
    }
  }
};
pp$1.regexp_eatGroupName = function(state) {
  state.lastStringValue = "";
  if (state.eat(
    60
    /* < */
  )) {
    if (this.regexp_eatRegExpIdentifierName(state) && state.eat(
      62
      /* > */
    )) {
      return true;
    }
    state.raise("Invalid capture group name");
  }
  return false;
};
pp$1.regexp_eatRegExpIdentifierName = function(state) {
  state.lastStringValue = "";
  if (this.regexp_eatRegExpIdentifierStart(state)) {
    state.lastStringValue += codePointToString(state.lastIntValue);
    while (this.regexp_eatRegExpIdentifierPart(state)) {
      state.lastStringValue += codePointToString(state.lastIntValue);
    }
    return true;
  }
  return false;
};
pp$1.regexp_eatRegExpIdentifierStart = function(state) {
  var start = state.pos;
  var forceU = this.options.ecmaVersion >= 11;
  var ch = state.current(forceU);
  state.advance(forceU);
  if (ch === 92 && this.regexp_eatRegExpUnicodeEscapeSequence(state, forceU)) {
    ch = state.lastIntValue;
  }
  if (isRegExpIdentifierStart(ch)) {
    state.lastIntValue = ch;
    return true;
  }
  state.pos = start;
  return false;
};
function isRegExpIdentifierStart(ch) {
  return isIdentifierStart(ch, true) || ch === 36 || ch === 95;
}
pp$1.regexp_eatRegExpIdentifierPart = function(state) {
  var start = state.pos;
  var forceU = this.options.ecmaVersion >= 11;
  var ch = state.current(forceU);
  state.advance(forceU);
  if (ch === 92 && this.regexp_eatRegExpUnicodeEscapeSequence(state, forceU)) {
    ch = state.lastIntValue;
  }
  if (isRegExpIdentifierPart(ch)) {
    state.lastIntValue = ch;
    return true;
  }
  state.pos = start;
  return false;
};
function isRegExpIdentifierPart(ch) {
  return isIdentifierChar(ch, true) || ch === 36 || ch === 95 || ch === 8204 || ch === 8205;
}
pp$1.regexp_eatAtomEscape = function(state) {
  if (this.regexp_eatBackReference(state) || this.regexp_eatCharacterClassEscape(state) || this.regexp_eatCharacterEscape(state) || state.switchN && this.regexp_eatKGroupName(state)) {
    return true;
  }
  if (state.switchU) {
    if (state.current() === 99) {
      state.raise("Invalid unicode escape");
    }
    state.raise("Invalid escape");
  }
  return false;
};
pp$1.regexp_eatBackReference = function(state) {
  var start = state.pos;
  if (this.regexp_eatDecimalEscape(state)) {
    var n = state.lastIntValue;
    if (state.switchU) {
      if (n > state.maxBackReference) {
        state.maxBackReference = n;
      }
      return true;
    }
    if (n <= state.numCapturingParens) {
      return true;
    }
    state.pos = start;
  }
  return false;
};
pp$1.regexp_eatKGroupName = function(state) {
  if (state.eat(
    107
    /* k */
  )) {
    if (this.regexp_eatGroupName(state)) {
      state.backReferenceNames.push(state.lastStringValue);
      return true;
    }
    state.raise("Invalid named reference");
  }
  return false;
};
pp$1.regexp_eatCharacterEscape = function(state) {
  return this.regexp_eatControlEscape(state) || this.regexp_eatCControlLetter(state) || this.regexp_eatZero(state) || this.regexp_eatHexEscapeSequence(state) || this.regexp_eatRegExpUnicodeEscapeSequence(state, false) || !state.switchU && this.regexp_eatLegacyOctalEscapeSequence(state) || this.regexp_eatIdentityEscape(state);
};
pp$1.regexp_eatCControlLetter = function(state) {
  var start = state.pos;
  if (state.eat(
    99
    /* c */
  )) {
    if (this.regexp_eatControlLetter(state)) {
      return true;
    }
    state.pos = start;
  }
  return false;
};
pp$1.regexp_eatZero = function(state) {
  if (state.current() === 48 && !isDecimalDigit(state.lookahead())) {
    state.lastIntValue = 0;
    state.advance();
    return true;
  }
  return false;
};
pp$1.regexp_eatControlEscape = function(state) {
  var ch = state.current();
  if (ch === 116) {
    state.lastIntValue = 9;
    state.advance();
    return true;
  }
  if (ch === 110) {
    state.lastIntValue = 10;
    state.advance();
    return true;
  }
  if (ch === 118) {
    state.lastIntValue = 11;
    state.advance();
    return true;
  }
  if (ch === 102) {
    state.lastIntValue = 12;
    state.advance();
    return true;
  }
  if (ch === 114) {
    state.lastIntValue = 13;
    state.advance();
    return true;
  }
  return false;
};
pp$1.regexp_eatControlLetter = function(state) {
  var ch = state.current();
  if (isControlLetter(ch)) {
    state.lastIntValue = ch % 32;
    state.advance();
    return true;
  }
  return false;
};
function isControlLetter(ch) {
  return ch >= 65 && ch <= 90 || ch >= 97 && ch <= 122;
}
pp$1.regexp_eatRegExpUnicodeEscapeSequence = function(state, forceU) {
  if (forceU === void 0) forceU = false;
  var start = state.pos;
  var switchU = forceU || state.switchU;
  if (state.eat(
    117
    /* u */
  )) {
    if (this.regexp_eatFixedHexDigits(state, 4)) {
      var lead = state.lastIntValue;
      if (switchU && lead >= 55296 && lead <= 56319) {
        var leadSurrogateEnd = state.pos;
        if (state.eat(
          92
          /* \ */
        ) && state.eat(
          117
          /* u */
        ) && this.regexp_eatFixedHexDigits(state, 4)) {
          var trail = state.lastIntValue;
          if (trail >= 56320 && trail <= 57343) {
            state.lastIntValue = (lead - 55296) * 1024 + (trail - 56320) + 65536;
            return true;
          }
        }
        state.pos = leadSurrogateEnd;
        state.lastIntValue = lead;
      }
      return true;
    }
    if (switchU && state.eat(
      123
      /* { */
    ) && this.regexp_eatHexDigits(state) && state.eat(
      125
      /* } */
    ) && isValidUnicode(state.lastIntValue)) {
      return true;
    }
    if (switchU) {
      state.raise("Invalid unicode escape");
    }
    state.pos = start;
  }
  return false;
};
function isValidUnicode(ch) {
  return ch >= 0 && ch <= 1114111;
}
pp$1.regexp_eatIdentityEscape = function(state) {
  if (state.switchU) {
    if (this.regexp_eatSyntaxCharacter(state)) {
      return true;
    }
    if (state.eat(
      47
      /* / */
    )) {
      state.lastIntValue = 47;
      return true;
    }
    return false;
  }
  var ch = state.current();
  if (ch !== 99 && (!state.switchN || ch !== 107)) {
    state.lastIntValue = ch;
    state.advance();
    return true;
  }
  return false;
};
pp$1.regexp_eatDecimalEscape = function(state) {
  state.lastIntValue = 0;
  var ch = state.current();
  if (ch >= 49 && ch <= 57) {
    do {
      state.lastIntValue = 10 * state.lastIntValue + (ch - 48);
      state.advance();
    } while ((ch = state.current()) >= 48 && ch <= 57);
    return true;
  }
  return false;
};
var CharSetNone = 0;
var CharSetOk = 1;
var CharSetString = 2;
pp$1.regexp_eatCharacterClassEscape = function(state) {
  var ch = state.current();
  if (isCharacterClassEscape(ch)) {
    state.lastIntValue = -1;
    state.advance();
    return CharSetOk;
  }
  var negate = false;
  if (state.switchU && this.options.ecmaVersion >= 9 && ((negate = ch === 80) || ch === 112)) {
    state.lastIntValue = -1;
    state.advance();
    var result;
    if (state.eat(
      123
      /* { */
    ) && (result = this.regexp_eatUnicodePropertyValueExpression(state)) && state.eat(
      125
      /* } */
    )) {
      if (negate && result === CharSetString) {
        state.raise("Invalid property name");
      }
      return result;
    }
    state.raise("Invalid property name");
  }
  return CharSetNone;
};
function isCharacterClassEscape(ch) {
  return ch === 100 || ch === 68 || ch === 115 || ch === 83 || ch === 119 || ch === 87;
}
pp$1.regexp_eatUnicodePropertyValueExpression = function(state) {
  var start = state.pos;
  if (this.regexp_eatUnicodePropertyName(state) && state.eat(
    61
    /* = */
  )) {
    var name = state.lastStringValue;
    if (this.regexp_eatUnicodePropertyValue(state)) {
      var value = state.lastStringValue;
      this.regexp_validateUnicodePropertyNameAndValue(state, name, value);
      return CharSetOk;
    }
  }
  state.pos = start;
  if (this.regexp_eatLoneUnicodePropertyNameOrValue(state)) {
    var nameOrValue = state.lastStringValue;
    return this.regexp_validateUnicodePropertyNameOrValue(state, nameOrValue);
  }
  return CharSetNone;
};
pp$1.regexp_validateUnicodePropertyNameAndValue = function(state, name, value) {
  if (!hasOwn(state.unicodeProperties.nonBinary, name)) {
    state.raise("Invalid property name");
  }
  if (!state.unicodeProperties.nonBinary[name].test(value)) {
    state.raise("Invalid property value");
  }
};
pp$1.regexp_validateUnicodePropertyNameOrValue = function(state, nameOrValue) {
  if (state.unicodeProperties.binary.test(nameOrValue)) {
    return CharSetOk;
  }
  if (state.switchV && state.unicodeProperties.binaryOfStrings.test(nameOrValue)) {
    return CharSetString;
  }
  state.raise("Invalid property name");
};
pp$1.regexp_eatUnicodePropertyName = function(state) {
  var ch = 0;
  state.lastStringValue = "";
  while (isUnicodePropertyNameCharacter(ch = state.current())) {
    state.lastStringValue += codePointToString(ch);
    state.advance();
  }
  return state.lastStringValue !== "";
};
function isUnicodePropertyNameCharacter(ch) {
  return isControlLetter(ch) || ch === 95;
}
pp$1.regexp_eatUnicodePropertyValue = function(state) {
  var ch = 0;
  state.lastStringValue = "";
  while (isUnicodePropertyValueCharacter(ch = state.current())) {
    state.lastStringValue += codePointToString(ch);
    state.advance();
  }
  return state.lastStringValue !== "";
};
function isUnicodePropertyValueCharacter(ch) {
  return isUnicodePropertyNameCharacter(ch) || isDecimalDigit(ch);
}
pp$1.regexp_eatLoneUnicodePropertyNameOrValue = function(state) {
  return this.regexp_eatUnicodePropertyValue(state);
};
pp$1.regexp_eatCharacterClass = function(state) {
  if (state.eat(
    91
    /* [ */
  )) {
    var negate = state.eat(
      94
      /* ^ */
    );
    var result = this.regexp_classContents(state);
    if (!state.eat(
      93
      /* ] */
    )) {
      state.raise("Unterminated character class");
    }
    if (negate && result === CharSetString) {
      state.raise("Negated character class may contain strings");
    }
    return true;
  }
  return false;
};
pp$1.regexp_classContents = function(state) {
  if (state.current() === 93) {
    return CharSetOk;
  }
  if (state.switchV) {
    return this.regexp_classSetExpression(state);
  }
  this.regexp_nonEmptyClassRanges(state);
  return CharSetOk;
};
pp$1.regexp_nonEmptyClassRanges = function(state) {
  while (this.regexp_eatClassAtom(state)) {
    var left = state.lastIntValue;
    if (state.eat(
      45
      /* - */
    ) && this.regexp_eatClassAtom(state)) {
      var right = state.lastIntValue;
      if (state.switchU && (left === -1 || right === -1)) {
        state.raise("Invalid character class");
      }
      if (left !== -1 && right !== -1 && left > right) {
        state.raise("Range out of order in character class");
      }
    }
  }
};
pp$1.regexp_eatClassAtom = function(state) {
  var start = state.pos;
  if (state.eat(
    92
    /* \ */
  )) {
    if (this.regexp_eatClassEscape(state)) {
      return true;
    }
    if (state.switchU) {
      var ch$1 = state.current();
      if (ch$1 === 99 || isOctalDigit(ch$1)) {
        state.raise("Invalid class escape");
      }
      state.raise("Invalid escape");
    }
    state.pos = start;
  }
  var ch = state.current();
  if (ch !== 93) {
    state.lastIntValue = ch;
    state.advance();
    return true;
  }
  return false;
};
pp$1.regexp_eatClassEscape = function(state) {
  var start = state.pos;
  if (state.eat(
    98
    /* b */
  )) {
    state.lastIntValue = 8;
    return true;
  }
  if (state.switchU && state.eat(
    45
    /* - */
  )) {
    state.lastIntValue = 45;
    return true;
  }
  if (!state.switchU && state.eat(
    99
    /* c */
  )) {
    if (this.regexp_eatClassControlLetter(state)) {
      return true;
    }
    state.pos = start;
  }
  return this.regexp_eatCharacterClassEscape(state) || this.regexp_eatCharacterEscape(state);
};
pp$1.regexp_classSetExpression = function(state) {
  var result = CharSetOk, subResult;
  if (this.regexp_eatClassSetRange(state)) ;
  else if (subResult = this.regexp_eatClassSetOperand(state)) {
    if (subResult === CharSetString) {
      result = CharSetString;
    }
    var start = state.pos;
    while (state.eatChars(
      [38, 38]
      /* && */
    )) {
      if (state.current() !== 38 && (subResult = this.regexp_eatClassSetOperand(state))) {
        if (subResult !== CharSetString) {
          result = CharSetOk;
        }
        continue;
      }
      state.raise("Invalid character in character class");
    }
    if (start !== state.pos) {
      return result;
    }
    while (state.eatChars(
      [45, 45]
      /* -- */
    )) {
      if (this.regexp_eatClassSetOperand(state)) {
        continue;
      }
      state.raise("Invalid character in character class");
    }
    if (start !== state.pos) {
      return result;
    }
  } else {
    state.raise("Invalid character in character class");
  }
  for (; ; ) {
    if (this.regexp_eatClassSetRange(state)) {
      continue;
    }
    subResult = this.regexp_eatClassSetOperand(state);
    if (!subResult) {
      return result;
    }
    if (subResult === CharSetString) {
      result = CharSetString;
    }
  }
};
pp$1.regexp_eatClassSetRange = function(state) {
  var start = state.pos;
  if (this.regexp_eatClassSetCharacter(state)) {
    var left = state.lastIntValue;
    if (state.eat(
      45
      /* - */
    ) && this.regexp_eatClassSetCharacter(state)) {
      var right = state.lastIntValue;
      if (left !== -1 && right !== -1 && left > right) {
        state.raise("Range out of order in character class");
      }
      return true;
    }
    state.pos = start;
  }
  return false;
};
pp$1.regexp_eatClassSetOperand = function(state) {
  if (this.regexp_eatClassSetCharacter(state)) {
    return CharSetOk;
  }
  return this.regexp_eatClassStringDisjunction(state) || this.regexp_eatNestedClass(state);
};
pp$1.regexp_eatNestedClass = function(state) {
  var start = state.pos;
  if (state.eat(
    91
    /* [ */
  )) {
    var negate = state.eat(
      94
      /* ^ */
    );
    var result = this.regexp_classContents(state);
    if (state.eat(
      93
      /* ] */
    )) {
      if (negate && result === CharSetString) {
        state.raise("Negated character class may contain strings");
      }
      return result;
    }
    state.pos = start;
  }
  if (state.eat(
    92
    /* \ */
  )) {
    var result$1 = this.regexp_eatCharacterClassEscape(state);
    if (result$1) {
      return result$1;
    }
    state.pos = start;
  }
  return null;
};
pp$1.regexp_eatClassStringDisjunction = function(state) {
  var start = state.pos;
  if (state.eatChars(
    [92, 113]
    /* \q */
  )) {
    if (state.eat(
      123
      /* { */
    )) {
      var result = this.regexp_classStringDisjunctionContents(state);
      if (state.eat(
        125
        /* } */
      )) {
        return result;
      }
    } else {
      state.raise("Invalid escape");
    }
    state.pos = start;
  }
  return null;
};
pp$1.regexp_classStringDisjunctionContents = function(state) {
  var result = this.regexp_classString(state);
  while (state.eat(
    124
    /* | */
  )) {
    if (this.regexp_classString(state) === CharSetString) {
      result = CharSetString;
    }
  }
  return result;
};
pp$1.regexp_classString = function(state) {
  var count = 0;
  while (this.regexp_eatClassSetCharacter(state)) {
    count++;
  }
  return count === 1 ? CharSetOk : CharSetString;
};
pp$1.regexp_eatClassSetCharacter = function(state) {
  var start = state.pos;
  if (state.eat(
    92
    /* \ */
  )) {
    if (this.regexp_eatCharacterEscape(state) || this.regexp_eatClassSetReservedPunctuator(state)) {
      return true;
    }
    if (state.eat(
      98
      /* b */
    )) {
      state.lastIntValue = 8;
      return true;
    }
    state.pos = start;
    return false;
  }
  var ch = state.current();
  if (ch < 0 || ch === state.lookahead() && isClassSetReservedDoublePunctuatorCharacter(ch)) {
    return false;
  }
  if (isClassSetSyntaxCharacter(ch)) {
    return false;
  }
  state.advance();
  state.lastIntValue = ch;
  return true;
};
function isClassSetReservedDoublePunctuatorCharacter(ch) {
  return ch === 33 || ch >= 35 && ch <= 38 || ch >= 42 && ch <= 44 || ch === 46 || ch >= 58 && ch <= 64 || ch === 94 || ch === 96 || ch === 126;
}
function isClassSetSyntaxCharacter(ch) {
  return ch === 40 || ch === 41 || ch === 45 || ch === 47 || ch >= 91 && ch <= 93 || ch >= 123 && ch <= 125;
}
pp$1.regexp_eatClassSetReservedPunctuator = function(state) {
  var ch = state.current();
  if (isClassSetReservedPunctuator(ch)) {
    state.lastIntValue = ch;
    state.advance();
    return true;
  }
  return false;
};
function isClassSetReservedPunctuator(ch) {
  return ch === 33 || ch === 35 || ch === 37 || ch === 38 || ch === 44 || ch === 45 || ch >= 58 && ch <= 62 || ch === 64 || ch === 96 || ch === 126;
}
pp$1.regexp_eatClassControlLetter = function(state) {
  var ch = state.current();
  if (isDecimalDigit(ch) || ch === 95) {
    state.lastIntValue = ch % 32;
    state.advance();
    return true;
  }
  return false;
};
pp$1.regexp_eatHexEscapeSequence = function(state) {
  var start = state.pos;
  if (state.eat(
    120
    /* x */
  )) {
    if (this.regexp_eatFixedHexDigits(state, 2)) {
      return true;
    }
    if (state.switchU) {
      state.raise("Invalid escape");
    }
    state.pos = start;
  }
  return false;
};
pp$1.regexp_eatDecimalDigits = function(state) {
  var start = state.pos;
  var ch = 0;
  state.lastIntValue = 0;
  while (isDecimalDigit(ch = state.current())) {
    state.lastIntValue = 10 * state.lastIntValue + (ch - 48);
    state.advance();
  }
  return state.pos !== start;
};
function isDecimalDigit(ch) {
  return ch >= 48 && ch <= 57;
}
pp$1.regexp_eatHexDigits = function(state) {
  var start = state.pos;
  var ch = 0;
  state.lastIntValue = 0;
  while (isHexDigit(ch = state.current())) {
    state.lastIntValue = 16 * state.lastIntValue + hexToInt(ch);
    state.advance();
  }
  return state.pos !== start;
};
function isHexDigit(ch) {
  return ch >= 48 && ch <= 57 || ch >= 65 && ch <= 70 || ch >= 97 && ch <= 102;
}
function hexToInt(ch) {
  if (ch >= 65 && ch <= 70) {
    return 10 + (ch - 65);
  }
  if (ch >= 97 && ch <= 102) {
    return 10 + (ch - 97);
  }
  return ch - 48;
}
pp$1.regexp_eatLegacyOctalEscapeSequence = function(state) {
  if (this.regexp_eatOctalDigit(state)) {
    var n1 = state.lastIntValue;
    if (this.regexp_eatOctalDigit(state)) {
      var n2 = state.lastIntValue;
      if (n1 <= 3 && this.regexp_eatOctalDigit(state)) {
        state.lastIntValue = n1 * 64 + n2 * 8 + state.lastIntValue;
      } else {
        state.lastIntValue = n1 * 8 + n2;
      }
    } else {
      state.lastIntValue = n1;
    }
    return true;
  }
  return false;
};
pp$1.regexp_eatOctalDigit = function(state) {
  var ch = state.current();
  if (isOctalDigit(ch)) {
    state.lastIntValue = ch - 48;
    state.advance();
    return true;
  }
  state.lastIntValue = 0;
  return false;
};
function isOctalDigit(ch) {
  return ch >= 48 && ch <= 55;
}
pp$1.regexp_eatFixedHexDigits = function(state, length) {
  var start = state.pos;
  state.lastIntValue = 0;
  for (var i2 = 0; i2 < length; ++i2) {
    var ch = state.current();
    if (!isHexDigit(ch)) {
      state.pos = start;
      return false;
    }
    state.lastIntValue = 16 * state.lastIntValue + hexToInt(ch);
    state.advance();
  }
  return true;
};
var Token = function Token2(p) {
  this.type = p.type;
  this.value = p.value;
  this.start = p.start;
  this.end = p.end;
  if (p.options.locations) {
    this.loc = new SourceLocation(p, p.startLoc, p.endLoc);
  }
  if (p.options.ranges) {
    this.range = [p.start, p.end];
  }
};
var pp = Parser.prototype;
pp.next = function(ignoreEscapeSequenceInKeyword) {
  if (!ignoreEscapeSequenceInKeyword && this.type.keyword && this.containsEsc) {
    this.raiseRecoverable(this.start, "Escape sequence in keyword " + this.type.keyword);
  }
  if (this.options.onToken) {
    this.options.onToken(new Token(this));
  }
  this.lastTokEnd = this.end;
  this.lastTokStart = this.start;
  this.lastTokEndLoc = this.endLoc;
  this.lastTokStartLoc = this.startLoc;
  this.nextToken();
};
pp.getToken = function() {
  this.next();
  return new Token(this);
};
if (typeof Symbol !== "undefined") {
  pp[Symbol.iterator] = function() {
    var this$1$1 = this;
    return {
      next: function() {
        var token = this$1$1.getToken();
        return {
          done: token.type === types$1.eof,
          value: token
        };
      }
    };
  };
}
pp.nextToken = function() {
  var curContext = this.curContext();
  if (!curContext || !curContext.preserveSpace) {
    this.skipSpace();
  }
  this.start = this.pos;
  if (this.options.locations) {
    this.startLoc = this.curPosition();
  }
  if (this.pos >= this.input.length) {
    return this.finishToken(types$1.eof);
  }
  if (curContext.override) {
    return curContext.override(this);
  } else {
    this.readToken(this.fullCharCodeAtPos());
  }
};
pp.readToken = function(code) {
  if (isIdentifierStart(code, this.options.ecmaVersion >= 6) || code === 92) {
    return this.readWord();
  }
  return this.getTokenFromCode(code);
};
pp.fullCharCodeAt = function(pos) {
  var code = this.input.charCodeAt(pos);
  if (code <= 55295 || code >= 56320) {
    return code;
  }
  var next = this.input.charCodeAt(pos + 1);
  return next <= 56319 || next >= 57344 ? code : (code << 10) + next - 56613888;
};
pp.fullCharCodeAtPos = function() {
  return this.fullCharCodeAt(this.pos);
};
pp.skipBlockComment = function() {
  var startLoc = this.options.onComment && this.curPosition();
  var start = this.pos, end = this.input.indexOf("*/", this.pos += 2);
  if (end === -1) {
    this.raise(this.pos - 2, "Unterminated comment");
  }
  this.pos = end + 2;
  if (this.options.locations) {
    for (var nextBreak = void 0, pos = start; (nextBreak = nextLineBreak(this.input, pos, this.pos)) > -1; ) {
      ++this.curLine;
      pos = this.lineStart = nextBreak;
    }
  }
  if (this.options.onComment) {
    this.options.onComment(
      true,
      this.input.slice(start + 2, end),
      start,
      this.pos,
      startLoc,
      this.curPosition()
    );
  }
};
pp.skipLineComment = function(startSkip) {
  var start = this.pos;
  var startLoc = this.options.onComment && this.curPosition();
  var ch = this.input.charCodeAt(this.pos += startSkip);
  while (this.pos < this.input.length && !isNewLine(ch)) {
    ch = this.input.charCodeAt(++this.pos);
  }
  if (this.options.onComment) {
    this.options.onComment(
      false,
      this.input.slice(start + startSkip, this.pos),
      start,
      this.pos,
      startLoc,
      this.curPosition()
    );
  }
};
pp.skipSpace = function() {
  loop: while (this.pos < this.input.length) {
    var ch = this.input.charCodeAt(this.pos);
    switch (ch) {
      case 32:
      case 160:
        ++this.pos;
        break;
      case 13:
        if (this.input.charCodeAt(this.pos + 1) === 10) {
          ++this.pos;
        }
      case 10:
      case 8232:
      case 8233:
        ++this.pos;
        if (this.options.locations) {
          ++this.curLine;
          this.lineStart = this.pos;
        }
        break;
      case 47:
        switch (this.input.charCodeAt(this.pos + 1)) {
          case 42:
            this.skipBlockComment();
            break;
          case 47:
            this.skipLineComment(2);
            break;
          default:
            break loop;
        }
        break;
      default:
        if (ch > 8 && ch < 14 || ch >= 5760 && nonASCIIwhitespace.test(String.fromCharCode(ch))) {
          ++this.pos;
        } else {
          break loop;
        }
    }
  }
};
pp.finishToken = function(type, val) {
  this.end = this.pos;
  if (this.options.locations) {
    this.endLoc = this.curPosition();
  }
  var prevType = this.type;
  this.type = type;
  this.value = val;
  this.updateContext(prevType);
};
pp.readToken_dot = function() {
  var next = this.input.charCodeAt(this.pos + 1);
  if (next >= 48 && next <= 57) {
    return this.readNumber(true);
  }
  var next2 = this.input.charCodeAt(this.pos + 2);
  if (this.options.ecmaVersion >= 6 && next === 46 && next2 === 46) {
    this.pos += 3;
    return this.finishToken(types$1.ellipsis);
  } else {
    ++this.pos;
    return this.finishToken(types$1.dot);
  }
};
pp.readToken_slash = function() {
  var next = this.input.charCodeAt(this.pos + 1);
  if (this.exprAllowed) {
    ++this.pos;
    return this.readRegexp();
  }
  if (next === 61) {
    return this.finishOp(types$1.assign, 2);
  }
  return this.finishOp(types$1.slash, 1);
};
pp.readToken_mult_modulo_exp = function(code) {
  var next = this.input.charCodeAt(this.pos + 1);
  var size = 1;
  var tokentype = code === 42 ? types$1.star : types$1.modulo;
  if (this.options.ecmaVersion >= 7 && code === 42 && next === 42) {
    ++size;
    tokentype = types$1.starstar;
    next = this.input.charCodeAt(this.pos + 2);
  }
  if (next === 61) {
    return this.finishOp(types$1.assign, size + 1);
  }
  return this.finishOp(tokentype, size);
};
pp.readToken_pipe_amp = function(code) {
  var next = this.input.charCodeAt(this.pos + 1);
  if (next === code) {
    if (this.options.ecmaVersion >= 12) {
      var next2 = this.input.charCodeAt(this.pos + 2);
      if (next2 === 61) {
        return this.finishOp(types$1.assign, 3);
      }
    }
    return this.finishOp(code === 124 ? types$1.logicalOR : types$1.logicalAND, 2);
  }
  if (next === 61) {
    return this.finishOp(types$1.assign, 2);
  }
  return this.finishOp(code === 124 ? types$1.bitwiseOR : types$1.bitwiseAND, 1);
};
pp.readToken_caret = function() {
  var next = this.input.charCodeAt(this.pos + 1);
  if (next === 61) {
    return this.finishOp(types$1.assign, 2);
  }
  return this.finishOp(types$1.bitwiseXOR, 1);
};
pp.readToken_plus_min = function(code) {
  var next = this.input.charCodeAt(this.pos + 1);
  if (next === code) {
    if (next === 45 && !this.inModule && this.input.charCodeAt(this.pos + 2) === 62 && (this.lastTokEnd === 0 || lineBreak.test(this.input.slice(this.lastTokEnd, this.pos)))) {
      this.skipLineComment(3);
      this.skipSpace();
      return this.nextToken();
    }
    return this.finishOp(types$1.incDec, 2);
  }
  if (next === 61) {
    return this.finishOp(types$1.assign, 2);
  }
  return this.finishOp(types$1.plusMin, 1);
};
pp.readToken_lt_gt = function(code) {
  var next = this.input.charCodeAt(this.pos + 1);
  var size = 1;
  if (next === code) {
    size = code === 62 && this.input.charCodeAt(this.pos + 2) === 62 ? 3 : 2;
    if (this.input.charCodeAt(this.pos + size) === 61) {
      return this.finishOp(types$1.assign, size + 1);
    }
    return this.finishOp(types$1.bitShift, size);
  }
  if (next === 33 && code === 60 && !this.inModule && this.input.charCodeAt(this.pos + 2) === 45 && this.input.charCodeAt(this.pos + 3) === 45) {
    this.skipLineComment(4);
    this.skipSpace();
    return this.nextToken();
  }
  if (next === 61) {
    size = 2;
  }
  return this.finishOp(types$1.relational, size);
};
pp.readToken_eq_excl = function(code) {
  var next = this.input.charCodeAt(this.pos + 1);
  if (next === 61) {
    return this.finishOp(types$1.equality, this.input.charCodeAt(this.pos + 2) === 61 ? 3 : 2);
  }
  if (code === 61 && next === 62 && this.options.ecmaVersion >= 6) {
    this.pos += 2;
    return this.finishToken(types$1.arrow);
  }
  return this.finishOp(code === 61 ? types$1.eq : types$1.prefix, 1);
};
pp.readToken_question = function() {
  var ecmaVersion2 = this.options.ecmaVersion;
  if (ecmaVersion2 >= 11) {
    var next = this.input.charCodeAt(this.pos + 1);
    if (next === 46) {
      var next2 = this.input.charCodeAt(this.pos + 2);
      if (next2 < 48 || next2 > 57) {
        return this.finishOp(types$1.questionDot, 2);
      }
    }
    if (next === 63) {
      if (ecmaVersion2 >= 12) {
        var next2$1 = this.input.charCodeAt(this.pos + 2);
        if (next2$1 === 61) {
          return this.finishOp(types$1.assign, 3);
        }
      }
      return this.finishOp(types$1.coalesce, 2);
    }
  }
  return this.finishOp(types$1.question, 1);
};
pp.readToken_numberSign = function() {
  var ecmaVersion2 = this.options.ecmaVersion;
  var code = 35;
  if (ecmaVersion2 >= 13) {
    ++this.pos;
    code = this.fullCharCodeAtPos();
    if (isIdentifierStart(code, true) || code === 92) {
      return this.finishToken(types$1.privateId, this.readWord1());
    }
  }
  this.raise(this.pos, "Unexpected character '" + codePointToString(code) + "'");
};
pp.getTokenFromCode = function(code) {
  switch (code) {
    // The interpretation of a dot depends on whether it is followed
    // by a digit or another two dots.
    case 46:
      return this.readToken_dot();
    // Punctuation tokens.
    case 40:
      ++this.pos;
      return this.finishToken(types$1.parenL);
    case 41:
      ++this.pos;
      return this.finishToken(types$1.parenR);
    case 59:
      ++this.pos;
      return this.finishToken(types$1.semi);
    case 44:
      ++this.pos;
      return this.finishToken(types$1.comma);
    case 91:
      ++this.pos;
      return this.finishToken(types$1.bracketL);
    case 93:
      ++this.pos;
      return this.finishToken(types$1.bracketR);
    case 123:
      ++this.pos;
      return this.finishToken(types$1.braceL);
    case 125:
      ++this.pos;
      return this.finishToken(types$1.braceR);
    case 58:
      ++this.pos;
      return this.finishToken(types$1.colon);
    case 96:
      if (this.options.ecmaVersion < 6) {
        break;
      }
      ++this.pos;
      return this.finishToken(types$1.backQuote);
    case 48:
      var next = this.input.charCodeAt(this.pos + 1);
      if (next === 120 || next === 88) {
        return this.readRadixNumber(16);
      }
      if (this.options.ecmaVersion >= 6) {
        if (next === 111 || next === 79) {
          return this.readRadixNumber(8);
        }
        if (next === 98 || next === 66) {
          return this.readRadixNumber(2);
        }
      }
    // Anything else beginning with a digit is an integer, octal
    // number, or float.
    case 49:
    case 50:
    case 51:
    case 52:
    case 53:
    case 54:
    case 55:
    case 56:
    case 57:
      return this.readNumber(false);
    // Quotes produce strings.
    case 34:
    case 39:
      return this.readString(code);
    // Operators are parsed inline in tiny state machines. '=' (61) is
    // often referred to. `finishOp` simply skips the amount of
    // characters it is given as second argument, and returns a token
    // of the type given by its first argument.
    case 47:
      return this.readToken_slash();
    case 37:
    case 42:
      return this.readToken_mult_modulo_exp(code);
    case 124:
    case 38:
      return this.readToken_pipe_amp(code);
    case 94:
      return this.readToken_caret();
    case 43:
    case 45:
      return this.readToken_plus_min(code);
    case 60:
    case 62:
      return this.readToken_lt_gt(code);
    case 61:
    case 33:
      return this.readToken_eq_excl(code);
    case 63:
      return this.readToken_question();
    case 126:
      return this.finishOp(types$1.prefix, 1);
    case 35:
      return this.readToken_numberSign();
  }
  this.raise(this.pos, "Unexpected character '" + codePointToString(code) + "'");
};
pp.finishOp = function(type, size) {
  var str = this.input.slice(this.pos, this.pos + size);
  this.pos += size;
  return this.finishToken(type, str);
};
pp.readRegexp = function() {
  var escaped, inClass, start = this.pos;
  for (; ; ) {
    if (this.pos >= this.input.length) {
      this.raise(start, "Unterminated regular expression");
    }
    var ch = this.input.charAt(this.pos);
    if (lineBreak.test(ch)) {
      this.raise(start, "Unterminated regular expression");
    }
    if (!escaped) {
      if (ch === "[") {
        inClass = true;
      } else if (ch === "]" && inClass) {
        inClass = false;
      } else if (ch === "/" && !inClass) {
        break;
      }
      escaped = ch === "\\";
    } else {
      escaped = false;
    }
    ++this.pos;
  }
  var pattern = this.input.slice(start, this.pos);
  ++this.pos;
  var flagsStart = this.pos;
  var flags = this.readWord1();
  if (this.containsEsc) {
    this.unexpected(flagsStart);
  }
  var state = this.regexpState || (this.regexpState = new RegExpValidationState(this));
  state.reset(start, pattern, flags);
  this.validateRegExpFlags(state);
  this.validateRegExpPattern(state);
  var value = null;
  try {
    value = new RegExp(pattern, flags);
  } catch (e) {
  }
  return this.finishToken(types$1.regexp, { pattern, flags, value });
};
pp.readInt = function(radix, len, maybeLegacyOctalNumericLiteral) {
  var allowSeparators = this.options.ecmaVersion >= 12 && len === void 0;
  var isLegacyOctalNumericLiteral = maybeLegacyOctalNumericLiteral && this.input.charCodeAt(this.pos) === 48;
  var start = this.pos, total = 0, lastCode = 0;
  for (var i2 = 0, e = len == null ? Infinity : len; i2 < e; ++i2, ++this.pos) {
    var code = this.input.charCodeAt(this.pos), val = void 0;
    if (allowSeparators && code === 95) {
      if (isLegacyOctalNumericLiteral) {
        this.raiseRecoverable(this.pos, "Numeric separator is not allowed in legacy octal numeric literals");
      }
      if (lastCode === 95) {
        this.raiseRecoverable(this.pos, "Numeric separator must be exactly one underscore");
      }
      if (i2 === 0) {
        this.raiseRecoverable(this.pos, "Numeric separator is not allowed at the first of digits");
      }
      lastCode = code;
      continue;
    }
    if (code >= 97) {
      val = code - 97 + 10;
    } else if (code >= 65) {
      val = code - 65 + 10;
    } else if (code >= 48 && code <= 57) {
      val = code - 48;
    } else {
      val = Infinity;
    }
    if (val >= radix) {
      break;
    }
    lastCode = code;
    total = total * radix + val;
  }
  if (allowSeparators && lastCode === 95) {
    this.raiseRecoverable(this.pos - 1, "Numeric separator is not allowed at the last of digits");
  }
  if (this.pos === start || len != null && this.pos - start !== len) {
    return null;
  }
  return total;
};
function stringToNumber(str, isLegacyOctalNumericLiteral) {
  if (isLegacyOctalNumericLiteral) {
    return parseInt(str, 8);
  }
  return parseFloat(str.replace(/_/g, ""));
}
function stringToBigInt(str) {
  if (typeof BigInt !== "function") {
    return null;
  }
  return BigInt(str.replace(/_/g, ""));
}
pp.readRadixNumber = function(radix) {
  var start = this.pos;
  this.pos += 2;
  var val = this.readInt(radix);
  if (val == null) {
    this.raise(this.start + 2, "Expected number in radix " + radix);
  }
  if (this.options.ecmaVersion >= 11 && this.input.charCodeAt(this.pos) === 110) {
    val = stringToBigInt(this.input.slice(start, this.pos));
    ++this.pos;
  } else if (isIdentifierStart(this.fullCharCodeAtPos())) {
    this.raise(this.pos, "Identifier directly after number");
  }
  return this.finishToken(types$1.num, val);
};
pp.readNumber = function(startsWithDot) {
  var start = this.pos;
  if (!startsWithDot && this.readInt(10, void 0, true) === null) {
    this.raise(start, "Invalid number");
  }
  var octal = this.pos - start >= 2 && this.input.charCodeAt(start) === 48;
  if (octal && this.strict) {
    this.raise(start, "Invalid number");
  }
  var next = this.input.charCodeAt(this.pos);
  if (!octal && !startsWithDot && this.options.ecmaVersion >= 11 && next === 110) {
    var val$1 = stringToBigInt(this.input.slice(start, this.pos));
    ++this.pos;
    if (isIdentifierStart(this.fullCharCodeAtPos())) {
      this.raise(this.pos, "Identifier directly after number");
    }
    return this.finishToken(types$1.num, val$1);
  }
  if (octal && /[89]/.test(this.input.slice(start, this.pos))) {
    octal = false;
  }
  if (next === 46 && !octal) {
    ++this.pos;
    this.readInt(10);
    next = this.input.charCodeAt(this.pos);
  }
  if ((next === 69 || next === 101) && !octal) {
    next = this.input.charCodeAt(++this.pos);
    if (next === 43 || next === 45) {
      ++this.pos;
    }
    if (this.readInt(10) === null) {
      this.raise(start, "Invalid number");
    }
  }
  if (isIdentifierStart(this.fullCharCodeAtPos())) {
    this.raise(this.pos, "Identifier directly after number");
  }
  var val = stringToNumber(this.input.slice(start, this.pos), octal);
  return this.finishToken(types$1.num, val);
};
pp.readCodePoint = function() {
  var ch = this.input.charCodeAt(this.pos), code;
  if (ch === 123) {
    if (this.options.ecmaVersion < 6) {
      this.unexpected();
    }
    var codePos = ++this.pos;
    code = this.readHexChar(this.input.indexOf("}", this.pos) - this.pos);
    ++this.pos;
    if (code > 1114111) {
      this.invalidStringToken(codePos, "Code point out of bounds");
    }
  } else {
    code = this.readHexChar(4);
  }
  return code;
};
pp.readString = function(quote) {
  var out = "", chunkStart = ++this.pos;
  for (; ; ) {
    if (this.pos >= this.input.length) {
      this.raise(this.start, "Unterminated string constant");
    }
    var ch = this.input.charCodeAt(this.pos);
    if (ch === quote) {
      break;
    }
    if (ch === 92) {
      out += this.input.slice(chunkStart, this.pos);
      out += this.readEscapedChar(false);
      chunkStart = this.pos;
    } else if (ch === 8232 || ch === 8233) {
      if (this.options.ecmaVersion < 10) {
        this.raise(this.start, "Unterminated string constant");
      }
      ++this.pos;
      if (this.options.locations) {
        this.curLine++;
        this.lineStart = this.pos;
      }
    } else {
      if (isNewLine(ch)) {
        this.raise(this.start, "Unterminated string constant");
      }
      ++this.pos;
    }
  }
  out += this.input.slice(chunkStart, this.pos++);
  return this.finishToken(types$1.string, out);
};
var INVALID_TEMPLATE_ESCAPE_ERROR = {};
pp.tryReadTemplateToken = function() {
  this.inTemplateElement = true;
  try {
    this.readTmplToken();
  } catch (err) {
    if (err === INVALID_TEMPLATE_ESCAPE_ERROR) {
      this.readInvalidTemplateToken();
    } else {
      throw err;
    }
  }
  this.inTemplateElement = false;
};
pp.invalidStringToken = function(position, message) {
  if (this.inTemplateElement && this.options.ecmaVersion >= 9) {
    throw INVALID_TEMPLATE_ESCAPE_ERROR;
  } else {
    this.raise(position, message);
  }
};
pp.readTmplToken = function() {
  var out = "", chunkStart = this.pos;
  for (; ; ) {
    if (this.pos >= this.input.length) {
      this.raise(this.start, "Unterminated template");
    }
    var ch = this.input.charCodeAt(this.pos);
    if (ch === 96 || ch === 36 && this.input.charCodeAt(this.pos + 1) === 123) {
      if (this.pos === this.start && (this.type === types$1.template || this.type === types$1.invalidTemplate)) {
        if (ch === 36) {
          this.pos += 2;
          return this.finishToken(types$1.dollarBraceL);
        } else {
          ++this.pos;
          return this.finishToken(types$1.backQuote);
        }
      }
      out += this.input.slice(chunkStart, this.pos);
      return this.finishToken(types$1.template, out);
    }
    if (ch === 92) {
      out += this.input.slice(chunkStart, this.pos);
      out += this.readEscapedChar(true);
      chunkStart = this.pos;
    } else if (isNewLine(ch)) {
      out += this.input.slice(chunkStart, this.pos);
      ++this.pos;
      switch (ch) {
        case 13:
          if (this.input.charCodeAt(this.pos) === 10) {
            ++this.pos;
          }
        case 10:
          out += "\n";
          break;
        default:
          out += String.fromCharCode(ch);
          break;
      }
      if (this.options.locations) {
        ++this.curLine;
        this.lineStart = this.pos;
      }
      chunkStart = this.pos;
    } else {
      ++this.pos;
    }
  }
};
pp.readInvalidTemplateToken = function() {
  for (; this.pos < this.input.length; this.pos++) {
    switch (this.input[this.pos]) {
      case "\\":
        ++this.pos;
        break;
      case "$":
        if (this.input[this.pos + 1] !== "{") {
          break;
        }
      // fall through
      case "`":
        return this.finishToken(types$1.invalidTemplate, this.input.slice(this.start, this.pos));
      case "\r":
        if (this.input[this.pos + 1] === "\n") {
          ++this.pos;
        }
      // fall through
      case "\n":
      case "\u2028":
      case "\u2029":
        ++this.curLine;
        this.lineStart = this.pos + 1;
        break;
    }
  }
  this.raise(this.start, "Unterminated template");
};
pp.readEscapedChar = function(inTemplate) {
  var ch = this.input.charCodeAt(++this.pos);
  ++this.pos;
  switch (ch) {
    case 110:
      return "\n";
    // 'n' -> '\n'
    case 114:
      return "\r";
    // 'r' -> '\r'
    case 120:
      return String.fromCharCode(this.readHexChar(2));
    // 'x'
    case 117:
      return codePointToString(this.readCodePoint());
    // 'u'
    case 116:
      return "	";
    // 't' -> '\t'
    case 98:
      return "\b";
    // 'b' -> '\b'
    case 118:
      return "\v";
    // 'v' -> '\u000b'
    case 102:
      return "\f";
    // 'f' -> '\f'
    case 13:
      if (this.input.charCodeAt(this.pos) === 10) {
        ++this.pos;
      }
    // '\r\n'
    case 10:
      if (this.options.locations) {
        this.lineStart = this.pos;
        ++this.curLine;
      }
      return "";
    case 56:
    case 57:
      if (this.strict) {
        this.invalidStringToken(
          this.pos - 1,
          "Invalid escape sequence"
        );
      }
      if (inTemplate) {
        var codePos = this.pos - 1;
        this.invalidStringToken(
          codePos,
          "Invalid escape sequence in template string"
        );
      }
    default:
      if (ch >= 48 && ch <= 55) {
        var octalStr = this.input.substr(this.pos - 1, 3).match(/^[0-7]+/)[0];
        var octal = parseInt(octalStr, 8);
        if (octal > 255) {
          octalStr = octalStr.slice(0, -1);
          octal = parseInt(octalStr, 8);
        }
        this.pos += octalStr.length - 1;
        ch = this.input.charCodeAt(this.pos);
        if ((octalStr !== "0" || ch === 56 || ch === 57) && (this.strict || inTemplate)) {
          this.invalidStringToken(
            this.pos - 1 - octalStr.length,
            inTemplate ? "Octal literal in template string" : "Octal literal in strict mode"
          );
        }
        return String.fromCharCode(octal);
      }
      if (isNewLine(ch)) {
        if (this.options.locations) {
          this.lineStart = this.pos;
          ++this.curLine;
        }
        return "";
      }
      return String.fromCharCode(ch);
  }
};
pp.readHexChar = function(len) {
  var codePos = this.pos;
  var n = this.readInt(16, len);
  if (n === null) {
    this.invalidStringToken(codePos, "Bad character escape sequence");
  }
  return n;
};
pp.readWord1 = function() {
  this.containsEsc = false;
  var word = "", first = true, chunkStart = this.pos;
  var astral = this.options.ecmaVersion >= 6;
  while (this.pos < this.input.length) {
    var ch = this.fullCharCodeAtPos();
    if (isIdentifierChar(ch, astral)) {
      this.pos += ch <= 65535 ? 1 : 2;
    } else if (ch === 92) {
      this.containsEsc = true;
      word += this.input.slice(chunkStart, this.pos);
      var escStart = this.pos;
      if (this.input.charCodeAt(++this.pos) !== 117) {
        this.invalidStringToken(this.pos, "Expecting Unicode escape sequence \\uXXXX");
      }
      ++this.pos;
      var esc = this.readCodePoint();
      if (!(first ? isIdentifierStart : isIdentifierChar)(esc, astral)) {
        this.invalidStringToken(escStart, "Invalid Unicode escape");
      }
      word += codePointToString(esc);
      chunkStart = this.pos;
    } else {
      break;
    }
    first = false;
  }
  return word + this.input.slice(chunkStart, this.pos);
};
pp.readWord = function() {
  var word = this.readWord1();
  var type = types$1.name;
  if (this.keywords.test(word)) {
    type = keywords[word];
  }
  return this.finishToken(type, word);
};
var version = "8.18.0";
Parser.acorn = {
  Parser,
  version,
  defaultOptions,
  Position,
  SourceLocation,
  getLineInfo,
  Node,
  TokenType,
  tokTypes: types$1,
  keywordTypes: keywords,
  TokContext,
  tokContexts: types,
  isIdentifierChar,
  isIdentifierStart,
  Token,
  isNewLine,
  lineBreak,
  lineBreakG,
  nonASCIIwhitespace
};
function parse3(input, options) {
  return Parser.parse(input, options);
}

// ../../node_modules/acorn-walk/dist/walk.mjs
function fullAncestor(node, callback, baseVisitor, state) {
  if (!baseVisitor) {
    baseVisitor = base;
  }
  var ancestors = [], last;
  (function c(node2, st, override) {
    var type = override || node2.type;
    var isNew = node2 !== ancestors[ancestors.length - 1];
    if (isNew) {
      ancestors.push(node2);
    }
    visitNode(baseVisitor, type, node2, st, c);
    if (last !== node2) {
      callback(node2, st || ancestors, ancestors, type);
      last = node2;
    }
    if (isNew) {
      ancestors.pop();
    }
  })(node, state);
}
function skipThrough(node, st, c) {
  c(node, st);
}
function ignore(_node, _st, _c) {
}
function visitNode(baseVisitor, type, node, st, c) {
  if (baseVisitor[type] == null) {
    throw new Error("No walker function defined for node type " + type);
  }
  baseVisitor[type](node, st, c);
}
var base = {};
base.Program = base.BlockStatement = base.StaticBlock = function(node, st, c) {
  for (var i2 = 0, list2 = node.body; i2 < list2.length; i2 += 1) {
    var stmt = list2[i2];
    c(stmt, st, "Statement");
  }
};
base.Statement = skipThrough;
base.EmptyStatement = ignore;
base.ExpressionStatement = base.ParenthesizedExpression = base.ChainExpression = function(node, st, c) {
  return c(node.expression, st, "Expression");
};
base.IfStatement = function(node, st, c) {
  c(node.test, st, "Expression");
  c(node.consequent, st, "Statement");
  if (node.alternate) {
    c(node.alternate, st, "Statement");
  }
};
base.LabeledStatement = function(node, st, c) {
  return c(node.body, st, "Statement");
};
base.BreakStatement = base.ContinueStatement = ignore;
base.WithStatement = function(node, st, c) {
  c(node.object, st, "Expression");
  c(node.body, st, "Statement");
};
base.SwitchStatement = function(node, st, c) {
  c(node.discriminant, st, "Expression");
  for (var i2 = 0, list2 = node.cases; i2 < list2.length; i2 += 1) {
    var cs = list2[i2];
    c(cs, st);
  }
};
base.SwitchCase = function(node, st, c) {
  if (node.test) {
    c(node.test, st, "Expression");
  }
  for (var i2 = 0, list2 = node.consequent; i2 < list2.length; i2 += 1) {
    var cons = list2[i2];
    c(cons, st, "Statement");
  }
};
base.ReturnStatement = base.YieldExpression = base.AwaitExpression = function(node, st, c) {
  if (node.argument) {
    c(node.argument, st, "Expression");
  }
};
base.ThrowStatement = base.SpreadElement = function(node, st, c) {
  return c(node.argument, st, "Expression");
};
base.TryStatement = function(node, st, c) {
  c(node.block, st, "Statement");
  if (node.handler) {
    c(node.handler, st);
  }
  if (node.finalizer) {
    c(node.finalizer, st, "Statement");
  }
};
base.CatchClause = function(node, st, c) {
  if (node.param) {
    c(node.param, st, "Pattern");
  }
  c(node.body, st, "Statement");
};
base.WhileStatement = base.DoWhileStatement = function(node, st, c) {
  c(node.test, st, "Expression");
  c(node.body, st, "Statement");
};
base.ForStatement = function(node, st, c) {
  if (node.init) {
    c(node.init, st, "ForInit");
  }
  if (node.test) {
    c(node.test, st, "Expression");
  }
  if (node.update) {
    c(node.update, st, "Expression");
  }
  c(node.body, st, "Statement");
};
base.ForInStatement = base.ForOfStatement = function(node, st, c) {
  c(node.left, st, "ForInit");
  c(node.right, st, "Expression");
  c(node.body, st, "Statement");
};
base.ForInit = function(node, st, c) {
  if (node.type === "VariableDeclaration") {
    c(node, st);
  } else {
    c(node, st, "Expression");
  }
};
base.DebuggerStatement = ignore;
base.FunctionDeclaration = function(node, st, c) {
  return c(node, st, "Function");
};
base.VariableDeclaration = function(node, st, c) {
  for (var i2 = 0, list2 = node.declarations; i2 < list2.length; i2 += 1) {
    var decl = list2[i2];
    c(decl, st);
  }
};
base.VariableDeclarator = function(node, st, c) {
  c(node.id, st, "Pattern");
  if (node.init) {
    c(node.init, st, "Expression");
  }
};
base.Function = function(node, st, c) {
  if (node.id) {
    c(node.id, st, "Pattern");
  }
  for (var i2 = 0, list2 = node.params; i2 < list2.length; i2 += 1) {
    var param = list2[i2];
    c(param, st, "Pattern");
  }
  c(node.body, st, node.expression ? "Expression" : "Statement");
};
base.Pattern = function(node, st, c) {
  if (node.type === "Identifier") {
    c(node, st, "VariablePattern");
  } else if (node.type === "MemberExpression") {
    c(node, st, "MemberPattern");
  } else {
    c(node, st);
  }
};
base.VariablePattern = ignore;
base.MemberPattern = skipThrough;
base.RestElement = function(node, st, c) {
  return c(node.argument, st, "Pattern");
};
base.ArrayPattern = function(node, st, c) {
  for (var i2 = 0, list2 = node.elements; i2 < list2.length; i2 += 1) {
    var elt = list2[i2];
    if (elt) {
      c(elt, st, "Pattern");
    }
  }
};
base.ObjectPattern = function(node, st, c) {
  for (var i2 = 0, list2 = node.properties; i2 < list2.length; i2 += 1) {
    var prop = list2[i2];
    if (prop.type === "Property") {
      if (prop.computed) {
        c(prop.key, st, "Expression");
      }
      c(prop.value, st, "Pattern");
    } else if (prop.type === "RestElement") {
      c(prop.argument, st, "Pattern");
    }
  }
};
base.Expression = skipThrough;
base.ThisExpression = base.Super = base.MetaProperty = ignore;
base.ArrayExpression = function(node, st, c) {
  for (var i2 = 0, list2 = node.elements; i2 < list2.length; i2 += 1) {
    var elt = list2[i2];
    if (elt) {
      c(elt, st, "Expression");
    }
  }
};
base.ObjectExpression = function(node, st, c) {
  for (var i2 = 0, list2 = node.properties; i2 < list2.length; i2 += 1) {
    var prop = list2[i2];
    c(prop, st);
  }
};
base.FunctionExpression = base.ArrowFunctionExpression = base.FunctionDeclaration;
base.SequenceExpression = function(node, st, c) {
  for (var i2 = 0, list2 = node.expressions; i2 < list2.length; i2 += 1) {
    var expr = list2[i2];
    c(expr, st, "Expression");
  }
};
base.TemplateLiteral = function(node, st, c) {
  for (var i2 = 0, list2 = node.quasis; i2 < list2.length; i2 += 1) {
    var quasi = list2[i2];
    c(quasi, st);
  }
  for (var i$1 = 0, list$1 = node.expressions; i$1 < list$1.length; i$1 += 1) {
    var expr = list$1[i$1];
    c(expr, st, "Expression");
  }
};
base.TemplateElement = ignore;
base.UnaryExpression = base.UpdateExpression = function(node, st, c) {
  c(node.argument, st, "Expression");
};
base.BinaryExpression = base.LogicalExpression = function(node, st, c) {
  c(node.left, st, "Expression");
  c(node.right, st, "Expression");
};
base.AssignmentExpression = base.AssignmentPattern = function(node, st, c) {
  c(node.left, st, "Pattern");
  c(node.right, st, "Expression");
};
base.ConditionalExpression = function(node, st, c) {
  c(node.test, st, "Expression");
  c(node.consequent, st, "Expression");
  c(node.alternate, st, "Expression");
};
base.NewExpression = base.CallExpression = function(node, st, c) {
  c(node.callee, st, "Expression");
  if (node.arguments) {
    for (var i2 = 0, list2 = node.arguments; i2 < list2.length; i2 += 1) {
      var arg = list2[i2];
      c(arg, st, "Expression");
    }
  }
};
base.MemberExpression = function(node, st, c) {
  c(node.object, st, "Expression");
  if (node.computed) {
    c(node.property, st, "Expression");
  }
};
base.ExportNamedDeclaration = base.ExportDefaultDeclaration = function(node, st, c) {
  if (node.declaration) {
    c(node.declaration, st, node.type === "ExportNamedDeclaration" || node.declaration.id ? "Statement" : "Expression");
  }
  if (node.source) {
    c(node.source, st, "Expression");
  }
  if (node.attributes) {
    for (var i2 = 0, list2 = node.attributes; i2 < list2.length; i2 += 1) {
      var attr = list2[i2];
      c(attr, st);
    }
  }
};
base.ExportAllDeclaration = function(node, st, c) {
  if (node.exported) {
    c(node.exported, st);
  }
  c(node.source, st, "Expression");
  if (node.attributes) {
    for (var i2 = 0, list2 = node.attributes; i2 < list2.length; i2 += 1) {
      var attr = list2[i2];
      c(attr, st);
    }
  }
};
base.ImportAttribute = function(node, st, c) {
  c(node.value, st, "Expression");
};
base.ImportDeclaration = function(node, st, c) {
  for (var i2 = 0, list2 = node.specifiers; i2 < list2.length; i2 += 1) {
    var spec = list2[i2];
    c(spec, st);
  }
  c(node.source, st, "Expression");
  if (node.attributes) {
    for (var i$1 = 0, list$1 = node.attributes; i$1 < list$1.length; i$1 += 1) {
      var attr = list$1[i$1];
      c(attr, st);
    }
  }
};
base.ImportExpression = function(node, st, c) {
  c(node.source, st, "Expression");
  if (node.options) {
    c(node.options, st, "Expression");
  }
};
base.ImportSpecifier = base.ImportDefaultSpecifier = base.ImportNamespaceSpecifier = base.Identifier = base.PrivateIdentifier = base.Literal = ignore;
base.TaggedTemplateExpression = function(node, st, c) {
  c(node.tag, st, "Expression");
  c(node.quasi, st, "Expression");
};
base.ClassDeclaration = base.ClassExpression = function(node, st, c) {
  return c(node, st, "Class");
};
base.Class = function(node, st, c) {
  if (node.id) {
    c(node.id, st, "Pattern");
  }
  if (node.superClass) {
    c(node.superClass, st, "Expression");
  }
  c(node.body, st);
};
base.ClassBody = function(node, st, c) {
  for (var i2 = 0, list2 = node.body; i2 < list2.length; i2 += 1) {
    var elt = list2[i2];
    c(elt, st);
  }
};
base.MethodDefinition = base.PropertyDefinition = base.Property = function(node, st, c) {
  if (node.computed) {
    c(node.key, st, "Expression");
  }
  if (node.value) {
    c(node.value, st, "Expression");
  }
};

// ../../packages/evidence-engine/src/scanners/environment.ts
function entropy(value) {
  const counts = /* @__PURE__ */ new Map();
  for (const c of value) counts.set(c, (counts.get(c) || 0) + 1);
  return -[...counts.values()].reduce(
    (n, c) => n + c / value.length * Math.log2(c / value.length),
    0
  );
}
async function digest(value) {
  const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function scan(content, source, onValue) {
  const locations = [];
  const member2 = (n) => n?.type === "Identifier" ? n.name : n?.type === "MemberExpression" ? member2(n.object) + "." + (n.property.name || n.property.value) : "";
  try {
    const tree = parse3(content.slice(0, 2e6), {
      ecmaVersion: "latest",
      sourceType: "module",
      locations: true
    });
    fullAncestor(tree, (n, _s, ancestors) => {
      if (!["Property", "VariableDeclarator", "AssignmentExpression"].includes(n.type)) return;
      const value = n.value || n.init || n.right;
      if (value?.type !== "Literal" || typeof value.value !== "string") return;
      const names = ancestors.filter((a) => a.type === "Property").map((a) => a.key.name || a.key.value);
      const declaration = ancestors.find((a) => a.type === "VariableDeclarator");
      const assignment = ancestors.find((a) => a.type === "AssignmentExpression");
      const prefix = declaration?.id?.name || member2(assignment?.left);
      let path = names.length ? [prefix, ...names].filter(Boolean).join(".") : prefix;
      locations.push({
        start: n.start,
        end: n.end,
        line: n.loc.start.line,
        column: n.loc.start.column + 1,
        path
      });
    });
  } catch {
  }
  const results = [];
  const seen = /* @__PURE__ */ new Set();
  const assignments = /["']?([A-Za-z_][\w.-]{0,100})["']?\s*[:=]\s*["']([^"'\r\n]{4,500})["']/g;
  for (const match of content.slice(0, 2e6).matchAll(assignments)) {
    const key2 = match[1], value = match[2];
    if (!/(secret|password|token|key|public|api.?url|database|mongodb|postgres|client.?id)/i.test(key2))
      continue;
    if (/^(example|placeholder|changeme|your[_ -]|undefined|null|true|false)/i.test(value) || /\$\{|process\.env|import\.meta\.env/.test(value))
      continue;
    const provider = /^sk_(live|test|dummy)_[A-Za-z0-9]{16,}$/.test(value) ? "Stripe secret" : /^pk_(live|test)_/.test(value) ? "Stripe publishable" : /^(ghp_|github_pat_)[\w]{20,}$/.test(value) ? "GitHub" : /^AKIA[A-Z0-9]{16}$/.test(value) ? "AWS access identifier" : /AWS_SECRET_ACCESS_KEY/i.test(key2) && /^[\w/+]{40}$/.test(value) ? "AWS secret" : /^AIza[\w-]{35}$/.test(value) ? "Google browser API key" : "Generic";
    const hardSecret = ["Stripe secret", "GitHub", "AWS secret"].includes(provider) || /(?:^|_)(PRIVATE_KEY|JWT_SECRET|SESSION_SECRET|AWS_SECRET_ACCESS_KEY|STRIPE_SECRET_KEY)(?:$|_)/i.test(
      key2
    );
    const publicSignal = /^(NEXT_PUBLIC_|VITE_|REACT_APP_|PUBLIC_|EXPO_PUBLIC_)/i.test(key2) || /publishable|client.?id$/i.test(key2) || ["Stripe publishable", "Google browser API key", "AWS access identifier"].includes(provider);
    let publicUrl = false;
    try {
      publicUrl = /^https?:\/\//.test(value) && !new URL(value).password;
    } catch {
    }
    const score = entropy(value);
    const structured = provider !== "Generic";
    const secret = hardSecret || !publicSignal && !publicUrl && /(secret|password|token|key)/i.test(key2) && value.length >= 16 && score >= 3;
    const fingerprint = await digest(value);
    if (seen.has(`${key2}:${fingerprint}`)) continue;
    seen.add(`${key2}:${fingerprint}`);
    onValue?.({ key: key2, valueFingerprint: fingerprint, value });
    const prefix = value.length >= 12 ? value.slice(0, 3) : "", suffix = value.length >= 12 ? value.slice(-2) : "";
    results.push({
      key: key2,
      source,
      location: {
        scriptId: source,
        url: "",
        line: locations.find((n) => n.start <= match.index && n.end >= match.index)?.line || content.slice(0, match.index).split("\n").length,
        column: locations.find((n) => n.start <= match.index && n.end >= match.index)?.column || match.index - content.lastIndexOf("\n", match.index - 1),
        propertyPath: locations.find((n) => n.start <= match.index && n.end >= match.index)?.path || key2,
        method: locations.some((n) => n.start <= match.index && n.end >= match.index) ? "AST property location + value pattern" : "Text pattern location"
      },
      category: secret ? "Potential credential" : publicSignal || publicUrl ? "Browser-intended configuration" : "Unclassified pattern",
      provider,
      isSecret: secret,
      isLikelyPublic: !hardSecret && (publicSignal || publicUrl),
      confidence: secret && structured ? "High" : secret ? "Medium" : publicSignal || publicUrl ? "High" : "Low",
      entropyScore: Math.round(score * 100) / 100,
      valueFingerprint: fingerprint,
      length: value.length,
      prefix,
      suffix,
      valueRedacted: prefix ? `${prefix}\u2026${suffix} [${value.length} characters]` : "[REDACTED]",
      signals: [
        ...hardSecret ? ["secret key name or provider format"] : [],
        ...structured ? ["recognized format"] : [],
        ...publicSignal ? ["public context"] : [],
        `entropy ${score.toFixed(2)}`
      ]
    });
    if (results.length >= 100) break;
  }
  return results;
}
async function scanForSecrets(content, source) {
  return scan(content, source);
}
async function readSecretValues(content) {
  const values2 = [];
  await scan(content, "Live DOM inline scripts", (value) => values2.push(value));
  return values2;
}
async function scanScriptSecrets(scripts, url) {
  const results = [];
  let remaining = 2e6;
  for (const script of scripts.slice(0, 100)) {
    if (remaining <= 0 || results.length >= 100) break;
    const code = script.code.slice(0, remaining);
    remaining -= code.length;
    const found = await scanForSecrets(code, script.id);
    results.push(
      ...found.map((f) => ({
        ...f,
        location: f.location ? { ...f.location, scriptId: script.id, url } : void 0
      }))
    );
  }
  return results.slice(0, 100);
}

// ../../packages/evidence-engine/src/scanners/javascript.ts
var member = (n) => !n ? "" : n.type === "Identifier" ? n.name : n.type === "MemberExpression" ? `${member(n.object)}.${n.computed && n.property.type === "Literal" ? n.property.value : n.property.name}` : "";
var sourceName = (n) => {
  const m = member(n).replace(/^window\./, "");
  return /^(location\.(href|search|hash|pathname)|document\.(URL|referrer|cookie))$/.test(m) ? m : member(n) === "window.name" ? "window.name" : "";
};
function analyzeScripts(scripts) {
  const out = {
    apis: [],
    sources: [],
    flows: [],
    handlers: [],
    parsed: 0,
    failed: 0,
    limitation: "Static AST analysis of collected inline scripts only. Direct expressions and simple local aliases are traced; sanitization, runtime paths, interprocedural flows and exploitability are not established. External scripts are not fetched."
  };
  for (const script of scripts.slice(0, 100)) {
    if (script.code.length > 5e5) {
      out.failed++;
      continue;
    }
    let tree;
    try {
      tree = parse3(script.code, {
        ecmaVersion: "latest",
        sourceType: "module",
        locations: true,
        allowReturnOutsideFunction: true
      });
      out.parsed++;
    } catch {
      out.failed++;
      continue;
    }
    const taint = /* @__PURE__ */ new Map(), scriptVariables = /* @__PURE__ */ new Set();
    const scope = (ancestors) => ancestors.filter((a) => /Function/.test(a.type)).at(-1)?.start ?? 0;
    const messageParameters = /* @__PURE__ */ new Map();
    fullAncestor(tree, (n) => {
      const handler = n.type === "CallExpression" && member(n.callee).endsWith("addEventListener") && n.arguments[0]?.value === "message" ? n.arguments[1] : n.type === "AssignmentExpression" && /^(window\.)?onmessage$/.test(member(n.left)) ? n.right : void 0;
      if (handler?.params?.[0]?.type === "Identifier")
        messageParameters.set(handler.start, handler.params[0].name);
    });
    const observedSource = (node, s) => sourceName(node) || (messageParameters.has(s) && member(node) === `${messageParameters.get(s)}.data` ? "postMessage event.data" : "");
    const trace = (node, s, depth = 0) => {
      if (!node || depth > 15) return /* @__PURE__ */ new Set();
      const direct = observedSource(node, s);
      if (direct) return /* @__PURE__ */ new Set([direct]);
      if (node.type === "Identifier") return taint.get(`${s}:${node.name}`) || /* @__PURE__ */ new Set();
      if (node.type === "CallExpression" && /^(localStorage|sessionStorage)\.getItem$/.test(member(node.callee)))
        return /* @__PURE__ */ new Set([member(node.callee)]);
      if (node.type === "CallExpression" && /DOMPurify\.sanitize|trustedTypes\.createPolicy/.test(member(node.callee)))
        return /* @__PURE__ */ new Set();
      const result = /* @__PURE__ */ new Set();
      for (const [key2, value] of Object.entries(node)) {
        if (["loc", "start", "end"].includes(key2)) continue;
        for (const child of Array.isArray(value) ? value : [value])
          if (child && typeof child === "object" && "type" in child)
            for (const src of trace(child, s, depth + 1)) result.add(src);
      }
      return result;
    };
    fullAncestor(tree, (node, _state, ancestors) => {
      const s = scope(ancestors), line = node.loc?.start.line || 1;
      const src = observedSource(node, s);
      if (src && !out.sources.some((x) => x.name === src && x.scriptId === script.id && x.line === line))
        out.sources.push({ name: src, scriptId: script.id, line });
      if (node.type === "VariableDeclarator" && node.id.type === "Identifier") {
        taint.set(`${s}:${node.id.name}`, trace(node.init, s));
        if (node.init?.type === "CallExpression" && member(node.init.callee) === "document.createElement" && node.init.arguments[0]?.value === "script")
          scriptVariables.add(`${s}:${node.id.name}`);
      }
      if (node.type === "AssignmentExpression" && node.left.type === "Identifier")
        taint.set(`${s}:${node.left.name}`, trace(node.right, s));
      let sink = "", argument;
      if (node.type === "AssignmentExpression") {
        const name = member(node.left);
        if (/\.(innerHTML|outerHTML)$/.test(name)) sink = name.split(".").at(-1);
        else if (/(^|\.)location(\.(href|search|hash))?$/.test(name)) sink = "location assignment";
        else if (node.left.type === "MemberExpression" && node.left.property.name === "src" && scriptVariables.has(`${s}:${member(node.left.object)}`))
          sink = "script.src";
        argument = node.right;
      }
      if (node.type === "CallExpression" || node.type === "NewExpression") {
        const name = member(node.callee);
        if (["eval", "Function", "document.write", "document.writeln"].includes(name) || /\.insertAdjacentHTML$/.test(name) || /^(?:window\.)?location\.(assign|replace)$/.test(name))
          sink = name;
        else if (["setTimeout", "setInterval", "window.setTimeout", "window.setInterval"].includes(name) && ["Literal", "TemplateLiteral", "BinaryExpression"].includes(node.arguments[0]?.type) && typeof node.arguments[0]?.value !== "number")
          sink = `${name}(string)`;
        argument = /insertAdjacentHTML$/.test(name) ? node.arguments[1] : node.arguments[0];
        if (name.endsWith("addEventListener") && node.arguments[0]?.value === "message") {
          const handler = node.arguments[1], param = handler?.params?.[0]?.name;
          if (handler && param) {
            let originCheck = false, sourceCheck = false;
            fullAncestor(handler, (n) => {
              if (n.type === "BinaryExpression" && ["===", "==", "!==", "!="].includes(n.operator)) {
                const names = [member(n.left), member(n.right)];
                originCheck ||= names.includes(`${param}.origin`);
                sourceCheck ||= names.includes(`${param}.source`);
              }
            });
            out.handlers.push({
              scriptId: script.id,
              line,
              originCheck,
              sourceCheck,
              validation: originCheck || sourceCheck ? "pattern observed" : "not resolved"
            });
          } else
            out.handlers.push({
              scriptId: script.id,
              line,
              originCheck: false,
              sourceCheck: false,
              validation: "not resolved"
            });
        }
      }
      if (sink) {
        out.apis.push({ name: sink, scriptId: script.id, line });
        for (const source of trace(argument, s))
          out.flows.push({
            source,
            sink,
            scriptId: script.id,
            line,
            confidence: "medium",
            method: "Direct expression or simple lexical alias"
          });
      }
    });
  }
  out.apis = out.apis.slice(0, 300);
  out.sources = out.sources.slice(0, 300);
  out.flows = out.flows.slice(0, 150);
  out.handlers = out.handlers.slice(0, 100);
  return out;
}

// ../../packages/evidence-engine/src/scanners/source-maps.ts
async function inspectSourceMaps(urls, scope, request = fetch) {
  const budget = new RequestBudget(scope);
  const results = [];
  for (const raw of [...new Set(urls)].slice(0, 20)) {
    const record = {
      url: redactUrl(raw),
      status: "blocked",
      sources: [],
      secrets: [],
      provenance: {
        source: "extension-request",
        collector: "Scoped supplemental source-map reader"
      },
      limitation: "Explicit supplemental request; public accessibility does not establish sensitivity. Credentials omitted."
    };
    try {
      let url = raw, response;
      for (let hop = 0; hop < 5; hop++) {
        await budget.reserve(url);
        response = await request(url, {
          credentials: "omit",
          redirect: "manual",
          cache: "no-store",
          signal: AbortSignal.timeout(scope.timeoutMs)
        });
        if (response.status >= 300 && response.status < 400) {
          const location2 = response.headers.get("location");
          await response.body?.cancel();
          if (!location2) throw new Error("Redirect destination unavailable.");
          url = new URL(location2, url).href;
          if (!inScope(url, scope)) throw new Error("Redirect outside scope.");
          continue;
        }
        break;
      }
      if (!response?.ok) throw new Error("Map response unavailable.");
      const reader = response.body?.getReader();
      if (!reader) throw new Error("No response body.");
      const chunks = [];
      let size = 0;
      for (; ; ) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.length;
        if (size > scope.maxBytes) {
          await reader.cancel();
          throw new Error("Map exceeds the byte limit.");
        }
        chunks.push(value);
      }
      const bytes = new Uint8Array(size);
      let position = 0;
      for (const chunk of chunks) {
        bytes.set(chunk, position);
        position += chunk.length;
      }
      const map = JSON.parse(new TextDecoder().decode(bytes));
      if (map.version !== 3 || !Array.isArray(map.sources))
        throw new Error("Not a supported source map.");
      record.sources = map.sources.slice(0, 200).map((p) => text(p, 256).replace(/[?#].*$/, ""));
      const content = (Array.isArray(map.sourcesContent) ? map.sourcesContent : []).filter((s) => typeof s === "string").join("\n").slice(0, scope.maxBytes);
      record.secrets = await scanForSecrets(content, "Authorized source map");
      record.status = "inspected";
      record.provenance.statusCode = response.status;
    } catch (e) {
      record.limitation = e.message;
      record.status = inScope(raw, scope) ? "failed" : "blocked";
    }
    results.push(record);
  }
  return results;
}

// ../../packages/evidence-engine/src/index.ts
var EvidenceEngine = class {
  evidence = [];
  keys = /* @__PURE__ */ new Map();
  page;
  response;
  raw;
  technologies;
  constructor(raw, page, response, technologies) {
    this.raw = raw;
    this.page = page;
    this.response = response;
    this.technologies = technologies;
  }
  add(key2, type, label, data2, collectedAt = this.page.collectedAt, provenanceSource) {
    const id = `EV-${String(this.evidence.length + 1).padStart(3, "0")}`;
    this.keys.set(key2, id);
    const source = provenanceSource || (type === "header" ? this.response?.provenance?.source || "original-page-response" : ["cookie", "storage", "redirect"].includes(type) ? "browser-api" : type === "technology" ? "inference" : "dom");
    this.evidence.push({
      id,
      type,
      label,
      source: this.page.url,
      data: data2,
      redacted: true,
      collectedAt,
      provenance: {
        source,
        collector: this.raw.profile === "cli-browser" ? "SiteLens CLI browser" : "SiteLens Chromium extension",
        ...type === "header" && this.response ? {
          documentId: this.response.documentId,
          requestId: this.response.requestId,
          statusCode: this.response.statusCode
        } : {},
        limitation: source === "inference" ? "Heuristic association; not an independently established fact." : void 0
      }
    });
  }
  generateCoreEvidence() {
    this.add(
      "environment-secrets",
      "document",
      "Redacted configuration patterns",
      this.page.secrets || []
    );
    this.add("document", "document", "Document", {
      url: this.page.url,
      statusCode: this.response?.statusCode ?? "Unavailable",
      responseCaptured: !!this.response
    });
    const headerKeys = /* @__PURE__ */ new Set([
      ...Object.keys(this.response?.headers || {}),
      "content-security-policy",
      "content-security-policy-report-only",
      "strict-transport-security",
      "x-content-type-options",
      "referrer-policy",
      "x-frame-options",
      "permissions-policy",
      "cross-origin-opener-policy",
      "cross-origin-resource-policy",
      "cross-origin-embedder-policy",
      "server",
      "x-powered-by",
      "cache-control",
      "pragma",
      "vary",
      "access-control-allow-origin",
      "access-control-allow-credentials"
    ]);
    for (const key2 of headerKeys) {
      this.add(
        key2,
        "header",
        key2,
        {
          name: key2,
          values: this.response ? this.response.headers[key2] || [] : null,
          availability: this.response ? "captured" : "unavailable"
        },
        this.response?.collectedAt || this.page.collectedAt
      );
    }
    this.add("meta-csp", "document", "CSP meta policies", this.page.metaCsp);
    this.add("meta-referrer", "document", "Referrer meta policy", this.page.metaReferrer);
    this.add("resources", "resource", "Resource references", this.page.resources);
    this.add("forms", "form", "Declared forms", this.page.forms);
    this.add("frames", "frame", "Embedded frames", this.page.frames);
    this.add("links", "document", "New-window relationships", {
      withoutExplicitIsolation: this.page.blankLinks
    });
    this.add("cookies", "cookie", "Cookie attributes", {
      available: this.raw.cookies.available,
      limitation: this.raw.cookies.limitation,
      cookies: this.raw.cookies.cookies
    });
    this.add("storage", "storage", "Storage item counts", this.page.storage);
    this.add("technology", "technology", "Technology indicators", this.technologies);
    this.add(
      "client-security",
      "document",
      "Client-side AST observations",
      this.page.analysis || null,
      this.page.collectedAt,
      "inference"
    );
    this.add(
      "source-maps",
      "document",
      "Source map observations",
      this.page.sourceMaps || this.page.sourceMapUrls || []
    );
    this.add(
      "service-workers",
      "document",
      "Registered service workers",
      this.page.serviceWorkers || [],
      this.page.collectedAt,
      "browser-api"
    );
    this.add(
      "isolation",
      "document",
      "Runtime isolation",
      { crossOriginIsolated: this.page.crossOriginIsolated ?? null },
      this.page.collectedAt,
      "browser-api"
    );
    this.add(
      "cors",
      "header",
      "CORS relationships",
      {
        document: this.response ? {
          origin: this.response.headers["access-control-allow-origin"] || [],
          credentials: this.response.headers["access-control-allow-credentials"] || [],
          vary: this.response.headers.vary || []
        } : null,
        requests: this.raw.requests || []
      },
      this.response?.collectedAt || this.page.collectedAt,
      "intercepted-request"
    );
    this.add(
      "requests",
      "resource",
      "Observed browser requests",
      this.raw.requests || [],
      this.page.collectedAt,
      "intercepted-request"
    );
    this.add("active-probes", "document", "Active tests", {
      status: "unsupported",
      reason: "Active vulnerability probing is not implemented or performed."
    });
    this.add(
      "redirects",
      "redirect",
      "Observed redirects",
      {
        hops: this.response?.redirects || [],
        limitation: "Only permitted, selected-site hops are visible. This may not be the full redirect chain."
      },
      this.response?.collectedAt || this.page.collectedAt
    );
  }
  getEvidence() {
    return this.evidence;
  }
  getKeys() {
    return this.keys;
  }
};

// ../../packages/rule-definitions/src/governance.ts
var RULESET_VERSION = "2026.10.1";
function ruleVersion(check2) {
  return check2.version || "1.1.0";
}
function validateSuppression(value) {
  const s = value;
  if (!s || typeof s.checkId !== "string" || !/^SL-[A-Z]+-\d+$/.test(s.checkId) || typeof s.ruleVersion !== "string" || !s.rationale?.trim() || s.rationale.length > 2e3 || typeof s.actor !== "string" || !s.actor.trim() || !Number.isFinite(Date.parse(s.expiresAt)) || Date.parse(s.expiresAt) <= Date.now() || new URL(s.origin).origin !== s.origin)
    throw new Error(
      "An exception needs a rule, version, origin, rationale, analyst and future expiry."
    );
  return {
    ...s,
    id: s.id || crypto.randomUUID(),
    createdAt: s.createdAt || (/* @__PURE__ */ new Date()).toISOString()
  };
}
function suppressionFor(finding, origin, exceptions, now = Date.now()) {
  const exception = exceptions.find((e) => e.origin === origin && e.checkId === finding.checkId);
  if (!exception) return void 0;
  const expired = Date.parse(exception.expiresAt) <= now;
  const changed = exception.ruleVersion !== finding.ruleVersion;
  return {
    active: !expired && !changed && finding.status === "potential_weakness",
    reason: expired ? "Exception expired; review required." : changed ? "Rule version changed; exception needs re-evaluation." : "Approved exception; original observation and evidence retained.",
    exception
  };
}
function sameRule(before, after) {
  return (before.ruleVersion || "legacy") === (after.ruleVersion || "legacy");
}

// src/collector.ts
async function collectPage() {
  const limits = [];
  const cap = (items, max, label) => {
    if (items.length > max) limits.push(`${label}: ${max} of ${items.length} retained.`);
    return items.slice(0, max);
  };
  const resources = cap(
    [
      ...document.querySelectorAll(
        'script[src],link[rel="stylesheet"][href],link[rel="modulepreload"][href],link[rel="preload"][as="script"][href],img[src],video[src],audio[src],source[src]'
      )
    ],
    1e3,
    "DOM resources"
  ).map((el) => ({
    url: "src" in el ? el.src : el.href,
    type: el.tagName === "LINK" && ["modulepreload", "preload"].includes(el.rel) ? "script" : el.tagName.toLowerCase(),
    integrity: el.getAttribute("integrity"),
    crossorigin: el.getAttribute("crossorigin"),
    loadedBy: "Main document",
    observedBy: "DOM"
  }));
  const known = new Set(resources.map((r) => r.url));
  for (const e of cap(
    performance.getEntriesByType("resource"),
    1e3,
    "Resource timing"
  ))
    if (!known.has(e.name)) {
      known.add(e.name);
      resources.push({
        url: e.name,
        type: e.initiatorType || "resource",
        integrity: null,
        crossorigin: null,
        loadedBy: "Runtime / unspecified",
        observedBy: "Resource timing"
      });
    }
  const forms = cap([...document.forms], 200, "Forms").map((f) => ({
    action: f.action || location.href,
    method: f.method.toLowerCase(),
    password: !!f.querySelector('input[type="password"]')
  }));
  const frames = cap(
    [...document.querySelectorAll("iframe")],
    200,
    "Frames"
  ).map((f) => ({ url: f.src || "about:blank", sandbox: f.getAttribute("sandbox") }));
  const indicators = [];
  for (const [selector, name] of [
    ["[data-reactroot]", "React"],
    ["[ng-version]", "Angular"],
    ["[data-v-app]", "Vue.js"],
    ['[class*="svelte-"]', "Svelte"],
    ["#__next,#__NEXT_DATA__", "Next.js"],
    ["#__nuxt", "Nuxt.js"],
    ["html[data-wf-site]", "Webflow"],
    ['meta[name="generator"][content^="Gatsby" i],#___gatsby', "Gatsby"],
    ["[data-astro-cid]", "Astro"],
    ["[x-data][x-init],[x-data][x-show]", "Alpine.js"],
    ["[hx-get],[hx-post]", "HTMX"],
    ["svg.lucide", "Lucide"],
    ["html.lenis", "Lenis"],
    ["[data-projection-id]", "Framer Motion"],
    ['link[href*="/wp-content/plugins/woocommerce/"]', "WooCommerce"]
  ])
    if (document.querySelector(selector))
      indicators.push({
        name,
        layer: ["Lucide"].includes(name) ? "Icon libraries" : ["Lenis", "Framer Motion"].includes(name) ? "JavaScript libraries" : name === "Webflow" ? "Website builders" : name === "WooCommerce" ? "Commerce" : "Frontend",
        confidence: "medium",
        observation: `${selector} DOM marker observed.`,
        version: name === "Angular" ? document.querySelector("[ng-version]")?.getAttribute("ng-version")?.slice(0, 32) || "Unknown" : "Unknown",
        versionConfidence: name === "Angular" ? "high" : "low",
        versionSource: "DOM marker",
        signals: [
          {
            type: "dom",
            source: selector,
            observation: `${selector} DOM marker observed.`,
            confidence: "medium"
          }
        ]
      });
  let rulesRead = 0;
  const tailwindMarkers = /* @__PURE__ */ new Set();
  for (const sheet of [...document.styleSheets].slice(0, 30)) {
    try {
      const rules = [...sheet.cssRules];
      for (let n = 0; n < rules.length && rulesRead < 2e3; n++, rulesRead++) {
        const rule = rules[n];
        const text2 = rule.cssText.slice(0, 8e3);
        for (const m of text2.matchAll(
          /--tw-(?:translate|rotate|scale|ring|shadow|space|border|gradient|backdrop|blur|divide|inset)[\w-]*/g
        ))
          tailwindMarkers.add(m[0]);
        if ("cssRules" in rule)
          rules.push(...Array.from(rule.cssRules).slice(0, 2e3 - rulesRead));
      }
    } catch {
    }
    if (rulesRead >= 2e3) break;
  }
  if (tailwindMarkers.size >= 2)
    indicators.push({
      name: "Tailwind CSS",
      layer: "UI frameworks",
      confidence: "medium",
      version: "Unknown",
      observation: "Multiple Tailwind-specific --tw-* CSS custom-property names observed in readable stylesheet rules.",
      signals: [
        {
          type: "stylesheet",
          source: "Browser-readable CSS rules",
          observation: "Tailwind CSS custom-property marker families observed; stylesheet values are omitted.",
          confidence: "medium"
        }
      ]
    });
  let local = null, session = null;
  const keys = [];
  try {
    local = localStorage.length;
    for (let i2 = 0; i2 < Math.min(local, 200); i2++) {
      const k = localStorage.key(i2) || "";
      if (/token|jwt|session|auth|secret|credential/i.test(k)) keys.push("sensitive-name pattern");
    }
  } catch {
  }
  try {
    session = sessionStorage.length;
  } catch {
  }
  const inlineScripts = cap(
    [...document.querySelectorAll("script:not([src])")].filter(
      (s) => !s.getAttribute("type") || ["module", "text/javascript", "application/javascript"].includes(
        s.getAttribute("type") || ""
      )
    ),
    100,
    "Inline scripts"
  ).map((s, i2) => ({ id: `inline-${i2 + 1}`, code: (s.textContent || "").slice(0, 500001) }));
  const sourceMapUrls = [];
  for (const s of inlineScripts)
    for (const m of s.code.matchAll(/\/\/[#@]\s*sourceMappingURL=([^\s]+)/g))
      try {
        sourceMapUrls.push(new URL(m[1], location.href).href);
      } catch {
      }
  let serviceWorkers;
  try {
    serviceWorkers = (await navigator.serviceWorker.getRegistrations()).slice(0, 100).map((r) => ({
      scope: r.scope,
      scriptUrl: r.active?.scriptURL || r.waiting?.scriptURL || r.installing?.scriptURL || "",
      state: r.active?.state || r.waiting?.state || r.installing?.state || "unknown"
    }));
  } catch {
  }
  const nav = performance.getEntriesByType("navigation")[0];
  return {
    url: location.href,
    timeOrigin: performance.timeOrigin,
    resources,
    forms,
    frames,
    indicators,
    technologyMeta: [...document.querySelectorAll('meta[name="generator" i]')].slice(0, 10).map((m) => ({ name: "generator", content: m.content.slice(0, 256) })),
    metaCsp: cap(
      [...document.querySelectorAll("meta[http-equiv]")].filter((m) => m.httpEquiv.toLowerCase() === "content-security-policy").map((m) => m.content.slice(0, 16e3)),
      10,
      "Meta CSP"
    ),
    metaReferrer: document.querySelector('meta[name="referrer" i]')?.content.toLowerCase() || null,
    blankLinks: document.querySelectorAll(
      'a[target="_blank"]:not([rel~="noopener"]):not([rel~="noreferrer"])'
    ).length,
    storage: { local, session, keys },
    limits,
    windowKeys: Object.keys(window).slice(0, 5e3),
    collectedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inlineScripts,
    sourceMapUrls: sourceMapUrls.slice(0, 20),
    serviceWorkers,
    manifestUrl: document.querySelector('link[rel="manifest"]')?.href || null,
    crossOriginIsolated: window.crossOriginIsolated,
    performance: {
      fcp: performance.getEntriesByType("paint").find((p) => p.name === "first-contentful-paint")?.startTime || 0,
      domInteractive: nav?.domInteractive || 0,
      domComplete: nav?.domComplete || 0,
      loadEvent: nav?.loadEventEnd || 0
    }
  };
}

// src/technology-runtime.ts
function collectRuntimeTechnologies() {
  const technologies = [];
  const data2 = (path) => {
    let value = window;
    for (const key2 of path.split(".")) {
      if (!value || !["object", "function"].includes(typeof value)) return;
      const descriptor = Object.getOwnPropertyDescriptor(value, key2);
      if (!descriptor || !("value" in descriptor)) return;
      value = descriptor.value;
    }
    return value;
  };
  const add = (name, layer, path, version2) => technologies.push({
    name,
    layer,
    confidence: "medium",
    version: version2 || "Unknown",
    versionConfidence: version2 ? "high" : "low",
    versionSource: version2 ? "Runtime data property " + path : void 0,
    observation: `${path} runtime marker observed; page-supplied metadata can be imitated.`,
    signals: [
      {
        type: "runtime",
        source: path,
        observation: `${path} runtime data marker observed; no getter or library method invoked.`,
        confidence: "medium"
      }
    ]
  });
  for (const [name, layer, path] of [
    ["React", "Frontend", "React.version"],
    ["React Router", "Frontend", "__reactRouterVersion"],
    ["Lenis", "JavaScript libraries", "lenisVersion"],
    ["Lenis", "JavaScript libraries", "lenis.version"],
    ["GSAP", "JavaScript libraries", "gsap.version"],
    ["Vue.js", "Frontend", "Vue.version"],
    ["Firebase", "Client services", "firebase.SDK_VERSION"],
    ["Alpine.js", "Frontend", "Alpine.version"],
    ["HTMX", "Frontend", "htmx.version"]
  ]) {
    try {
      const value = data2(path);
      if (typeof value === "string" && /^\d+(?:\.\d+){1,3}(?:[-\w.]*)?$/.test(value) && value.length <= 32)
        add(name, layer, path, value);
    } catch {
    }
  }
  try {
    const versions = data2("gsapVersions");
    if (Array.isArray(versions)) {
      for (let i2 = 0; i2 < Math.min(versions.length, 5); i2++) {
        const descriptor = Object.getOwnPropertyDescriptor(versions, String(i2));
        const v = descriptor?.value;
        if (typeof v === "string" && /^\d+\.\d+\.\d+(?:[-\w.]*)?$/.test(v) && v.length <= 32)
          add("GSAP", "JavaScript libraries", "gsapVersions data array", v);
      }
    }
  } catch {
  }
  try {
    for (const el of [...document.querySelectorAll("*")].slice(0, 500)) {
      const keys = Object.getOwnPropertyNames(el);
      if (keys.some((k) => /^__(?:reactFiber|reactContainer|reactInternalInstance)\$/.test(k))) {
        add(
          "React",
          "Frontend",
          "React-owned DOM property prefix (__reactFiber$/__reactContainer$)"
        );
        break;
      }
    }
  } catch {
  }
  let windowKeys = [];
  try {
    windowKeys = Object.getOwnPropertyNames(window).slice(0, 5e3);
  } catch {
  }
  return {
    url: location.href,
    timeOrigin: performance.timeOrigin,
    technologies,
    windowKeys
  };
}

// ../../packages/technology-detector/src/bundles.ts
function detectBundleTechnologies(code, url) {
  const text2 = code.slice(0, 2e6), source = redactUrl(url), result = [];
  const add = (name, layer, marker, version2) => result.push({
    name,
    layer,
    confidence: "medium",
    version: version2 || "Unknown",
    versionConfidence: version2 ? "medium" : "low",
    versionSource: version2 ? "Static bundle declaration" : void 0,
    observation: `${name} static bundle fingerprint observed; inclusion does not establish execution.`,
    signals: [
      {
        type: "bundle",
        source,
        observation: marker + "; raw source omitted and runtime use unverified.",
        confidence: "medium"
      }
    ]
  });
  if (text2.includes("FirebaseError") && text2.includes("@firebase"))
    add("Firebase", "Client services", "Firebase SDK error type and package namespace");
  if (text2.includes("__reactRouterVersion"))
    add(
      "React Router",
      "Frontend",
      "React Router explicit version marker",
      text2.match(/__reactRouterVersion\s*=\s*["'](\d+\.\d+\.\d+)["']/)?.[1]
    );
  if (text2.includes("GreenSock") && text2.includes("gsapVersions"))
    add("GSAP", "JavaScript libraries", "GSAP registry and GreenSock identity markers");
  if (text2.includes("lenisVersion") && text2.includes("lenis-smooth"))
    add("Lenis", "JavaScript libraries", "Lenis runtime version and scrolling-class markers");
  if ((text2.includes("framer-motion") || text2.includes("MotionGlobalConfig")) && (text2.includes("data-projection-id") || text2.includes("motionValue")))
    add(
      "Framer Motion",
      "JavaScript libraries",
      "Motion package/configuration and projection/value markers"
    );
  if (text2.includes("createLucideIcon") && (text2.includes("lucide-") || text2.includes("lucide-react")) || text2.includes('"lucide"') && text2.includes("lucide-") && text2.includes("strokeWidth"))
    add("Lucide", "Icon libraries", "Lucide SVG factory and icon-class namespace");
  if (text2.includes("react.transitional.element") && text2.includes("react.fragment"))
    add("React", "Frontend", "React element and fragment symbol markers");
  return result;
}

// ../../packages/rule-definitions/src/rules/environment.ts
var secretExposureCheck = {
  id: "SL-SECRET-001",
  version: "2.0.0",
  name: "Potential client-visible credentials",
  category: "Information exposure",
  severity: "high",
  method: "Combine assignment key, value format, entropy, provider and public context; retain SHA-256 and short previews only.",
  impact: "An exposed usable credential may grant unintended access.",
  limitation: "Validity, permissions and runtime usability are unknown. Public browser keys are distinguished from secret formats. External bundles are not fetched.",
  recommendation: "Investigate high-confidence credential patterns. Rotate confirmed exposed credentials and remove private configuration from client builds.",
  learning: "A public prefix is a clue, not permission to expose a private credential. Provider secret formats take precedence over public naming.",
  references: [
    "https://cheatsheetseries.owasp.org/cheatsheets/Secrets_Management_Cheat_Sheet.html"
  ],
  run: (i2) => {
    const matches = i2.page.secrets || [];
    const risky = matches.filter((s) => s.isSecret && s.confidence !== "Low");
    return {
      status: risky.length ? "potential_weakness" : "informational",
      confidence: risky.some((s) => s.confidence === "High") ? "high" : risky.length ? "medium" : "low",
      observation: `${risky.length} potential credentials and ${matches.filter((s) => s.isLikelyPublic).length} public-context configurations observed. Credentials were not validated; complete values are not retained.`,
      evidenceKeys: ["environment-secrets"]
    };
  }
};

// ../../packages/rule-definitions/src/policies.ts
function parseCsp(value) {
  const directives = /* @__PURE__ */ new Map();
  for (const part of value.split(";")) {
    const [name, ...tokens] = part.trim().split(/\s+/);
    if (name && !directives.has(name.toLowerCase())) directives.set(name.toLowerCase(), tokens);
  }
  return directives;
}
function policies(values2) {
  return values2.flatMap((v) => v.split(",")).filter((v) => v.trim()).map(parseCsp);
}
function sources(policy, directive) {
  return policy.get(directive) ?? policy.get("default-src");
}
function positiveHsts(value) {
  return /(?:^|;)\s*max-age\s*=\s*"?[1-9]\d*"?\s*(?:;|$)/i.test(value);
}
function sriValid(value) {
  return value.trim().split(/\s+/).some((v) => /^sha(?:256|384|512)-[A-Za-z0-9+/]+={0,2}(?:\?\S+)?$/.test(v));
}
function restrictiveAncestors(tokens) {
  return tokens.length > 0 && !tokens.includes("*") && !tokens.some((t) => /^(https?:|https?:\/\/\*)$/.test(t)) && tokens.every((t) => t === "'none'" || t === "'self'" || /^https?:\/\/[^\s]+$/.test(t));
}

// ../../packages/rule-definitions/src/rules/modern.ts
var base2 = {
  version: "1.0.0",
  category: "Modern browser security",
  severity: "low",
  impact: "Explicit browser policy can reduce accidental exposure in applicable contexts.",
  limitation: "Configuration patterns are contextual; browser support, policy intersections and runtime applicability require review.",
  recommendation: "Review this policy with the application owner and test compatibility.",
  learning: "Presence and syntax are observations; enforcement and exploitability are separate questions.",
  references: [
    "https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Content-Security-Policy"
  ]
};
var modernChecks = [
  {
    ...base2,
    id: "SL-CSP-008",
    name: "Script attribute restrictions",
    method: "Inspect script-src-attr or its script/default fallback.",
    run: (i2) => {
      const p = policies([
        ...i2.response?.headers["content-security-policy"] || [],
        ...i2.page.metaCsp
      ]);
      return {
        status: !p.length ? "unable_to_assess" : p.some(
          (p2) => (p2.get("script-src-attr") ?? p2.get("script-src") ?? p2.get("default-src") ?? []).includes("'unsafe-inline'")
        ) ? "potential_weakness" : "informational",
        observation: "Script attribute directive and fallback reviewed. Nonce/hash and unsafe-hashes interactions require contextual review.",
        evidenceKeys: ["content-security-policy", "meta-csp"]
      };
    }
  },
  {
    ...base2,
    id: "SL-CSP-009",
    name: "Extended CSP directive inventory",
    method: "Inventory modern fetch, navigation, reporting and Trusted Types directives.",
    run: (i2) => ({
      status: "informational",
      observation: policies([...i2.response?.headers["content-security-policy"] || [], ...i2.page.metaCsp]).map((p) => [...p.keys()].join(", ")).join(" | ") || "No enforced policy available. Unsupported directives such as navigate-to are not assumed effective.",
      evidenceKeys: ["content-security-policy", "meta-csp"]
    })
  },
  {
    ...base2,
    id: "SL-CSP-010",
    name: "Nonce, hash and strict-dynamic patterns",
    method: "Inspect redacted source tokens; no nonce values are retained.",
    run: (i2) => {
      const p = policies([
        ...i2.response?.headers["content-security-policy"] || [],
        ...i2.page.metaCsp
      ]);
      const scripts = p.flatMap((p2) => p2.get("script-src") || []);
      return {
        status: "informational",
        observation: `Nonce tokens: ${scripts.filter((t) => t.startsWith("'nonce-")).length}; hash tokens: ${scripts.filter((t) => /^'sha(256|384|512)-/.test(t)).length}; strict-dynamic: ${scripts.includes("'strict-dynamic'") ? "observed" : "not observed"}.`,
        evidenceKeys: ["content-security-policy", "meta-csp"]
      };
    }
  },
  {
    ...base2,
    id: "SL-PWA-001",
    name: "Service worker and PWA scope",
    method: "Read same-origin registered service worker metadata without enumerating cache contents.",
    run: (i2) => ({
      status: i2.page.serviceWorkers ? "informational" : "unable_to_assess",
      observation: `${i2.page.serviceWorkers?.length || 0} service worker registrations observed. Cached body sensitivity and session invalidation are not assessed.`,
      evidenceKeys: ["service-workers"]
    })
  },
  {
    ...base2,
    id: "SL-CACHE-001",
    name: "Document cache policy",
    category: "Session observations",
    method: "Inspect captured Cache-Control and Pragma in authentication-like document context.",
    run: (i2) => {
      const cache = i2.response?.headers["cache-control"] || [];
      const sensitive = i2.page.forms.some((f) => f.password) || i2.cookies.cookies.some((c) => /(session|auth|token)/i.test(c.name));
      return {
        status: !i2.response ? "unable_to_assess" : sensitive && cache.some((c) => /(?:^|,)\s*public(?:,|$)/i.test(c)) ? "potential_weakness" : "informational",
        observation: `Cache policy: ${cache.join(", ") || "not observed"}. Sensitivity is ${sensitive ? "heuristically suggested" : "unknown"}; cache contents and user-specific response variation were not inspected.`,
        evidenceKeys: ["cache-control", "forms", "cookies"]
      };
    }
  },
  {
    ...base2,
    id: "SL-ISOLATION-001",
    name: "Runtime cross-origin isolation",
    method: "Read crossOriginIsolated from the selected document.",
    run: (i2) => ({
      status: i2.page.crossOriginIsolated === true ? "protection_observed" : typeof i2.page.crossOriginIsolated === "boolean" ? "informational" : "unable_to_assess",
      observation: `crossOriginIsolated: ${i2.page.crossOriginIsolated ?? "unknown"}. Lack of isolation is not a general vulnerability.`,
      evidenceKeys: ["isolation"]
    })
  }
];

// ../../packages/rule-definitions/src/rules/probing.ts
var activeProbingCheck = {
  id: "SL-PROBE-001",
  name: "Active testing coverage",
  category: "Configuration",
  severity: "informational",
  method: "Record that active testing is outside this release.",
  impact: "Passive browser observations cannot establish whether sensitive files or exploitable vulnerabilities exist.",
  limitation: "No probes, attack payloads, authentication attacks or exploit confirmation are performed.",
  recommendation: "Use a separately scoped authorized security assessment when active testing is required.",
  learning: "Passive inspection and active testing have different collection methods and authorization requirements.",
  references: ["https://owasp.org/www-project-web-security-testing-guide/"],
  run: () => ({
    status: "unable_to_assess",
    observation: "Active testing is unsupported. No paths were probed.",
    evidenceKeys: ["active-probes"]
  })
};

// ../../packages/rule-definitions/src/rules/storage.ts
var storageSecurityCheck = {
  id: "SL-STORAGE-002",
  version: "2.0.0",
  name: "Browser storage sensitivity patterns",
  category: "Storage",
  severity: "informational",
  method: "Count local-storage entries and redacted sensitive-name patterns; omit keys and values.",
  impact: "Script-readable storage may hold sensitive data. A name pattern does not establish that credentials are present or exposed.",
  limitation: "Values and actual keys are not retained. Application purpose, token validity and XSS exploitability remain unknown.",
  recommendation: "Review sensitive storage with the application owner. Consider HttpOnly cookies for suitable server-managed sessions and the associated CSRF controls.",
  learning: "Local storage is script-readable and has no HttpOnly attribute. Storage security depends on the data, application design and script execution context.",
  references: [
    "https://cheatsheetseries.owasp.org/cheatsheets/HTML5_Security_Cheat_Sheet.html#local-storage"
  ],
  run: (i2) => ({
    status: i2.page.storage.local === null ? "unable_to_assess" : i2.page.storage.local === 0 ? "not_applicable" : "informational",
    confidence: "low",
    observation: i2.page.storage.local === null ? "Local-storage metadata could not be read." : `${i2.page.storage.local} local-storage entries; ${i2.page.storage.keys?.length || 0} redacted sensitive-name patterns. Values and actual names omitted.`,
    evidenceKeys: ["storage"]
  })
};

// ../../packages/rule-definitions/src/rules/tech.ts
var techVulnerabilityCheck = {
  id: "SL-TECH-002",
  version: "2.0.0",
  name: "Dependency advisory applicability",
  category: "Dependencies",
  severity: "medium",
  method: "Match exact package versions to supplied dated advisory affected ranges.",
  impact: "A component version in an advisory range may require dependency review.",
  limitation: "Runtime reachability and exploitability remain unknown. Without an exact version and authoritative advisory data, no vulnerable-version assertion is made.",
  recommendation: "Use a current advisory dataset and confirm exact component versions and runtime applicability.",
  learning: "A version-range match is not a confirmed exploit. Unknown or inferred major versions must not be treated as exact versions.",
  references: ["https://osv.dev/docs/"],
  run: (i2) => ({
    status: "informational",
    observation: `${i2.page.indicators.filter((t) => /^\d+\.\d+\.\d+$/.test(t.version)).length} exact-looking version indicators; advisories require independent version confidence and authoritative range data.`,
    evidenceKeys: ["technology"]
  })
};

// ../../packages/rule-definitions/src/rules/clientside.ts
var base3 = {
  category: "Client-Side Security",
  severity: "medium",
  version: "2.0.0",
  impact: "An externally influenced value reaching a code or HTML execution API may require review.",
  limitation: "Static inline-script analysis does not confirm an executable path, failed sanitization or exploitability. External script contents are not inspected.",
  recommendation: "Review observed source-to-sink expressions; prefer safe APIs, validated messages and contextual sanitization.",
  learning: "API presence, a potential source-to-sink relationship, and a confirmed exploit are different levels of evidence. SiteLens does not confirm exploits.",
  references: ["https://developer.mozilla.org/en-US/docs/Web/API/Element/innerHTML"]
};
var clientSideSinkCheck = {
  ...base3,
  id: "SL-JSDOM-001",
  name: "Dangerous API observations",
  method: "Parse inline scripts into an AST and locate selected assignments and calls.",
  run: (i2) => ({
    status: i2.page.analysis ? "informational" : "unable_to_assess",
    observation: i2.page.analysis ? `${i2.page.analysis.apis.length} API patterns observed; absence is not a protection claim.` : "JavaScript analysis was not collected.",
    evidenceKeys: ["client-security"]
  })
};
var clientSideFlowCheck = {
  ...base3,
  id: "SL-JSDOM-002",
  name: "Potential source-to-sink expressions",
  method: "Trace direct expressions and simple lexical variable aliases in collected inline scripts.",
  run: (i2) => ({
    status: !i2.page.analysis ? "unable_to_assess" : i2.page.analysis.flows.length ? "potential_weakness" : "informational",
    confidence: "medium",
    observation: i2.page.analysis ? `${i2.page.analysis.flows.length} potential direct source-to-sink relationships observed. No exploitability confirmed.` : "JavaScript analysis was not collected.",
    evidenceKeys: ["client-security"]
  })
};
var postMessageCheck = {
  ...base3,
  id: "SL-JSDOM-003",
  name: "postMessage validation observations",
  method: "Inspect AST event listener callbacks for origin and source comparison patterns.",
  run: (i2) => ({
    status: i2.page.analysis ? "informational" : "unable_to_assess",
    confidence: "low",
    observation: i2.page.analysis ? `${i2.page.analysis.handlers.length} message handlers; ${i2.page.analysis.handlers.filter((h) => !h.originCheck).length} without a resolved origin comparison. Pattern presence does not establish validation correctness.` : "Message handlers were not collected.",
    evidenceKeys: ["client-security"]
  })
};
var sourceMapCheck = {
  ...base3,
  id: "SL-SRCMAP-001",
  name: "Source map references",
  category: "Information exposure",
  method: "Observe sourceMappingURL references; inspect contents only under explicitly authorized supplemental scope.",
  impact: "Source maps may expose original source structure and accidental configuration. They are legitimate debugging artifacts.",
  recommendation: "Review intended exposure and inspect public map contents for accidental sensitive data.",
  run: (i2) => ({
    status: "informational",
    observation: `${i2.page.sourceMaps?.length || i2.page.sourceMapUrls?.length || 0} source map references; accessibility and sensitivity are not inferred from presence.`,
    evidenceKeys: ["source-maps"]
  })
};

// ../../packages/rule-definitions/src/rules/crossorigin.ts
var base4 = {
  category: "Cross-Origin & Isolation",
  severity: "informational",
  version: "2.0.0",
  method: "Inspect actual response header values, without issuing cross-origin tests.",
  impact: "Browser policies can control cross-origin sharing and browsing context isolation.",
  limitation: "Header observations do not establish access to sensitive data or exploitable behavior. Absence may be appropriate.",
  recommendation: "Review policy applicability and integration compatibility.",
  learning: "Cross-origin sharing and cross-origin isolation have different purposes.",
  references: ["https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/CORS"]
};
var isolation = (id, name, key2, accepted) => ({
  ...base4,
  id,
  name,
  run: (i2) => {
    const values2 = i2.response?.headers[key2] || [];
    return {
      status: !i2.response ? "unable_to_assess" : values2.some((v) => accepted.includes(v.split(";")[0].trim())) ? "protection_observed" : "informational",
      observation: values2.length ? `${name}: ${values2.join(", ")}. Applicability remains contextual.` : `${name} not observed; absence is not a general vulnerability.`,
      evidenceKeys: [key2]
    };
  }
});
var coopCheck = isolation(
  "SL-COOP-001",
  "Cross-origin opener policy",
  "cross-origin-opener-policy",
  ["same-origin", "same-origin-allow-popups", "noopener-allow-popups"]
);
var coepCheck = isolation(
  "SL-COEP-001",
  "Cross-origin embedder policy",
  "cross-origin-embedder-policy",
  ["require-corp", "credentialless"]
);
var corpCheck = isolation(
  "SL-CORP-001",
  "Cross-origin resource policy",
  "cross-origin-resource-policy",
  ["same-origin", "same-site"]
);
var corsCheck = {
  ...base4,
  id: "SL-CORS-001",
  name: "CORS response and credential relationships",
  run: (i2) => {
    if (!i2.response)
      return {
        status: "unable_to_assess",
        observation: "Response headers unavailable.",
        evidenceKeys: ["cors"]
      };
    const observed = [
      i2.response,
      ...(i2.requests || []).filter((r) => r.headers["access-control-allow-origin"])
    ];
    const conflicts = observed.filter(
      (r) => r.headers["access-control-allow-origin"]?.includes("*") && r.headers["access-control-allow-credentials"]?.includes("true")
    );
    return {
      status: "informational",
      observation: `${observed.length} observed responses reviewed; ${conflicts.length} wildcard/credentials combinations are incompatible with credentialed CORS reads. Origin reflection and sensitive response access were not tested.`,
      evidenceKeys: ["cors"]
    };
  }
};
var trustedTypesCheck = {
  ...base4,
  id: "SL-TT-001",
  name: "Trusted Types enforcement",
  category: "Client-Side Security",
  method: "Parse enforced CSP require-trusted-types-for tokens separately from Report-Only.",
  run: (i2) => {
    const enforced = policies([
      ...i2.response?.headers["content-security-policy"] || [],
      ...i2.page.metaCsp
    ]);
    const required = enforced.some((p) => p.get("require-trusted-types-for")?.includes("'script'"));
    const reportOnly = policies(
      i2.response?.headers["content-security-policy-report-only"] || []
    ).some((p) => p.get("require-trusted-types-for")?.includes("'script'"));
    return {
      status: required ? "protection_observed" : !i2.response && !i2.page.metaCsp.length ? "unable_to_assess" : "informational",
      observation: required ? "Trusted Types 'script' requirement observed in an enforced policy. Policy quality and runtime behavior are not assessed." : reportOnly ? "Trusted Types is report-only; enforcement not established." : "No enforced Trusted Types requirement observed; applicability is contextual.",
      evidenceKeys: ["content-security-policy", "content-security-policy-report-only", "meta-csp"]
    };
  }
};
var redirectCheck = {
  ...base4,
  id: "SL-REDIRECT-001",
  name: "Redirect transport and origin changes",
  severity: "medium",
  run: (i2) => {
    const hops = i2.response?.redirects || [];
    const downgraded = hops.filter(
      (h) => h.url.startsWith("https:") && h.destination.startsWith("http:")
    );
    return {
      status: !i2.response ? "unable_to_assess" : downgraded.length ? "potential_weakness" : "informational",
      observation: `${hops.length} permitted redirect hops observed; ${downgraded.length} HTTPS-to-HTTP downgrades. Chain completeness is not guaranteed.`,
      evidenceKeys: ["redirects"]
    };
  }
};

// ../../packages/rule-definitions/src/index.ts
var MDN = "https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/";
var outcome = (status, observation, evidenceKeys) => ({
  status,
  observation,
  evidenceKeys
});
var unavailable = (keys) => outcome(
  "unable_to_assess",
  "No matching document response was captured. Grant access to this site, reload it, and inspect again.",
  keys
);
var values = (i2, key2) => i2.response?.headers[key2] || [];
var csp = (i2) => policies([...values(i2, "content-security-policy"), ...i2.page.metaCsp]);
var check = (id, name, category, severity, method, impact, limitation, recommendation, learning, run, reference = MDN) => ({
  id,
  name,
  category,
  severity,
  method,
  impact,
  limitation,
  recommendation,
  learning,
  run,
  references: [reference]
});
var header = (id, name, key2, valid, recommendation, impact, severity = "medium") => check(
  id,
  name,
  "Security headers",
  severity,
  `Inspect captured ${key2} response values.`,
  impact,
  "This checks configuration syntax or presence, not whole-policy effectiveness.",
  recommendation,
  `${name} is a browser-directed response policy. Its usefulness depends on the application and the browser.`,
  (i2) => {
    if (!i2.response) return unavailable([key2]);
    const v = values(i2, key2);
    return outcome(
      v.some((x) => valid(x, i2)) ? "protection_observed" : "potential_weakness",
      v.length ? `${name}: ${v.some((x) => valid(x, i2)) ? "expected configuration observed" : "review the observed value"}.` : `${name} was not observed in the document response.`,
      [key2]
    );
  },
  MDN + key2
);
var cookieCheck = (id, name, predicate, advice, limitation, severity = "low") => check(
  id,
  name,
  "Cookies",
  severity,
  "Inspect metadata of cookies matching the document URL; never retain values.",
  "Cookie attributes limit transport, script access, or cross-site use.",
  limitation,
  advice,
  "Secure restricts transport; HttpOnly restricts script access; SameSite affects cross-site sending. These flags do not prove authentication security.",
  (i2) => {
    if (!i2.cookies.available)
      return outcome("unable_to_assess", i2.cookies.limitation, ["cookies"]);
    const eligible = i2.cookies.cookies.filter(
      (c) => id === "SL-COOKIE-002" ? /(session|auth|token|sid$)/i.test(c.name) : id === "SL-COOKIE-004" ? /^__(Secure|Host)-/.test(c.name) : true
    );
    const bad = eligible.filter(predicate);
    return outcome(
      !eligible.length ? "not_applicable" : bad.length ? "potential_weakness" : "protection_observed",
      `${bad.length} of ${eligible.length} applicable matching cookies require review for this check.`,
      ["cookies"]
    );
  },
  "https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Set-Cookie"
);
var cspReview = (id, name, predicate, advice, learning) => check(
  id,
  name,
  "Content Security Policy",
  "medium",
  "Parse enforced header and meta policies, preserving separate policies.",
  "CSP can constrain the sources and execution of injected content.",
  "Multiple policies intersect. A permissive directive in one policy may be constrained by another; this is a review observation, not proof of exploitability. Script attribute overrides and browser-specific CSP support are not exhaustively evaluated.",
  advice,
  learning,
  (i2) => {
    const p = csp(i2);
    if (!p.length)
      return outcome(
        i2.response ? "not_applicable" : "unable_to_assess",
        "No enforced CSP available for directive review.",
        ["content-security-policy", "meta-csp"]
      );
    const hit = p.some(predicate);
    return outcome(
      hit ? "potential_weakness" : "protection_observed",
      hit ? "A policy contains the pattern described by this check; review all enforcing policies together." : "The reviewed pattern was not observed in available enforcing policies.",
      ["content-security-policy", "meta-csp"]
    );
  },
  MDN + "Content-Security-Policy"
);
var CHECKS = [
  ...modernChecks,
  clientSideSinkCheck,
  clientSideFlowCheck,
  postMessageCheck,
  sourceMapCheck,
  coopCheck,
  coepCheck,
  corpCheck,
  corsCheck,
  trustedTypesCheck,
  redirectCheck,
  techVulnerabilityCheck,
  storageSecurityCheck,
  activeProbingCheck,
  secretExposureCheck,
  check(
    "SL-TLS-001",
    "Document transport",
    "Transport",
    "high",
    "Inspect the top-level document URL scheme.",
    "HTTPS protects data in transit.",
    "Certificate validity, protocol versions, ciphers and application security are outside this check.",
    "Serve all pages over HTTPS.",
    "HTTPS encrypts transport between the browser and server. It does not guarantee that application logic is safe.",
    (i2) => outcome(
      i2.page.url.startsWith("https:") ? "protection_observed" : "potential_weakness",
      `The document uses ${i2.page.url.startsWith("https:") ? "HTTPS" : "HTTP"}.`,
      ["document"]
    ),
    "https://developer.mozilla.org/en-US/docs/Web/Security/Transport_Layer_Security"
  ),
  check(
    "SL-TLS-002",
    "Mixed content",
    "Transport",
    "high",
    "Inspect URLs of loaded resources and embedded frames.",
    "Active mixed content can compromise the page; passive mixed content allows interception.",
    "Only currently loaded resources are visible. Dynamic resources loaded later are missed.",
    "Ensure all resources and frames are loaded over HTTPS.",
    "Mixed content occurs when an HTTPS page loads resources over HTTP.",
    (i2) => {
      const insecureResources = i2.page.resources.filter((r) => r.url.startsWith("http:"));
      const insecureFrames = i2.page.frames.filter((f) => f.url.startsWith("http:"));
      if (!i2.page.url.startsWith("https:"))
        return outcome("not_applicable", "Page is not loaded over HTTPS.", ["document"]);
      const bad = insecureResources.length + insecureFrames.length;
      return outcome(
        bad > 0 ? "potential_weakness" : "protection_observed",
        bad > 0 ? `${bad} mixed-content resource(s) or frame(s) observed.` : "No mixed content observed.",
        ["resources", "frames"]
      );
    },
    "https://developer.mozilla.org/en-US/docs/Web/Security/Mixed_content"
  ),
  check(
    "SL-TLS-003",
    "Insecure form submission",
    "Transport",
    "high",
    "Inspect destination URLs of forms.",
    "Submitting forms over HTTP exposes the data to interception.",
    "Forms modified by JavaScript prior to submission may evade this check.",
    "Ensure all form action URLs use HTTPS.",
    "Forms on HTTPS pages should not submit to HTTP destinations.",
    (i2) => {
      if (!i2.page.url.startsWith("https:"))
        return outcome("not_applicable", "Page is not loaded over HTTPS.", ["document"]);
      const insecureForms = i2.page.forms.filter((f) => f.action.startsWith("http:"));
      return outcome(
        insecureForms.length > 0 ? "potential_weakness" : "protection_observed",
        insecureForms.length > 0 ? `${insecureForms.length} form(s) submit to HTTP destinations.` : "All forms submit to HTTPS or same-origin.",
        ["forms"]
      );
    },
    "https://developer.mozilla.org/en-US/docs/Web/Security/Insecure_passwords"
  ),
  check(
    "SL-CSP-001",
    "Content Security Policy presence",
    "Content Security Policy",
    "medium",
    "Inspect enforced CSP headers and CSP meta elements.",
    "CSP can reduce the impact of some content injection attacks.",
    "Absence does not establish XSS. Meta policies have limitations. Presence alone does not establish effectiveness.",
    "Develop a restrictive policy gradually, using Report-Only for header-based rollout.",
    "A CSP tells a browser which sources may supply scripts, styles and other content. Report-Only reports violations without blocking.",
    (i2) => {
      const present = csp(i2).length > 0;
      return outcome(
        present ? "protection_observed" : i2.response ? "potential_weakness" : "unable_to_assess",
        present ? "An enforced CSP was observed." : i2.response ? "No enforced CSP was observed." : "Header evidence unavailable and no CSP meta element observed.",
        ["content-security-policy", "meta-csp"]
      );
    },
    MDN + "Content-Security-Policy"
  ),
  cspReview(
    "SL-CSP-002",
    "CSP inline script allowance",
    (p) => {
      const s = p.get("script-src-elem") ?? sources(p, "script-src");
      return !!s?.includes("'unsafe-inline'") && !s.some((v) => /^'(nonce-|sha(?:256|384|512)-)/.test(v));
    },
    "Replace unrestricted inline execution with nonces or hashes when feasible.",
    "'unsafe-inline' can allow inline scripts. In modern browsers it may be ignored when nonces or hashes are supplied in the applicable directive."
  ),
  cspReview(
    "SL-CSP-003",
    "CSP string evaluation allowance",
    (p) => !!sources(p, "script-src")?.includes("'unsafe-eval'"),
    "Remove unsafe-eval where application dependencies permit.",
    "'unsafe-eval' allows some string-to-code execution functions. A restrictive CSP can block them."
  ),
  cspReview(
    "SL-CSP-004",
    "CSP broad script sources",
    (p) => {
      const s = p.get("script-src-elem") ?? sources(p, "script-src");
      return !s || s.some((v) => ["*", "https:", "http:", "data:"].includes(v));
    },
    "Define specific script sources and review data: and scheme-wide allowances.",
    "A scheme source such as https: permits a much wider set of sources than a named origin."
  ),
  cspReview(
    "SL-CSP-005",
    "CSP object restrictions",
    (p) => {
      const s = sources(p, "object-src");
      return !s || !(s.length === 1 && s[0] === "'none'");
    },
    "Use object-src 'none' if plugin content is unnecessary.",
    "object-src controls object and embed content; default-src is its fallback."
  ),
  cspReview(
    "SL-CSP-006",
    "CSP base URI restrictions",
    (p) => {
      const s = p.get("base-uri");
      return !s || s.some((v) => ["*", "https:", "http:"].includes(v));
    },
    "Use base-uri 'self' or 'none' where appropriate.",
    "base-uri limits base elements that can change how relative URLs resolve. It has no default-src fallback."
  ),
  check(
    "SL-CSP-007",
    "CSP reporting deployment",
    "Content Security Policy",
    "informational",
    "Observe Report-Only headers separately from enforced policies.",
    "Reporting supports gradual CSP deployment.",
    "Report-Only does not enforce protection; absence of reporting is not a weakness.",
    "Use a reporting policy when preparing CSP changes.",
    "A report-only policy allows activity while sending policy violation reports to configured reporting endpoints.",
    (i2) => i2.response ? outcome(
      "informational",
      values(i2, "content-security-policy-report-only").length ? "Report-Only CSP observed; it does not enforce protection." : "No Report-Only CSP observed.",
      ["content-security-policy-report-only"]
    ) : unavailable(["content-security-policy-report-only"]),
    MDN + "Content-Security-Policy-Report-Only"
  ),
  header(
    "SL-HEADER-001",
    "HTTP Strict Transport Security",
    "strict-transport-security",
    (v, i2) => i2.page.url.startsWith("https:") && positiveHsts(v),
    "On HTTPS, deploy an appropriate positive max-age after testing.",
    "HSTS directs future connections to use HTTPS."
  ),
  header(
    "SL-HEADER-002",
    "Content type protection",
    "x-content-type-options",
    (v) => v.trim().toLowerCase() === "nosniff",
    "Return X-Content-Type-Options: nosniff.",
    "nosniff reduces MIME type guessing."
  ),
  check(
    "SL-HEADER-003",
    "Referrer policy",
    "Security headers",
    "low",
    "Inspect the last recognized response token or a recognized meta referrer policy.",
    "Referrer policies control how much URL information is sent with requests.",
    "Browsers provide defaults. This check does not inspect per-element overrides.",
    "Review strict-origin-when-cross-origin, same-origin or no-referrer for your application.",
    "A referrer may disclose a referring URL. Modern browser defaults reduce this exposure even without an explicit policy.",
    (i2) => {
      const tokens = values(i2, "referrer-policy").join(",").split(",").map((x) => x.trim().toLowerCase());
      const known = [
        "no-referrer",
        "no-referrer-when-downgrade",
        "origin",
        "origin-when-cross-origin",
        "same-origin",
        "strict-origin",
        "strict-origin-when-cross-origin",
        "unsafe-url"
      ];
      const effective = tokens.filter((x) => known.includes(x)).at(-1) || i2.page.metaReferrer;
      return effective && known.includes(effective) ? outcome(
        effective === "unsafe-url" || effective === "no-referrer-when-downgrade" ? "potential_weakness" : "protection_observed",
        `Recognized policy: ${effective}.`,
        ["referrer-policy", "meta-referrer"]
      ) : i2.response ? outcome("potential_weakness", "No recognized explicit referrer policy observed.", [
        "referrer-policy",
        "meta-referrer"
      ]) : unavailable(["referrer-policy", "meta-referrer"]);
    },
    MDN + "Referrer-Policy"
  ),
  check(
    "SL-HEADER-004",
    "Framing protection",
    "Security headers",
    "medium",
    "Inspect header CSP frame-ancestors and X-Frame-Options.",
    "Restricting framing can reduce clickjacking exposure.",
    "frame-ancestors in meta CSP is ignored. Header presence does not establish all UI interaction security.",
    "Use a restrictive frame-ancestors directive or valid X-Frame-Options.",
    "frame-ancestors controls which pages may embed this document. It is independent of frame-src, which controls frames loaded by this document.",
    (i2) => {
      if (!i2.response) return unavailable(["content-security-policy", "x-frame-options"]);
      const ancestors = policies(values(i2, "content-security-policy")).map((p) => p.get("frame-ancestors")).filter(Boolean);
      const xfo = values(i2, "x-frame-options");
      const ok = ancestors.length ? ancestors.some(restrictiveAncestors) : xfo.length === 1 && /^(deny|sameorigin)$/i.test(xfo[0].trim());
      return outcome(
        ok ? "protection_observed" : "potential_weakness",
        ok ? "A restrictive header-based framing policy was observed." : "No recognized restrictive framing policy observed.",
        ["content-security-policy", "x-frame-options"]
      );
    },
    MDN + "Content-Security-Policy/frame-ancestors"
  ),
  header(
    "SL-HEADER-005",
    "Permissions Policy",
    "permissions-policy",
    (v) => /^[a-z-]+\s*=\s*\(/i.test(v.trim()),
    "Review browser feature permissions and disable unnecessary features.",
    "Permissions Policy controls access to some browser capabilities.",
    "low"
  ),
  ...[
    [
      "SL-HEADER-006",
      "Cross-origin opener policy",
      "cross-origin-opener-policy",
      ["same-origin", "same-origin-allow-popups", "noopener-allow-popups"]
    ],
    [
      "SL-HEADER-007",
      "Cross-origin resource policy",
      "cross-origin-resource-policy",
      ["same-origin", "same-site", "cross-origin"]
    ],
    [
      "SL-HEADER-008",
      "Cross-origin embedder policy",
      "cross-origin-embedder-policy",
      ["require-corp", "credentialless"]
    ]
  ].map(
    ([id, name, key2, accepted]) => check(
      id,
      name,
      "Cross-origin policies",
      "informational",
      `Inspect ${key2} header.`,
      "Cross-origin policies can provide isolation or control resource sharing.",
      "These policies are context dependent; absence is informational and not a general vulnerability.",
      "Review whether isolation is appropriate for the application.",
      "These policies may affect popups and third-party resources. Test compatibility before enabling.",
      (i2) => {
        if (!i2.response) return unavailable([key2]);
        const v = values(i2, key2);
        return outcome(
          "informational",
          v.some((x) => accepted.includes(x.split(";")[0].trim())) ? "Recognized cross-origin policy observed." : v.length ? "Unrecognized policy value; review configuration." : "Policy not observed; applicability is context dependent.",
          [key2]
        );
      },
      MDN + key2
    )
  ),
  check(
    "SL-HEADER-009",
    "HSTS subdomain coverage",
    "Security headers",
    "informational",
    "Inspect includeSubDomains in a positive HSTS policy.",
    "Subdomain coverage extends transport policy to child hosts.",
    "Enabling this can break HTTP-only subdomains. Preload enrollment is not inferred from the preload token.",
    "Inventory subdomains before enabling includeSubDomains or considering preload.",
    "An HSTS policy without includeSubDomains applies to the current host only.",
    (i2) => i2.response ? outcome(
      "informational",
      values(i2, "strict-transport-security").some(
        (v) => positiveHsts(v) && /(?:^|;)\s*includesubdomains\s*(?:;|$)/i.test(v)
      ) ? "includeSubDomains observed." : "No positive HSTS includeSubDomains configuration observed.",
      ["strict-transport-security"]
    ) : unavailable(["strict-transport-security"]),
    MDN + "Strict-Transport-Security"
  ),
  cookieCheck(
    "SL-COOKIE-001",
    "Secure cookie attribute",
    (c) => !c.secure,
    "Use Secure for cookies that should travel only over HTTPS.",
    "Some non-sensitive cookies may intentionally use HTTP. Matching cookies are a snapshot, not Set-Cookie history.",
    "medium"
  ),
  cookieCheck(
    "SL-COOKIE-002",
    "Probable session cookie script access",
    (c) => /(session|auth|token|sid$)/i.test(c.name) && !c.httpOnly,
    "Review HttpOnly for server-managed authentication cookies.",
    "Cookie purpose is inferred from its name with medium confidence. JavaScript-managed tokens may have different requirements.",
    "medium"
  ),
  cookieCheck(
    "SL-COOKIE-003",
    "SameSite cookie configuration",
    (c) => c.sameSite === "unspecified" || c.sameSite === "no_restriction" && !c.secure,
    "Set an explicit suitable SameSite attribute; None requires Secure.",
    "Unspecified SameSite is subject to browser defaults; this does not prove CSRF."
  ),
  cookieCheck(
    "SL-COOKIE-004",
    "Cookie prefix requirements",
    (c) => c.name.startsWith("__Secure-") && !c.secure || c.name.startsWith("__Host-") && (!c.secure || !c.hostOnly || c.path !== "/"),
    "Respect __Secure- and __Host- prefix requirements.",
    "Browsers may reject invalid prefixed cookies; collected accepted cookies can differ from attempted Set-Cookie."
  ),
  cookieCheck(
    "SL-COOKIE-005",
    "Cookie domain scope",
    (c) => !c.hostOnly,
    "Prefer host-only cookies for sensitive data where subdomain sharing is unnecessary.",
    "Domain cookies can be intentional; this is a scope review, not a vulnerability."
  ),
  check(
    "SL-COOKIE-006",
    "Cookie persistence",
    "Cookies",
    "informational",
    "Observe session flag and expiration metadata.",
    "Long-lived cookies may retain identifiers across sessions.",
    "Cookie lifetime does not establish session timeout or server-side revocation behavior.",
    "Review expiration and server-side session policies.",
    "A session cookie has no explicit persistent expiration. Browser session restore may retain it.",
    (i2) => i2.cookies.available ? outcome(
      "informational",
      `${i2.cookies.cookies.filter((c) => !c.session).length} persistent cookies; ${i2.cookies.cookies.filter((c) => c.session).length} session cookies.`,
      ["cookies"]
    ) : outcome("unable_to_assess", i2.cookies.limitation, ["cookies"]),
    MDN + "Set-Cookie"
  ),
  check(
    "SL-RESOURCE-001",
    "Mixed content references",
    "Resources",
    "medium",
    "Inspect HTTP references in the HTTPS document DOM and resource timing entries.",
    "Insecure resource transport can affect confidentiality or integrity.",
    "References may be blocked or upgraded by the browser; resource timing is not a complete network log.",
    "Replace HTTP resource URLs with HTTPS.",
    "Active mixed content includes scripts; passive content includes images. Browser treatment varies.",
    (i2) => {
      const bad = i2.page.resources.filter((r) => r.url.startsWith("http:"));
      return outcome(
        !i2.page.url.startsWith("https:") ? "not_applicable" : bad.length ? "potential_weakness" : "protection_observed",
        `${bad.length} HTTP resource references observed.`,
        ["resources"]
      );
    },
    "https://developer.mozilla.org/en-US/docs/Web/Security/Mixed_content"
  ),
  check(
    "SL-RESOURCE-002",
    "Third-party subresource integrity",
    "Resources",
    "low",
    "Inspect integrity on third-party DOM scripts and stylesheets.",
    "SRI checks that a fetched static resource matches an expected hash.",
    "Dynamic resources may not support stable hashes. Cross-origin SRI requires CORS support.",
    "Review SRI applicability for stable external scripts and stylesheets.",
    "An integrity hash pins expected content. Updating the content requires updating its hash.",
    (i2) => {
      const eligible = i2.page.resources.filter(
        (r) => r.thirdParty && ["script", "link"].includes(r.type) && r.observedBy !== "Resource timing"
      );
      const bad = eligible.filter((r) => !r.integrity);
      return outcome(
        !eligible.length ? "not_applicable" : bad.length ? "potential_weakness" : "protection_observed",
        `${bad.length} of ${eligible.length} third-party DOM scripts/stylesheets lack integrity.`,
        ["resources"]
      );
    },
    "https://developer.mozilla.org/en-US/docs/Web/Security/Subresource_Integrity"
  ),
  check(
    "SL-RESOURCE-003",
    "Integrity attribute syntax",
    "Resources",
    "low",
    "Check for recognized SHA-256 / SHA-384 / SHA-512 integrity token syntax.",
    "An unrecognized token cannot supply expected integrity protection.",
    "This check does not compute hashes, fetch resources, or validate CORS responses.",
    "Use a valid integrity token and verify the resource with browser tools.",
    "Integrity contains an algorithm and Base64 hash; a syntactically valid token can still contain the wrong hash.",
    (i2) => {
      const present = i2.page.resources.filter((r) => r.integrity);
      const bad = present.filter((r) => !sriValid(r.integrity));
      return outcome(
        !present.length ? "not_applicable" : bad.length ? "potential_weakness" : "protection_observed",
        `${bad.length} integrity attributes have no recognized token.`,
        ["resources"]
      );
    },
    "https://developer.mozilla.org/en-US/docs/Web/Security/Subresource_Integrity"
  ),
  check(
    "SL-RESOURCE-004",
    "New-window link relationships",
    "Resources",
    "informational",
    "Count target=_blank links without explicit noopener/noreferrer.",
    "Explicit noopener documents intended opener isolation.",
    "Modern browsers implicitly apply noopener to target=_blank. Missing rel alone is not treated as a weakness.",
    "Use explicit noopener where older browser compatibility is relevant.",
    "An opener reference connects a newly opened window to its originating page.",
    (i2) => outcome(
      "informational",
      `${i2.page.blankLinks} new-window links lack an explicit isolation relationship.`,
      ["links"]
    ),
    "https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Attributes/rel/noopener"
  ),
  check(
    "SL-RESOURCE-005",
    "Embedded frame sandboxing",
    "Resources",
    "low",
    "Inspect sandbox attributes of third-party iframe elements.",
    "Sandboxing can restrict capabilities of embedded documents.",
    "Some integrations require unsandboxed capabilities. Embedded document contents are not inspected.",
    "Review the minimum sandbox capabilities needed by third-party frames.",
    "A sandbox attribute restricts scripts, forms and navigation unless capabilities are explicitly allowed.",
    (i2) => {
      const frames = i2.page.frames.filter(
        (f) => originOf(f.url) && originOf(f.url) !== originOf(i2.page.url)
      );
      return outcome(
        !frames.length ? "not_applicable" : frames.some((f) => f.sandbox === null) ? "potential_weakness" : "protection_observed",
        `${frames.filter((f) => f.sandbox === null).length} of ${frames.length} third-party frames have no sandbox attribute.`,
        ["frames"]
      );
    },
    "https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/iframe"
  ),
  check(
    "SL-RESOURCE-006",
    "Third-party dependency footprint",
    "Resources",
    "informational",
    "Group external resource URLs by origin.",
    "Third-party resources introduce external dependencies and data-sharing considerations.",
    "A referenced origin is not evidence of a compromised dependency. eTLD+1 ownership is not inferred.",
    "Inventory external dependencies and their data access.",
    "Same-origin means the same scheme, host and port; it differs from same-site.",
    (i2) => outcome(
      "informational",
      `${new Set(i2.page.resources.filter((r) => r.thirdParty).map((r) => originOf(r.url))).size} third-party resource origins observed.`,
      ["resources"]
    ),
    "https://developer.mozilla.org/en-US/docs/Web/Security/Same-origin_policy"
  ),
  check(
    "SL-FORM-001",
    "Password form transport",
    "Forms",
    "high",
    "Inspect declared action URLs of password forms and document transport.",
    "Passwords sent over HTTP may be exposed in transit.",
    "JavaScript may override submissions; no forms are submitted.",
    "Use HTTPS for both password pages and form destinations.",
    "An action is the declared submission destination. Client-side code can change it.",
    (i2) => {
      const forms = i2.page.forms.filter((f) => f.password);
      const bad = forms.filter(
        (f) => f.action.startsWith("http:") || i2.page.url.startsWith("http:")
      );
      return outcome(
        !forms.length ? "not_applicable" : bad.length ? "potential_weakness" : "protection_observed",
        `${bad.length} of ${forms.length} password forms use an HTTP document or destination.`,
        ["forms"]
      );
    },
    "https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/form"
  ),
  check(
    "SL-FORM-002",
    "Password form method",
    "Forms",
    "high",
    "Inspect declared method on password forms.",
    "GET submissions can place passwords in URLs, logs and history.",
    "JavaScript-driven forms may not use the declared method.",
    "Use POST over HTTPS and avoid credentials in URLs.",
    "GET encodes form fields into a URL query. POST places them in a request body; transport still requires HTTPS.",
    (i2) => {
      const forms = i2.page.forms.filter((f) => f.password);
      return outcome(
        !forms.length ? "not_applicable" : forms.some((f) => f.method === "get") ? "potential_weakness" : "protection_observed",
        `${forms.filter((f) => f.method === "get").length} password forms declare GET.`,
        ["forms"]
      );
    },
    "https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/form"
  ),
  check(
    "SL-FORM-003",
    "External form destinations",
    "Forms",
    "informational",
    "Compare form action origins to the document origin.",
    "External submissions can share entered data with another origin.",
    "External identity providers and payment processors may be intentional. No data fields are collected.",
    "Confirm that external destinations are expected.",
    "An external action may be a legitimate service integration; review it in context.",
    (i2) => outcome(
      "informational",
      `${i2.page.forms.filter((f) => originOf(f.action) !== originOf(i2.page.url)).length} forms declare another origin.`,
      ["forms"]
    ),
    "https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/form"
  ),
  ...[
    ["SL-INFO-001", "Server disclosure", "server"],
    ["SL-INFO-002", "Runtime disclosure", "x-powered-by"]
  ].map(
    ([id, name, key2]) => check(
      id,
      name,
      "Information exposure",
      "low",
      `Observe ${key2} response values.`,
      "Software details may help fingerprint deployments.",
      "Disclosures do not establish a vulnerable version. Proxy headers may describe the delivery layer.",
      "Remove unnecessary detailed version disclosures; maintain patched software.",
      "A response header is a clue, not a reliable account of the complete backend stack.",
      (i2) => i2.response ? outcome(
        values(i2, key2).length ? "informational" : "not_applicable",
        values(i2, key2).length ? "Software-identifying response header observed." : "Header not observed.",
        [key2]
      ) : unavailable([key2]),
      MDN + key2
    )
  ),
  check(
    "SL-TECH-001",
    "Client technology indicators",
    "Technology",
    "informational",
    "Inspect DOM markers, resource URL patterns and delivery headers.",
    "Technology indicators help explain the client and delivery environment.",
    "Fingerprints can be imitated. Backend and database technologies are unknown; versions are inferred only from explicit indicators.",
    "Use these indicators as leads, not a software inventory.",
    "Detected describes direct markers; inferred describes heuristic associations. Neither proves a deployed server stack.",
    (i2) => outcome(
      "informational",
      `${i2.page.indicators.length} client technology indicators observed.`,
      ["technology"]
    ),
    "https://developer.mozilla.org/en-US/docs/Web/API/Document_Object_Model"
  ),
  check(
    "SL-STORAGE-001",
    "Browser storage metadata",
    "Storage",
    "informational",
    "Read only localStorage and sessionStorage item counts.",
    "Client storage can retain application state.",
    "Keys and values are not read; sensitivity, token storage and expiration are not assessed.",
    "Review storage usage manually for sensitive data.",
    "Storage is accessible to same-origin scripts. A count alone cannot reveal what is stored.",
    (i2) => outcome(
      i2.page.storage.local === null && i2.page.storage.session === null ? "unable_to_assess" : "informational",
      `Local storage: ${i2.page.storage.local ?? "unavailable"} items. Session storage: ${i2.page.storage.session ?? "unavailable"} items.`,
      ["storage"]
    ),
    "https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API"
  )
];
var CHECK_BY_ID = new Map(CHECKS.map((c) => [c.id, c]));

// ../../packages/technology-detector/src/index.ts
var FINGERPRINT_VERSION = "2026.10.01.2";
var host = (name, layer, ...hosts) => ({
  name,
  layer,
  hosts
});
var asset = (name, layer, paths, version2) => ({
  name,
  layer,
  paths,
  version: version2
});
var generator = (name, layer) => ({
  name,
  layer,
  generator: new RegExp("^" + name + "(?:\\s|$)", "i")
});
var TECHNOLOGIES = [
  { name: "React Router", layer: "Frontend" },
  { name: "Lenis", layer: "JavaScript libraries" },
  { name: "Framer Motion", layer: "JavaScript libraries" },
  { name: "Lucide", layer: "Icon libraries" },
  host("Cloudflare Browser Insights", "Analytics", "static.cloudflareinsights.com"),
  {
    name: "Firebase",
    layer: "Client services",
    hosts: ["www.gstatic.com"],
    paths: [/^\/firebasejs\//]
  },
  asset("Firebase", "Client services", [/^\/assets\/firebase-[A-Za-z0-9_-]+\.js$/]),
  asset("React", "Frontend", [/^\/assets\/react-[A-Za-z0-9_-]+\.js$/]),
  asset("React Three Fiber", "Visualization", [/^\/assets\/react-three-fiber-[A-Za-z0-9_-]+\.js$/]),
  asset("React Three Drei", "Visualization", [/^\/assets\/react-three-drei-[A-Za-z0-9_-]+\.js$/]),
  asset("Three.js", "Visualization", [/^\/assets\/three-core-[A-Za-z0-9_-]+\.js$/]),
  { name: "Angular", layer: "Frontend" },
  { name: "Svelte", layer: "Frontend" },
  host("Tailwind CSS", "UI frameworks", "cdn.tailwindcss.com"),
  asset("Vite", "Build tools", [/^\/@vite\/client$/, /\/node_modules\/\.vite\//]),
  asset(
    "React",
    "Frontend",
    [/\/react-dom(?:@|[-.])\d/, /\/react-dom(?:\.production)?(?:\.min)?\.js$/],
    /\/react-dom(?:@|-)(\d+\.\d+\.\d+)(?:\/|\.)/
  ),
  asset("Next.js", "Frontend", [/^\/_next\//]),
  asset("Nuxt.js", "Frontend", [/^\/_nuxt\//]),
  ...["React", "Vue", "jQuery", "Bootstrap", "Axios", "Lodash"].map((name) => {
    const slug = name.toLowerCase();
    return asset(
      name === "Vue" ? "Vue.js" : name,
      ["React", "Vue"].includes(name) ? "Frontend" : name === "Bootstrap" ? "UI frameworks" : "JavaScript libraries",
      [
        new RegExp("/" + slug + "(?:@|[-.])\\d", "i"),
        new RegExp(
          "/" + slug + "(?:\\.production|\\.global|\\.bundle)?(?:\\.min)?\\.(?:js|css)$",
          "i"
        )
      ],
      new RegExp("/" + slug + "(?:@|-)(\\d+\\.\\d+\\.\\d+)(?:/|\\.)", "i")
    );
  }),
  asset("Alpine.js", "Frontend", [/\/alpinejs(?:@|\/)/]),
  asset("HTMX", "Frontend", [/\/htmx(?:\.org)?(?:@|\/)/, /\/htmx(?:\.min)?\.js$/]),
  asset("D3.js", "Visualization", [/\/d3(?:@|[-.])\d/, /\/d3(?:\.min)?\.js$/]),
  asset("Chart.js", "Visualization", [/\/chart\.js(?:@|\/)/, /\/chart(?:\.umd)?(?:\.min)?\.js$/]),
  asset("Three.js", "Visualization", [/\/three(?:@|\/)/, /\/three(?:\.min)?\.js$/]),
  asset("GSAP", "JavaScript libraries", [/\/gsap(?:@|\/)/, /\/gsap(?:\.min)?\.js$/]),
  asset("WordPress", "Content management", [/\/wp-(?:content|includes)\//]),
  ...["WordPress", "Drupal", "Joomla", "Ghost"].map((n) => generator(n, "Content management")),
  ...["Wix", "Squarespace", "Webflow"].map((n) => generator(n, "Website builders")),
  ...["Hugo", "Jekyll", "Gatsby", "Astro", "Docusaurus"].map(
    (n) => generator(n, "Static site generators")
  ),
  host("Shopify", "Commerce", "cdn.shopify.com"),
  asset("WooCommerce", "Commerce", [/\/wp-content\/plugins\/woocommerce\//]),
  asset("Magento", "Commerce", [/\/static\/version\d+\/frontend\/Magento\//]),
  host("Google Analytics", "Analytics", "www.google-analytics.com", "google-analytics.com"),
  {
    name: "Google Analytics",
    layer: "Analytics",
    hosts: ["www.googletagmanager.com"],
    paths: [/^\/gtag\/js$/]
  },
  {
    name: "Google Tag Manager",
    layer: "Tag management",
    hosts: ["www.googletagmanager.com"],
    paths: [/^\/gtm\.js$/]
  },
  host("Plausible", "Analytics", "plausible.io"),
  host("PostHog", "Analytics", "us.i.posthog.com", "eu.i.posthog.com", "app.posthog.com"),
  host("Mixpanel", "Analytics", "cdn.mxpnl.com"),
  host("Hotjar", "Analytics", "static.hotjar.com", "script.hotjar.com"),
  host("Microsoft Clarity", "Analytics", "www.clarity.ms"),
  host("Matomo", "Analytics", "cdn.matomo.cloud"),
  host("Segment", "Analytics", "cdn.segment.com"),
  host("Amplitude", "Analytics", "cdn.amplitude.com"),
  host("Sentry", "Monitoring", "browser.sentry-cdn.com", "js.sentry-cdn.com"),
  host("Datadog", "Monitoring", "www.datadoghq-browser-agent.com"),
  host("New Relic", "Monitoring", "js-agent.newrelic.com", "bam.nr-data.net"),
  host("Intercom", "Customer support", "widget.intercom.io", "js.intercomcdn.com"),
  host("Zendesk", "Customer support", "static.zdassets.com"),
  host("Crisp", "Customer support", "client.crisp.chat"),
  host("Tawk.to", "Customer support", "embed.tawk.to"),
  host("HubSpot", "Marketing", "js.hs-scripts.com", "js.hs-analytics.net"),
  host("Stripe", "Payments", "js.stripe.com"),
  { name: "PayPal", layer: "Payments", hosts: ["www.paypal.com"], paths: [/^\/sdk\/js$/] },
  {
    name: "Google reCAPTCHA",
    layer: "Security",
    hosts: ["www.google.com", "www.recaptcha.net"],
    paths: [/^\/recaptcha\//]
  },
  {
    name: "Cloudflare Turnstile",
    layer: "Security",
    hosts: ["challenges.cloudflare.com"],
    paths: [/^\/turnstile\//]
  },
  host("hCaptcha", "Security", "js.hcaptcha.com"),
  host("Google Fonts", "Fonts", "fonts.googleapis.com", "fonts.gstatic.com"),
  host("Adobe Fonts", "Fonts", "use.typekit.net"),
  host("jsDelivr", "Delivery", "cdn.jsdelivr.net"),
  host("UNPKG", "Delivery", "unpkg.com"),
  host("cdnjs", "Delivery", "cdnjs.cloudflare.com"),
  {
    name: "Cloudflare",
    layer: "Delivery",
    headers: { server: /^cloudflare$/i, "cf-ray": /^[a-f0-9]+-/i }
  },
  {
    name: "AWS CloudFront",
    layer: "Delivery",
    headers: { via: /\bcloudfront\b/i, "x-amz-cf-id": /.+/ }
  },
  {
    name: "Fastly",
    layer: "Delivery",
    headers: { "x-served-by": /\bcache-/i, "x-fastly-request-id": /.+/ }
  },
  { name: "Vercel", layer: "Delivery", headers: { server: /^vercel$/i, "x-vercel-id": /.+/ } },
  {
    name: "Netlify",
    layer: "Delivery",
    headers: { server: /^netlify$/i, "x-nf-request-id": /.+/ }
  },
  { name: "Nginx", layer: "Server", headers: { server: /\bnginx(?:\/([\d.]+))?\b/i } },
  { name: "Apache", layer: "Server", headers: { server: /\bApache(?:\/([\d.]+))?\b/i } },
  {
    name: "Microsoft IIS",
    layer: "Server",
    headers: { server: /\bMicrosoft-IIS(?:\/([\d.]+))?\b/i }
  },
  { name: "LiteSpeed", layer: "Server", headers: { server: /\bLiteSpeed\b/i } },
  { name: "Express", layer: "Backend clues", headers: { "x-powered-by": /^Express$/i } },
  {
    name: "PHP",
    layer: "Backend clues",
    headers: { "x-powered-by": /^PHP(?:\/([\d.]+))?/i },
    cookies: [/^PHPSESSID$/]
  },
  {
    name: "ASP.NET",
    layer: "Backend clues",
    headers: { "x-powered-by": /^ASP\.NET$/i, "x-aspnet-version": /^([\d.]+)$/ },
    cookies: [/^ASP\.NET_SessionId$/]
  },
  { name: "Django", layer: "Backend clues", cookies: [/^csrftoken$/] },
  { name: "Laravel", layer: "Backend clues", cookies: [/^laravel_session$/] }
];
var rank = { low: 0, medium: 1, high: 2 };
function detectTechnologies(_html, resources, headers, cookies, _windowKeys = [], meta = [], existing = []) {
  const result = /* @__PURE__ */ new Map();
  const add = (def, signal, version2, versionConfidence = "low") => {
    let t = result.get(def.name);
    if (!t) {
      t = {
        name: def.name,
        layer: def.layer,
        confidence: signal.confidence,
        observation: "",
        version: "Unknown",
        versionConfidence: "low",
        detection: "observed",
        fingerprintVersion: FINGERPRINT_VERSION,
        signals: []
      };
      result.set(def.name, t);
    }
    if (!t.signals.some(
      (s) => s.type === signal.type && s.source === signal.source && s.observation === signal.observation
    ))
      t.signals.push(signal);
    if (rank[signal.confidence] > rank[t.confidence]) t.confidence = signal.confidence;
    if (signal.type !== "inference") t.detection = "observed";
    if (version2 && /^\d+(?:\.\d+){0,3}(?:[-\w.]*)?$/.test(version2)) {
      if (t.version !== "Unknown" && t.version !== version2) {
        t.version = "Conflicting indicators";
        t.versionConfidence = "low";
        t.versionSource = "Conflicting version signals";
      } else if (t.version !== "Conflicting indicators" && (t.version === "Unknown" || rank[versionConfidence] >= rank[t.versionConfidence || "low"])) {
        t.version = version2;
        t.versionConfidence = versionConfidence;
        t.versionSource = signal.source;
      }
    }
    t.observation = t.signals.map((s) => s.observation).join(" ");
  };
  for (const old of existing) {
    for (const signal of old.signals?.length ? old.signals : [
      {
        type: "dom",
        source: "Captured DOM marker",
        observation: old.observation,
        confidence: old.confidence
      }
    ])
      add(old, signal, old.version, old.versionConfidence);
    if (old.variant) result.get(old.name).variant = old.variant;
  }
  for (const def of TECHNOLOGIES) {
    for (const r of resources.slice(0, 2e3)) {
      let u;
      try {
        u = new URL(r.url);
      } catch {
        continue;
      }
      if (!["http:", "https:"].includes(u.protocol) || def.hosts && !def.hosts.includes(u.hostname) || def.paths && !def.paths.some((p) => p.test(u.pathname)) || !def.hosts && !def.paths)
        continue;
      const source = redactUrl(r.url);
      add(
        def,
        {
          type: "resource",
          source,
          observation: `${def.name} resource fingerprint: ${source}.`,
          confidence: "medium"
        },
        def.version?.exec(u.pathname)?.[1],
        "medium"
      );
      if (def.name === "Google Analytics" && u.hostname === "www.googletagmanager.com" && u.pathname === "/gtag/js" && /^G-[A-Z0-9]+$/.test(u.searchParams.get("id") || "")) {
        const ga = result.get(def.name);
        ga.variant = "GA4";
        if (!ga.signals.some((s) => s.observation.includes("GA4 identifier")))
          ga.signals.push({
            type: "resource",
            source,
            observation: "GA4 identifier format observed in the script-loader URL; identifier omitted.",
            confidence: "medium"
          });
      }
    }
    for (const [key2, pattern] of Object.entries(def.headers || {}))
      for (const value of (headers[key2] || []).slice(0, 10)) {
        const match = pattern.exec(value.slice(0, 4096));
        if (match)
          add(
            def,
            {
              type: "header",
              source: key2,
              observation: `${key2} matched the ${def.name} fingerprint (self-reported header).`,
              confidence: "medium"
            },
            match[1],
            "high"
          );
      }
    for (const pattern of def.cookies || [])
      if (cookies.some((c) => pattern.test(c.name)))
        add(def, {
          type: "cookie",
          source: "Cookie name pattern",
          observation: `Cookie name matches ${def.name}; shared names are weak evidence.`,
          confidence: "low"
        });
    if (def.generator) {
      for (const m of meta || [])
        if (m.name === "generator" && def.generator.test(m.content)) {
          const v = m.content.match(/\b(\d+\.\d+(?:\.\d+)?)\b/)?.[1];
          add(
            def,
            {
              type: "meta",
              source: 'meta[name="generator"]',
              observation: `Generator declares ${def.name}${v ? " " + v : ""}; this is self-reported.`,
              confidence: "medium"
            },
            v,
            "high"
          );
        }
    }
  }
  for (const [parent, child] of [
    ["Next.js", "React"],
    ["Nuxt.js", "Vue.js"],
    ["WooCommerce", "WordPress"]
  ])
    if (result.has(parent) && !result.has(child)) {
      add(
        { name: child, layer: child === "WordPress" ? "Content management" : "Frontend" },
        {
          type: "inference",
          source: parent,
          observation: `Inferred from ${parent}; no independent ${child} fingerprint observed.`,
          confidence: "low"
        }
      );
      result.get(child).detection = "inferred";
    }
  for (const t of result.values())
    if (t.signals?.every((s) => s.type === "inference")) t.detection = "inferred";
  return [...result.values()].sort(
    (a, b) => a.layer.localeCompare(b.layer) || a.name.localeCompare(b.name)
  );
}

// ../../packages/finding-engine/src/index.ts
var FindingEngine = class {
  static generateFindings(checks, input, evidenceKeys, now) {
    return checks.map((check2) => {
      const result = input.enabledChecks && !input.enabledChecks.includes(check2.id) ? {
        status: "unable_to_assess",
        observation: "Check skipped by the assessment profile.",
        evidenceKeys: ["document"]
      } : check2.run(input);
      const finding = {
        id: crypto.randomUUID(),
        checkId: check2.id,
        ruleVersion: ruleVersion(check2),
        title: check2.name,
        category: check2.category,
        status: result.status,
        severity: result.status === "potential_weakness" ? result.severity || check2.severity : "informational",
        confidence: check2.id === "SL-COOKIE-002" ? "medium" : result.confidence || "high",
        affectedUrl: input.page.url,
        observation: result.observation,
        impact: check2.impact,
        limitation: check2.limitation,
        recommendation: check2.recommendation,
        validation: "Reload the target after configuration changes. Re-run this check against newly collected evidence.",
        evidenceIds: (result.evidenceKeys.length ? result.evidenceKeys : ["document"]).map((k) => evidenceKeys.get(k)).filter(Boolean),
        references: check2.references,
        lifecycle: "new",
        firstObserved: now,
        createdAt: now
      };
      finding.suppression = suppressionFor(
        finding,
        new URL(input.page.url).origin,
        input.suppressions || [],
        Date.parse(now)
      );
      return finding;
    });
  }
};

// ../../packages/assessment-engine/src/index.ts
var VERSION = "1.0.0";
function normalizePage(page) {
  const origin = originOf(page.url);
  const { inlineScripts, windowKeys, activeProbes, ...safe } = page;
  const secretMetadata = (values2) => values2?.map((v) => ({
    key: text(v.key, 100),
    location: v.location ? {
      scriptId: text(v.location.scriptId, 128),
      url: redactUrl(v.location.url),
      line: v.location.line,
      column: v.location.column,
      propertyPath: text(v.location.propertyPath, 512),
      method: text(v.location.method, 128)
    } : void 0,
    source: text(v.source, 256),
    category: text(v.category, 80),
    confidence: v.confidence,
    isSecret: !!v.isSecret,
    isLikelyPublic: !!v.isLikelyPublic,
    provider: text(v.provider, 64),
    valueRedacted: "[REDACTED]",
    valueFingerprint: /^[a-f0-9]{64}$/.test(v.valueFingerprint || "") ? v.valueFingerprint : void 0,
    length: v.length,
    entropyScore: v.entropyScore,
    signals: v.signals?.map((t) => text(t, 100))
  }));
  return {
    ...safe,
    secrets: secretMetadata(page.secrets),
    sourceMaps: page.sourceMaps?.map((m) => ({
      ...m,
      url: redactUrl(m.url),
      secrets: secretMetadata(m.secrets) || []
    })),
    storage: {
      local: page.storage.local,
      session: page.storage.session,
      keys: page.storage.keys?.length ? Array(Math.min(page.storage.keys.length, 200)).fill("sensitive-name pattern") : void 0
    },
    manifestUrl: page.manifestUrl ? redactUrl(page.manifestUrl) : null,
    sinks: page.sinks?.map((s) => ({
      type: text(s.type, 64),
      node: text(s.node, 64),
      attribute: text(s.attribute, 64),
      snippet: "[CODE OMITTED]"
    })),
    sourceMapUrls: page.sourceMapUrls?.map(redactUrl),
    serviceWorkers: page.serviceWorkers?.map((s) => ({
      scope: redactUrl(s.scope),
      scriptUrl: redactUrl(s.scriptUrl),
      state: text(s.state, 32)
    })),
    url: redactUrl(page.url),
    resources: page.resources.map((r) => ({
      url: redactUrl(r.url),
      type: text(r.type, 32),
      integrity: r.integrity ? text(r.integrity, 2048) : null,
      crossorigin: r.crossorigin ? text(r.crossorigin, 32) : null,
      loadedBy: text(r.loadedBy, 128),
      observedBy: text(r.observedBy, 32),
      thirdParty: httpUrl(r.url) && originOf(r.url) !== origin
    })),
    forms: page.forms.map((f) => ({
      action: redactUrl(f.action),
      method: text(f.method, 16),
      password: !!f.password
    })),
    frames: page.frames.map((f) => ({
      url: redactUrl(f.url),
      sandbox: f.sandbox === null ? null : text(f.sandbox, 1024)
    })),
    metaCsp: page.metaCsp.map(redactHeader),
    metaReferrer: page.metaReferrer ? text(page.metaReferrer, 128) : null,
    indicators: page.indicators.map((t) => ({
      name: text(t.name, 64),
      layer: text(t.layer, 64),
      confidence: t.confidence,
      observation: text(t.observation, 512),
      versionConfidence: t.versionConfidence || "low",
      versionSource: t.versionSource,
      detection: t.detection,
      fingerprintVersion: t.fingerprintVersion,
      variant: t.variant ? text(t.variant, 32) : void 0,
      signals: t.signals?.slice(0, 30).map((s) => ({
        ...s,
        source: httpUrl(s.source) ? redactUrl(s.source) : text(s.source, 256),
        observation: text(s.observation, 512)
      })),
      version: t.version === "Conflicting indicators" ? t.version : /^\d+(\.\d+){0,3}(?:[-\w.]*)?$/.test(t.version) ? text(t.version, 32) : "Unknown"
    }))
  };
}
function assess(raw, selectedCheckId, now = (/* @__PURE__ */ new Date()).toISOString()) {
  if (selectedCheckId && !CHECK_BY_ID.has(selectedCheckId)) throw new Error("Unknown check ID.");
  const page = normalizePage({
    ...raw.page,
    indicators: detectTechnologies(
      "",
      raw.page.resources,
      raw.response?.headers || {},
      raw.cookies.cookies,
      [],
      raw.page.technologyMeta,
      raw.page.indicators
    )
  });
  const response = raw.response ? {
    ...raw.response,
    url: redactUrl(raw.response.url),
    headers: Object.fromEntries(
      Object.entries(raw.response.headers).map(([k, v]) => [k, v.map(redactHeader)])
    ),
    redirects: raw.response.redirects.map((r) => ({
      ...r,
      url: redactUrl(r.url),
      destination: redactUrl(r.destination)
    }))
  } : null;
  const technologies = [...page.indicators];
  const requests = (raw.requests || []).map((r) => ({
    ...r,
    url: redactUrl(r.url),
    initiator: redactUrl(r.initiator),
    headers: Object.fromEntries(
      Object.entries(r.headers).map(([k, v]) => [k, v.map(redactHeader)])
    )
  }));
  const input = {
    ...raw,
    cookies: {
      ...raw.cookies,
      cookies: raw.cookies.cookies.map((c) => ({ ...c, value: "[REDACTED]" }))
    },
    page: { ...page, indicators: technologies },
    response,
    requests
  };
  const evidenceEngine = new EvidenceEngine(input, page, response, technologies);
  evidenceEngine.generateCoreEvidence();
  const evidence = evidenceEngine.getEvidence();
  const keys = evidenceEngine.getKeys();
  const selected2 = selectedCheckId ? [CHECK_BY_ID.get(selectedCheckId)] : CHECKS;
  const findings = FindingEngine.generateFindings(selected2, input, keys, now);
  const apiEndpoints = requests.filter(
    (r) => ["xmlhttprequest", "fetch", "websocket"].includes(r.type) || /\/(api|graphql|gql|auth|socket)(?:\/|[?]|$)/i.test(r.url)
  ).map((r) => ({
    ...r,
    category: r.type === "websocket" ? "WebSocket" : /\/graphql(?:\/|[?]|$)/i.test(r.url) ? "GraphQL" : /\/(auth|login|token|refresh)(?:\/|[?]|$)/i.test(r.url) ? "Authentication" : /\/api(?:\/|[?]|$)/i.test(r.url) ? "REST" : "Fetch / XHR",
    relationship: originOf(r.url) === originOf(page.url) ? "same-origin" : "third-party"
  }));
  const needed = new Set(findings.flatMap((f) => f.evidenceIds));
  return {
    id: crypto.randomUUID(),
    schemaVersion: 2,
    version: VERSION,
    ruleSetVersion: RULESET_VERSION,
    engineVersion: "1.1.0",
    requestedUrl: redactUrl(raw.requestedUrl || raw.page.url),
    effectiveUrl: page.url,
    permissionsGranted: raw.permissions || [],
    profile: raw.profile || "extension-passive",
    enabledChecks: selected2.filter((c) => !raw.enabledChecks || raw.enabledChecks.includes(c.id)).map((c) => c.id),
    disabledChecks: selected2.filter((c) => raw.enabledChecks && !raw.enabledChecks.includes(c.id)).map((c) => c.id),
    scope: raw.scope || defaultScope(raw.page.url),
    timeouts: [],
    projectId: raw.projectId,
    environment: raw.environment,
    ruleVersions: Object.fromEntries(selected2.map((c) => [c.id, ruleVersion(c)])),
    apiEndpoints: selectedCheckId ? [] : apiEndpoints,
    requests: selectedCheckId ? [] : requests,
    url: page.url,
    origin: originOf(page.url),
    targetKey: raw.targetKey,
    createdAt: now,
    durationMs: 0,
    browser: raw.browser,
    kind: selectedCheckId ? "verification" : "full",
    ...selectedCheckId ? { selectedCheckId } : {},
    findings,
    evidence: selectedCheckId ? evidence.filter((e) => needed.has(e.id)) : evidence,
    resources: selectedCheckId ? [] : page.resources,
    forms: selectedCheckId ? [] : page.forms,
    frames: selectedCheckId ? [] : page.frames,
    cookies: selectedCheckId ? [] : raw.cookies.cookies.map((c) => ({ ...c, value: "[REDACTED]" })),
    technologies: selectedCheckId ? [] : technologies,
    checksCompleted: findings.filter((f) => f.status !== "unable_to_assess").length,
    checksTotal: selected2.length,
    limits: page.limits,
    coverage: [
      {
        area: "Document transport",
        status: "assessed",
        detail: "URL scheme only; no TLS protocol or certificate audit."
      },
      {
        area: "Security headers",
        status: response ? "assessed" : "blocked by permissions",
        detail: response ? "Matching document response captured. Policy effectiveness remains contextual." : "Response unavailable: permission, prior navigation or collection timing may be responsible; DOM meta evidence remains available."
      },
      {
        area: "Cookie attributes",
        status: raw.cookies.available ? "partial" : "blocked by permissions",
        detail: raw.cookies.limitation
      },
      {
        area: "Page resources",
        status: "partial",
        detail: "DOM references and available resource timing entries; not a complete network log."
      },
      {
        area: "HTML forms / frames",
        status: page.limits.length ? "partial" : "assessed",
        detail: "Declared top-level DOM attributes only; no submissions."
      },
      {
        area: "Client technologies",
        status: "partial",
        detail: "Local fingerprints from DOM markers, generator metadata, resource URLs, permitted response headers and cookie names. Inferences and version confidence are separate; runtime globals, hidden backends and a complete dependency inventory are not assessed."
      },
      {
        area: "Client-side JavaScript",
        status: page.analysis ? "partial" : "skipped",
        detail: page.analysis?.limitation || "No AST analysis collected."
      },
      {
        area: "API surface / CORS",
        status: requests.length ? "partial" : "not assessed",
        detail: "Only permitted intercepted requests; bodies and credential values are not read."
      },
      {
        area: "Active vulnerability testing",
        status: "unsupported",
        detail: "No attack payloads, probing or exploit confirmation."
      },
      { area: "Browser storage", status: "partial", detail: "Metadata only; values omitted." },
      {
        area: "Redirect chain",
        status: response?.redirects.length ? "partial" : "not assessed",
        detail: "Only selected permitted hops captured while observation is enabled."
      },
      {
        area: "Authentication / authorization",
        status: "not assessed",
        detail: "No login, session validation or access-control tests."
      },
      {
        area: "Backend / database security",
        status: "impossible from browser",
        detail: "Not established by browser-visible evidence."
      },
      {
        area: "Business logic",
        status: "not assessed",
        detail: "No workflow or transaction testing."
      },
      {
        area: "TLS certificate / protocol",
        status: "impossible from browser",
        detail: "HTTPS URL observation is not a TLS audit; use a dedicated external TLS tool."
      }
    ].map(
      (c) => selectedCheckId ? {
        ...c,
        status: "skipped",
        detail: "Selective verification; see the selected check and its evidence for scope."
      } : c
    )
  };
}

// ../../packages/assessment-engine/src/replay.ts
function replayAssessment(a, settings) {
  const data2 = (label) => a.evidence.find((e) => e.label === label)?.data;
  const storage = data2("Storage item counts") || {
    local: null,
    session: null
  };
  const page = {
    url: a.url,
    timeOrigin: 0,
    resources: a.resources,
    forms: a.forms,
    frames: a.frames,
    indicators: a.technologies,
    metaCsp: data2("CSP meta policies") || [],
    metaReferrer: data2("Referrer meta policy") || null,
    blankLinks: data2("New-window relationships")?.withoutExplicitIsolation || 0,
    storage,
    limits: [...a.limits, "Re-evaluation of stored evidence; no new website collection."],
    collectedAt: a.evidence.find((e) => e.type === "document")?.collectedAt || a.createdAt,
    analysis: data2("Client-side AST observations"),
    sourceMaps: data2("Source map observations"),
    secrets: data2("Redacted configuration patterns"),
    serviceWorkers: data2("Registered service workers"),
    crossOriginIsolated: data2("Runtime isolation")?.crossOriginIsolated
  };
  const headers = {};
  const captured = a.evidence.filter(
    (e) => e.type === "header" && e.data?.availability === "captured"
  );
  for (const e of captured) {
    const h = e.data;
    headers[h.name] = h.values;
  }
  const response = captured.length ? {
    url: a.url,
    headers,
    statusCode: captured[0].provenance?.statusCode || 200,
    collectedAt: captured[0].collectedAt,
    requestId: captured[0].provenance?.requestId || "replayed",
    startedAt: 0,
    urlHash: a.targetKey,
    redirects: data2("Observed redirects")?.hops || [],
    provenance: captured[0].provenance
  } : null;
  const cookieData = data2("Cookie attributes");
  const result = assess({
    page,
    response,
    cookies: cookieData || {
      available: false,
      cookies: [],
      limitation: "Cookie evidence was not retained."
    },
    browser: a.browser,
    targetKey: a.targetKey,
    profile: a.profile === "cli-browser" ? "cli-browser" : "extension-passive",
    scope: a.scope,
    permissions: a.permissionsGranted,
    requests: a.requests,
    projectId: a.projectId,
    environment: a.environment,
    suppressions: settings.suppressions || []
  });
  result.reproducibility = { reevaluatedFrom: a.id, evaluatedAt: result.createdAt };
  return result;
}

// src/core/history.ts
function inheritHistory(assessment, history, events) {
  return {
    ...assessment,
    findings: assessment.findings.map((f) => {
      const older = history.filter((a) => a.targetKey === assessment.targetKey).flatMap((a) => a.findings.filter((p) => p.checkId === f.checkId));
      const event = events.filter((e) => e.targetKey === assessment.targetKey && e.checkId === f.checkId).at(-1);
      return {
        ...f,
        firstObserved: older.map((p) => p.firstObserved || p.createdAt).sort()[0] || f.createdAt,
        lifecycle: event?.expiresAt && Date.parse(event.expiresAt) <= Date.now() || older[0] && !sameRule(older[0], f) ? "needs verification" : event?.state || older[0]?.lifecycle || "new",
        owner: event?.owner,
        reviewState: event?.expiresAt && Date.parse(event.expiresAt) <= Date.now() ? "Expired decision; review required" : void 0
      };
    })
  };
}
function verificationResult(before, after) {
  if (after.kind !== "verification" || !after.selectedCheckId)
    return { verified: false, reason: "This is not a selective verification." };
  if (before.targetKey !== after.targetKey)
    return { verified: false, reason: "The target changed; verification was refused." };
  const old = before.findings.find((f) => f.checkId === after.selectedCheckId), fresh = after.findings[0];
  if (!old || !fresh)
    return { verified: false, reason: "The baseline does not contain this check." };
  if (!sameRule(old, fresh) || after.reproducibility?.reevaluatedFrom)
    return {
      verified: false,
      reason: "Rule changes or stored-evidence re-evaluation cannot verify a website fix. Collect a new baseline."
    };
  if (old.status !== "potential_weakness" || fresh.status !== "protection_observed")
    return {
      verified: false,
      reason: "The selected observation has not changed from a potential weakness to an observed protection."
    };
  const newEvidence = after.evidence.filter((e) => fresh.evidenceIds.includes(e.id));
  const oldHeaders = before.evidence.filter(
    (e) => old.evidenceIds.includes(e.id) && e.type === "header"
  );
  if (oldHeaders.length && newEvidence.filter((e) => e.type === "header").some(
    (e) => Date.parse(e.collectedAt) <= Math.max(...oldHeaders.map((p) => Date.parse(p.collectedAt)))
  ))
    return { verified: false, reason: "Reload the target to obtain newer response evidence." };
  return {
    verified: true,
    reason: "Improvement verified for the selected passive check. This does not establish that the entire application is secure."
  };
}

// src/repository.ts
var DEFAULT_SETTINGS = {
  learningMode: false,
  retention: 50,
  observedOrigins: []
};
var queue = Promise.resolve();
function transaction(action) {
  const next = queue.then(action, action);
  queue = next.catch(() => {
  });
  return next;
}
async function getState() {
  const data2 = await chrome.storage.local.get(["records", "events", "settings", "assessments"]);
  return {
    assessments: Array.isArray(data2.records) ? data2.records : [],
    events: Array.isArray(data2.events) ? data2.events : [],
    settings: {
      ...DEFAULT_SETTINGS,
      ...typeof data2.settings === "object" && data2.settings ? data2.settings : {}
    },
    legacyCount: Array.isArray(data2.assessments) ? data2.assessments.length : 0
  };
}
async function saveAssessment(assessment) {
  return transaction(async () => {
    const state = await getState();
    const records = [assessment, ...state.assessments].slice(0, state.settings.retention);
    const ids = new Set(records.map((a) => a.id));
    await chrome.storage.local.set({
      records,
      events: state.events.filter((e) => ids.has(e.assessmentId))
    });
    return assessment;
  });
}
async function setSettings(patch) {
  return transaction(async () => {
    const state = await getState();
    const settings = {
      ...state.settings,
      ...patch,
      retention: Math.min(
        200,
        Math.max(5, Math.trunc(patch.retention ?? state.settings.retention))
      )
    };
    await chrome.storage.local.set({
      settings,
      records: state.assessments.slice(0, settings.retention)
    });
    return settings;
  });
}
var STATES = [
  "new",
  "acknowledged",
  "investigating",
  "accepted risk",
  "fixed",
  "needs verification",
  "verified",
  "false positive"
];
async function setLifecycle(assessmentId, checkId, state, note, metadata = {}) {
  if (!STATES.includes(state)) throw new Error("Invalid lifecycle state.");
  if (["accepted risk", "false positive"].includes(state) && (!note.trim() || !metadata.actor?.trim() || !metadata.expiresAt || !Number.isFinite(Date.parse(metadata.expiresAt)) || Date.parse(metadata.expiresAt) <= Date.now()))
    throw new Error(
      "Accepted risk and false positive annotations require a reason, analyst and future review expiry."
    );
  return transaction(async () => {
    const data2 = await getState();
    const a = data2.assessments.find((a2) => a2.id === assessmentId);
    const f = a?.findings.find((f2) => f2.checkId === checkId);
    if (!a || !f) throw new Error("Finding no longer exists.");
    f.lifecycle = state;
    const event = {
      id: crypto.randomUUID(),
      targetKey: a.targetKey,
      assessmentId,
      checkId,
      state: f.lifecycle,
      note: note.slice(0, 2e3),
      at: (/* @__PURE__ */ new Date()).toISOString(),
      actor: String(metadata.actor || "Local analyst").slice(0, 128),
      owner: String(metadata.owner || "").slice(0, 128),
      expiresAt: metadata.expiresAt,
      reviewRequired: metadata.reviewRequired ?? ["accepted risk", "false positive"].includes(state)
    };
    await chrome.storage.local.set({
      records: data2.assessments,
      events: [...data2.events, event].slice(-2e3)
    });
    return event;
  });
}
async function deleteAssessment(id) {
  return transaction(async () => {
    const state = await getState();
    await chrome.storage.local.set({
      records: state.assessments.filter((a) => a.id !== id),
      events: state.events.filter((e) => e.assessmentId !== id)
    });
  });
}

// src/background.ts
var ALLOWED_HEADERS = /* @__PURE__ */ new Set([
  "content-security-policy",
  "content-security-policy-report-only",
  "strict-transport-security",
  "x-content-type-options",
  "referrer-policy",
  "x-frame-options",
  "permissions-policy",
  "server",
  "x-powered-by",
  "cross-origin-opener-policy",
  "cross-origin-resource-policy",
  "cross-origin-embedder-policy",
  "access-control-allow-origin",
  "access-control-allow-credentials",
  "access-control-allow-methods",
  "access-control-allow-headers",
  "cache-control",
  "pragma",
  "vary",
  "content-type",
  "cf-ray",
  "via",
  "x-amz-cf-id",
  "x-served-by",
  "x-fastly-request-id",
  "x-vercel-id",
  "x-nf-request-id",
  "x-aspnet-version"
]);
var tabQueues = /* @__PURE__ */ new Map();
function tabTask(id, fn) {
  const task = (tabQueues.get(id) || Promise.resolve()).then(fn).catch(() => {
  });
  tabQueues.set(id, task);
  task.finally(() => {
    if (tabQueues.get(id) === task) tabQueues.delete(id);
  });
}
async function selected(url) {
  const { settings } = await getState();
  return settings.observedOrigins.includes(originOf(url)) && (!settings.scopes?.[originOf(url)] || inScope(url, settings.scopes[originOf(url)]));
}
var key = (id) => `navigation_${id}`;
async function readNav(id) {
  return (await chrome.storage.session.get(key(id)))[key(id)];
}
async function writeNav(id, nav) {
  await chrome.storage.session.set({ [key(id)]: nav });
}
chrome.webRequest.onBeforeRequest.addListener(
  (d) => {
    if (d.tabId < 0 || d.type !== "main_frame") return;
    tabTask(d.tabId, async () => {
      if (!await selected(d.url)) {
        await chrome.storage.session.remove(key(d.tabId));
        return;
      }
      const old = await readNav(d.tabId);
      if (old?.requestId === d.requestId) return;
      await writeNav(d.tabId, { requestId: d.requestId, startedAt: d.timeStamp, redirects: [] });
    });
    return void 0;
  },
  { urls: ["http://*/*", "https://*/*"], types: ["main_frame"] }
);
chrome.webRequest.onHeadersReceived.addListener(
  (d) => {
    if (d.tabId < 0) return;
    tabTask(d.tabId, async () => {
      if (!await selected(d.url)) return;
      let nav = await readNav(d.tabId);
      if (!nav || nav.requestId !== d.requestId)
        nav = { requestId: d.requestId, startedAt: d.timeStamp, redirects: [] };
      const headers = {};
      for (const h of d.responseHeaders || [])
        if (ALLOWED_HEADERS.has(h.name.toLowerCase()))
          (headers[h.name.toLowerCase()] ??= []).push(redactHeader(h.value || ""));
      nav.response = {
        url: redactUrl(d.url),
        urlHash: await hashUrl(d.url),
        headers,
        statusCode: d.statusCode,
        collectedAt: new Date(d.timeStamp).toISOString(),
        requestId: d.requestId,
        startedAt: nav.startedAt,
        redirects: nav.redirects
      };
      await writeNav(d.tabId, nav);
    });
    return void 0;
  },
  { urls: ["http://*/*", "https://*/*"], types: ["main_frame"] },
  ["responseHeaders"]
);
chrome.webRequest.onBeforeRedirect.addListener(
  (d) => {
    if (d.tabId < 0) return;
    tabTask(d.tabId, async () => {
      const nav = await readNav(d.tabId);
      if (!nav || nav.requestId !== d.requestId || !await selected(d.url)) return;
      nav.redirects.push({
        url: redactUrl(d.url),
        destination: redactUrl(d.redirectUrl),
        statusCode: d.statusCode,
        collectedAt: new Date(d.timeStamp).toISOString()
      });
      nav.redirects = nav.redirects.slice(-20);
      delete nav.response;
      await writeNav(d.tabId, nav);
    });
    return void 0;
  },
  { urls: ["http://*/*", "https://*/*"], types: ["main_frame"] }
);
chrome.webNavigation.onCommitted.addListener(
  (d) => {
    if (d.frameId !== 0) return;
    tabTask(d.tabId, async () => {
      const nav = await readNav(d.tabId);
      if (!nav?.response || nav.response.urlHash !== await hashUrl(d.url) || d.timeStamp < nav.startedAt || d.timeStamp - nav.startedAt > 12e4) {
        await chrome.storage.session.remove(key(d.tabId));
        return;
      }
      nav.documentId = d.documentId;
      nav.response.documentId = d.documentId;
      await writeNav(d.tabId, nav);
    });
  },
  { url: [{ schemes: ["http", "https"] }] }
);
chrome.tabs.onRemoved.addListener((id) => {
  tabTask(id, async () => {
    await chrome.storage.session.remove(key(id));
  });
});
chrome.webRequest.onBeforeRequest.addListener(
  (d) => {
    if (d.tabId < 0 || d.type !== "main_frame") return;
    tabTask(d.tabId, async () => {
      const nav = await readNav(d.tabId);
      if (!nav?.redirects.length) await chrome.storage.session.remove(`requests_${d.tabId}`);
    });
    return void 0;
  },
  { urls: ["http://*/*", "https://*/*"], types: ["main_frame"] }
);
chrome.webRequest.onHeadersReceived.addListener(
  (d) => {
    if (d.tabId < 0 || d.type === "main_frame") return;
    tabTask(d.tabId, async () => {
      const nav = await readNav(d.tabId);
      if (!nav?.documentId || d.documentId !== nav.documentId || !d.initiator || !await selected(d.initiator))
        return;
      const state = await getState();
      const scope = state.settings.scopes?.[originOf(d.initiator)] || defaultScope(d.initiator);
      if (!inScope(d.url, scope, originOf(d.url) !== originOf(d.initiator))) return;
      const headers = {};
      for (const h of d.responseHeaders || [])
        if (ALLOWED_HEADERS.has(h.name.toLowerCase()))
          (headers[h.name.toLowerCase()] ??= []).push(redactHeader(h.value || ""));
      const storageKey = `requests_${d.tabId}`;
      const requests = (await chrome.storage.session.get(storageKey))[storageKey] || [];
      requests.push({
        url: redactUrl(d.url),
        method: d.method,
        type: d.type,
        statusCode: d.statusCode,
        contentType: headers["content-type"]?.[0],
        headers,
        initiator: redactUrl(d.initiator),
        authentication: "unknown",
        firstObserved: new Date(d.timeStamp).toISOString(),
        provenance: {
          source: "intercepted-request",
          collector: "chrome.webRequest",
          requestId: d.requestId,
          documentId: d.documentId,
          statusCode: d.statusCode,
          limitation: "Credential presence and values were not inspected."
        }
      });
      await chrome.storage.session.set({ [storageKey]: requests.slice(-200) });
    });
    return void 0;
  },
  { urls: ["http://*/*", "https://*/*", "ws://*/*", "wss://*/*"] },
  ["responseHeaders"]
);
async function collectCookies(tabId, url, documentId) {
  if (!await chrome.permissions.contains({
    permissions: ["cookies"],
    origins: [`${originOf(url)}/*`]
  }))
    return {
      available: false,
      cookies: [],
      limitation: "Cookie permission or site access unavailable. Enable cookie inspection in the extension popup."
    };
  try {
    const stores = await chrome.cookies.getAllCookieStores();
    const storeId = stores.find((s) => s.tabIds.includes(tabId))?.id;
    if (!storeId) throw new Error("Cookie store not available.");
    const unpartitioned = await chrome.cookies.getAll({ url, storeId });
    const partition = await chrome.cookies.getPartitionKey({ tabId, frameId: 0, documentId });
    const partitioned = await chrome.cookies.getAll({
      url,
      storeId,
      partitionKey: partition.partitionKey
    });
    const unique = new Map(
      [...unpartitioned, ...partitioned].map((c) => [
        JSON.stringify([c.name, c.domain, c.path, c.partitionKey]),
        cookieMetadata(c)
      ])
    );
    return {
      available: true,
      cookies: [...unique.values()].slice(0, 200),
      limitation: `Only cookies matching the inspected document URL in its cookie store were queried, including the current partition. Other paths and third-party iframe cookies are not assessed.${unique.size > 200 ? " Collection capped at 200 cookies." : ""}`
    };
  } catch {
    return {
      available: false,
      cookies: [],
      limitation: "Cookie collection could not be completed. The page may have navigated or cookie access may be restricted."
    };
  }
}
var inspectionLocks = /* @__PURE__ */ new Set();
async function inspect(tabId, baselineId, checkId, includeCookies) {
  if (!Number.isInteger(tabId) || tabId < 0)
    throw new Error(
      "No original website tab is available. Open the website and inspect it from the popup."
    );
  if (inspectionLocks.has(tabId)) throw new Error("This tab is already being inspected.");
  inspectionLocks.add(tabId);
  try {
    const started = performance.now();
    const tab = await chrome.tabs.get(tabId);
    if (!httpUrl(tab.url || "")) throw new Error("Open an HTTP or HTTPS page first.");
    if (tab.incognito) throw new Error("Private browsing inspection is disabled.");
    if (typeof includeCookies === "boolean")
      await setSettings({ cookieInspection: includeCookies });
    const configured = await getState();
    const allowedScope = configured.settings.scopes?.[originOf(tab.url)] || defaultScope(tab.url);
    if (!inScope(tab.url, allowedScope))
      throw new Error("This document is outside the configured scope or in an excluded path.");
    const initial = await chrome.webNavigation.getFrame({ tabId, frameId: 0 });
    if (!initial?.documentId) throw new Error("Wait for the page to finish loading.");
    const results = await chrome.scripting.executeScript({
      target: { tabId, documentIds: [initial.documentId] },
      func: collectPage
    });
    const page = results[0]?.result;
    if (!page) throw new Error("Page collection failed.");
    try {
      const result = await chrome.scripting.executeScript({
        target: { tabId, documentIds: [initial.documentId] },
        world: "MAIN",
        func: collectRuntimeTechnologies
      });
      const runtime = result[0]?.result;
      if (runtime && Math.abs(runtime.timeOrigin - page.timeOrigin) < 1e3 && await hashUrl(runtime.url) === await hashUrl(page.url))
        page.indicators.push(...runtime.technologies);
      else
        page.limits.push(
          "Runtime technology metadata could not be matched to the collected document."
        );
    } catch {
      page.limits.push("Runtime technology data properties could not be assessed.");
    }
    page.analysis = analyzeScripts(page.inlineScripts || []);
    page.secrets = await scanScriptSecrets(page.inlineScripts || [], page.url);
    const targetKey = await hashUrl(page.url);
    const state = await getState();
    const baseline = baselineId ? state.assessments.find((a) => a.id === baselineId) : void 0;
    const scope = state.settings.scopes?.[originOf(page.url)] || defaultScope(page.url);
    if (!inScope(page.url, scope))
      throw new Error("This document is outside the configured scope or in an excluded path.");
    if (checkId && (!baseline || baseline.targetKey !== targetKey))
      throw new Error(
        "The website URL changed or its baseline was deleted. Inspect the current target again."
      );
    await tabQueues.get(tabId);
    const nav = await readNav(tabId);
    const response = nav?.documentId === initial.documentId && nav.response?.urlHash === targetKey ? nav.response : null;
    const cookies = configured.settings.cookieInspection !== false && (!checkId || checkId.startsWith("SL-COOKIE")) ? await collectCookies(tabId, page.url, initial.documentId) : {
      available: false,
      cookies: [],
      limitation: "Cookie collection not required for this selected check."
    };
    const finalFrame = await chrome.webNavigation.getFrame({ tabId, frameId: 0 });
    if (finalFrame?.documentId !== initial.documentId)
      throw new Error("The website navigated during inspection. Try again.");
    const permission = await chrome.permissions.getAll();
    const requests = (await chrome.storage.session.get(`requests_${tabId}`))[`requests_${tabId}`];
    let assessment = inheritHistory(
      assess(
        {
          page,
          response,
          cookies,
          browser: navigator.userAgent.replace(/\([^)]*\)/g, "").trim().slice(0, 128),
          targetKey,
          scope,
          permissions: [...permission.permissions || [], ...permission.origins || []],
          profile: "extension-passive",
          suppressions: state.settings.suppressions || [],
          requests: requests || [],
          projectId: state.settings.projectId,
          environment: state.settings.environment
        },
        checkId
      ),
      state.assessments,
      state.events
    );
    assessment.durationMs = Math.round(performance.now() - started);
    if (baseline) assessment.baselineId = baseline.id;
    const verification = baseline ? verificationResult(baseline, assessment) : void 0;
    if (verification?.verified) assessment.findings[0].lifecycle = "verified";
    else if (checkId && assessment.findings[0].lifecycle === "verified")
      assessment.findings[0].lifecycle = "needs verification";
    await saveAssessment(assessment);
    const bindingKey = "binding_" + assessment.id;
    const bindingValue = { tabId, documentId: initial.documentId };
    await chrome.storage.session.set({ [bindingKey]: bindingValue });
    await chrome.storage.local.set({ [bindingKey]: bindingValue });
    if (verification && checkId)
      await setLifecycle(
        assessment.id,
        checkId,
        verification.verified ? "verified" : "needs verification",
        verification.reason
      );
    return { id: assessment.id, verification };
  } finally {
    inspectionLocks.delete(tabId);
  }
}
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (sender.id !== chrome.runtime.id || !sender.url?.startsWith(chrome.runtime.getURL(""))) return;
  (async () => {
    switch (message.type) {
      case "inspect":
        return inspect(
          message.tabId,
          void 0,
          void 0,
          typeof message.includeCookies === "boolean" ? message.includeCookies : void 0
        );
      case "verify": {
        const binding = (await chrome.storage.session.get("binding_" + message.assessmentId))["binding_" + message.assessmentId];
        return inspect(binding?.tabId ?? -1, message.assessmentId, message.checkId);
      }
      case "reinspect": {
        const bKey = "binding_" + message.assessmentId;
        let bnd = (await chrome.storage.session.get(bKey))[bKey];
        if (!bnd) bnd = (await chrome.storage.local.get(bKey))[bKey];
        return inspect(bnd?.tabId ?? -1);
      }
      case "freshness": {
        const state = await getState();
        const a = state.assessments.find((a2) => a2.id === message.assessmentId);
        if (!a) throw new Error("Assessment unavailable.");
        const bindingKey = "binding_" + a.id;
        let binding = (await chrome.storage.session.get(bindingKey))[bindingKey];
        if (!binding) {
          binding = (await chrome.storage.local.get(bindingKey))[bindingKey];
          if (binding) await chrome.storage.session.set({ [bindingKey]: binding });
        }
        let documentId, target;
        if (!binding) {
          try {
            const tabs = await chrome.tabs.query({});
            for (const tab of tabs) {
              if (!tab.url || !tab.id) continue;
              try {
                const tabHash = await hashUrl(tab.url);
                if (tabHash === a.targetKey) {
                  target = tabHash;
                  try {
                    const frame = await chrome.webNavigation.getFrame({ tabId: tab.id, frameId: 0 });
                    documentId = frame?.documentId;
                    if (documentId) {
                      const restored = { tabId: tab.id, documentId };
                      await chrome.storage.session.set({ [bindingKey]: restored });
                      await chrome.storage.local.set({ [bindingKey]: restored });
                    }
                  } catch {
                  }
                  break;
                }
              } catch {
              }
            }
          } catch {
          }
        } else {
          try {
            const tab = await chrome.tabs.get(binding.tabId);
            try {
              target = await hashUrl(tab.url || "");
            } catch {
            }
            try {
              documentId = (await chrome.webNavigation.getFrame({ tabId: binding.tabId, frameId: 0 }))?.documentId;
            } catch {
            }
          } catch {
          }
        }
        return {
          status: a.importedAt ? "older assessment" : freshness(a, binding || (target ? { tabId: -1, documentId: documentId || "" } : void 0), documentId, target),
          collectedAt: a.evidence.find((e) => e.type === "document")?.collectedAt || a.createdAt
        };
      }
      case "storage-usage": {
        return {
          bytes: await chrome.storage.local.getBytesInUse(),
          quota: chrome.storage.local.QUOTA_BYTES
        };
      }
      case "bundles": {
        const state = await getState(), a = state.assessments.find((a2) => a2.id === message.assessmentId);
        if (!a || a.kind !== "full") throw new Error("Choose a full assessment.");
        const scope = state.settings.scopes?.[a.origin];
        if (!scope || scope.mode !== "supplemental" || !scope.authorized)
          throw new Error("Save an authorized supplemental scope first.");
        const urls = message.urls;
        if (!Array.isArray(urls) || !urls.length || urls.length > 10 || urls.some(
          (u) => typeof u !== "string" || !a.resources.some((r) => r.url === u && r.type === "script") || u.includes("?REDACTED") || !inScope(u, scope, originOf(u) !== a.origin)
        ))
          throw new Error(
            "Select 1\u201310 recorded script URLs within scope. Redacted query URLs need a new inspectable reference."
          );
        for (const u of urls)
          if (!await chrome.permissions.contains({ origins: [originOf(u) + "/*"] }))
            throw new Error("Grant access to the selected script origin first.");
        const budgetKey = "bundle-budget_" + a.id;
        await transaction(async () => {
          if ((await chrome.storage.session.get(budgetKey))[budgetKey])
            throw new Error(
              "Bundle budget already used for this assessment. Start a new assessment before another batch."
            );
          await chrome.storage.session.set({ [budgetKey]: true });
        });
        const budget = new RequestBudget(scope), copy = structuredClone(a), records = [];
        for (const url of [...new Set(urls)]) {
          try {
            const body = await scopedText(
              url,
              scope,
              budget,
              async (target, init) => {
                if (!await chrome.permissions.contains({
                  origins: [originOf(String(target)) + "/*"]
                }))
                  throw new Error("Bundle destination permission is not granted.");
                return fetch(target, init);
              },
              a.origin
            );
            const secrets = await scanScriptSecrets([{ id: body.url, code: body.text }], body.url), analysis = analyzeScripts([{ id: body.url, code: body.text }]);
            copy.technologies.push(...detectBundleTechnologies(body.text, body.url));
            const ev = copy.evidence.find((e) => e.label === "Redacted configuration patterns");
            if (ev && Array.isArray(ev.data)) ev.data.push(...secrets);
            const ast = copy.evidence.find((e) => e.label === "Client-side AST observations");
            if (ast) {
              if (!ast.data) ast.data = analyzeScripts([]);
              const current2 = ast.data;
              for (const k of ["apis", "sources", "flows", "handlers"])
                current2[k].push(...analysis[k]);
              current2.parsed += analysis.parsed;
              current2.failed += analysis.failed;
              current2.limitation = "Static analysis of captured inline scripts and explicitly selected bundles. Unvisited code, dynamic behavior and runtime exploitability are not established.";
            }
            records.push({ url: body.url, status: "inspected", bytes: body.bytes });
          } catch (error) {
            records.push({
              url: redactUrl(url),
              status: "failed",
              error: error.message
            });
          }
        }
        const result = replayAssessment(copy, state.settings);
        result.reproducibility = void 0;
        result.supplemental = {
          sourceAssessmentId: a.id,
          collectedAt: (/* @__PURE__ */ new Date()).toISOString(),
          urls: records.filter((r) => r.status === "inspected").map((r) => r.url)
        };
        result.baselineId = a.id;
        result.profile = "extension-supplemental";
        result.coverage.push({
          area: "Selected external bundles",
          status: "partial",
          detail: `${records.filter((r) => r.status === "inspected").length} of ${records.length} selected bundles read. Unselected scripts and runtime behavior remain unassessed.`
        });
        result.limits = result.limits.filter((s) => !s.startsWith("Re-evaluation"));
        result.limits.push(
          "Selected external bundles requested explicitly; raw source and full credential values omitted."
        );
        result.evidence.push({
          id: "EV-BUNDLE",
          type: "resource",
          label: "Selected bundle inspection",
          source: a.url,
          data: records,
          collectedAt: result.supplemental.collectedAt,
          redacted: true,
          provenance: { source: "extension-request", collector: "Scoped bundle reader" }
        });
        for (const e of result.evidence.filter(
          (e2) => [
            "Redacted configuration patterns",
            "Client-side AST observations",
            "Technology indicators"
          ].includes(e2.label)
        )) {
          e.collectedAt = result.supplemental.collectedAt;
          e.provenance = {
            source: "inference",
            collector: "DOM and scoped bundle static analysis",
            limitation: "Combined observations; script locations identify the source. External source was read by extension requests."
          };
        }
        await saveAssessment(result);
        return { id: result.id, records };
      }
      case "state":
        return getState();
      case "secret-values": {
        const state = await getState();
        const assessment = state.assessments.find((a) => a.id === message.assessmentId);
        const binding = (await chrome.storage.session.get("binding_" + message.assessmentId))["binding_" + message.assessmentId];
        if (!assessment || !binding)
          throw new Error(
            "Full values were not saved. Inspect the original website again to display live values."
          );
        const tab = await chrome.tabs.get(binding.tabId);
        if (tab.incognito || !httpUrl(tab.url || ""))
          throw new Error("The original website is unavailable.");
        const scope = state.settings.scopes?.[assessment.origin] || defaultScope(assessment.url);
        if (!inScope(tab.url, scope))
          throw new Error("The original website is outside the configured scope.");
        if (await hashUrl(tab.url) !== assessment.targetKey)
          throw new Error("The website URL changed. Inspect it again to display current values.");
        const frame = await chrome.webNavigation.getFrame({ tabId: binding.tabId, frameId: 0 });
        if (frame?.documentId !== binding.documentId)
          throw new Error(
            "The original document was reloaded. Inspect it again to display current values."
          );
        const result = await chrome.scripting.executeScript({
          target: { tabId: binding.tabId, documentIds: [binding.documentId] },
          func: collectPage
        });
        const snapshot = result[0]?.result;
        if (!snapshot || await hashUrl(snapshot.url) !== assessment.targetKey || (await chrome.webNavigation.getFrame({ tabId: binding.tabId, frameId: 0 }))?.documentId !== binding.documentId)
          throw new Error("The website navigated during collection. Inspect it again.");
        const saved = assessment.evidence.find((e) => e.label === "Redacted configuration patterns")?.data;
        const values2 = await readSecretValues(
          (snapshot.inlineScripts || []).map((s) => s.code).join("\n")
        );
        return {
          values: values2.filter(
            (v) => saved?.some(
              (s) => s.key === v.key.slice(0, 100) && s.valueFingerprint === v.valueFingerprint
            )
          )
        };
      }
      case "reevaluate": {
        const state = await getState();
        const a = state.assessments.find((a2) => a2.id === message.assessmentId);
        if (!a || a.kind !== "full")
          throw new Error("Choose a full assessment with retained evidence.");
        const result = replayAssessment(a, state.settings);
        await saveAssessment(result);
        return { id: result.id };
      }
      case "source-maps": {
        const data2 = await getState();
        const a = data2.assessments.find((a2) => a2.id === message.assessmentId);
        if (!a) throw new Error("Assessment not available.");
        const scope = data2.settings.scopes?.[a.origin];
        if (!scope || scope.mode !== "supplemental" || !scope.authorized)
          throw new Error(
            "Configure and authorize supplemental scope before inspecting source maps."
          );
        const budgetKey = "supplement_" + a.id;
        return transaction(async () => {
          if ((await chrome.storage.session.get(budgetKey))[budgetKey])
            throw new Error(
              "Supplemental map inspection already attempted for this assessment. Create a new assessment to establish a new request budget."
            );
          await chrome.storage.session.set({ [budgetKey]: true });
          const supplemental = structuredClone(a);
          supplemental.id = crypto.randomUUID();
          supplemental.createdAt = (/* @__PURE__ */ new Date()).toISOString();
          supplemental.baselineId = a.id;
          supplemental.profile = "extension-supplemental";
          const evidence = supplemental.evidence.find((e) => e.label === "Source map observations");
          const urls = Array.isArray(evidence?.data) ? evidence.data.filter((v) => typeof v === "string") : [];
          const maps = await inspectSourceMaps(urls, scope);
          if (evidence) {
            evidence.data = maps;
            evidence.provenance = {
              source: "extension-request",
              collector: "Authorized bounded source-map inspection"
            };
          }
          if (evidence) evidence.collectedAt = supplemental.createdAt;
          supplemental.coverage.push({
            area: "Source map contents",
            status: "partial",
            detail: "Explicitly authorized bounded requests; source paths and redacted credential patterns only."
          });
          await chrome.storage.local.set({
            records: [supplemental, ...data2.assessments].slice(0, data2.settings.retention)
          });
          return { maps, id: supplemental.id };
        });
      }
      case "observe": {
        if (!httpUrl(message.origin)) throw new Error("Invalid origin.");
        const origin = originOf(message.origin);
        if (!await chrome.permissions.contains({ origins: [`${origin}/*`] }))
          throw new Error("Site access was not granted.");
        const state = await getState();
        return setSettings({
          observedOrigins: [.../* @__PURE__ */ new Set([...state.settings.observedOrigins, origin])]
        });
      }
      case "settings":
        return setSettings({
          learningMode: !!message.learningMode,
          retention: Number.isFinite(Number(message.retention)) ? Number(message.retention) : 50
        });
      case "lifecycle":
        return setLifecycle(
          message.assessmentId,
          message.checkId,
          message.state,
          String(message.note || ""),
          {
            actor: message.actor,
            owner: message.owner,
            expiresAt: message.expiresAt,
            reviewRequired: message.reviewRequired
          }
        );
      case "delete":
        await deleteAssessment(message.id);
        return { ok: true };
      case "import": {
        if (JSON.stringify(message.data || message.assessment).length > 1e7)
          throw new Error("Backup exceeds 10 MB.");
        const imported = validateBackup(message.data || message.assessment);
        return transaction(async () => {
          const state = await getState();
          const seen = [...state.assessments];
          const added = imported.assessments.filter((a) => {
            if (seen.some(
              (old) => old.id === a.id || old.originalId === a.originalId && old.targetKey === a.targetKey && old.createdAt === a.createdAt
            ))
              return false;
            seen.push(a);
            return true;
          });
          if (state.assessments.length + added.length > 200)
            throw new Error("Restore would exceed 200 records. Delete unneeded records first.");
          const ids = new Set(added.map((a) => a.id));
          await chrome.storage.local.set({
            records: [...added, ...state.assessments].sort(
              (a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt)
            ),
            events: [
              ...state.events,
              ...imported.events.filter((e) => ids.has(e.assessmentId))
            ].slice(-2e3),
            settings: {
              ...state.settings,
              retention: Math.max(
                state.settings.retention,
                state.assessments.length + added.length
              )
            }
          });
          return { added: added.length, skipped: imported.assessments.length - added.length };
        });
      }
      case "report-options":
        return setSettings({ reportOptions: validateReportOptions(message.options) });
      case "scope": {
        const scope = validateScope(message.scope);
        return setSettings({
          scopes: { ...(await getState()).settings.scopes, [message.origin]: scope }
        });
      }
      case "suppression": {
        const suppression = validateSuppression(message.suppression);
        return setSettings({
          suppressions: [
            ...((await getState()).settings.suppressions || []).filter(
              (s) => s.id !== suppression.id
            ),
            suppression
          ]
        });
      }
      case "remove-suppression":
        return setSettings({
          suppressions: ((await getState()).settings.suppressions || []).filter(
            (s) => s.id !== message.id
          )
        });
      case "project": {
        const project = message.project;
        if (!project?.name || !Array.isArray(project.environments) || project.environments.length > 20 || project.environments.some(
          (e) => !e.name || !Array.isArray(e.origins) || e.origins.length > 50 || e.origins.some((o) => !httpUrl(o) || originOf(o) !== o)
        ))
          throw new Error("Project name and environments required.");
        return setSettings({
          projects: [
            ...((await getState()).settings.projects || []).filter((p) => p.id !== project.id),
            {
              id: project.id || crypto.randomUUID(),
              name: String(project.name).slice(0, 128),
              environments: project.environments
            }
          ],
          projectId: project.id,
          environment: String(message.environment || "")
        });
      }
      case "clear":
        await transaction(async () => {
          await chrome.storage.local.remove(["records", "events", "assessments"]);
          await chrome.storage.session.clear();
        });
        return { ok: true };
      case "revoke": {
        const origin = originOf(message.origin);
        await chrome.permissions.remove({ origins: [`${origin}/*`] });
        const state = await getState();
        return setSettings({
          observedOrigins: state.settings.observedOrigins.filter((o) => o !== origin)
        });
      }
      default:
        throw new Error("Unknown operation.");
    }
  })().then(reply).catch(
    (error) => reply({ error: error instanceof Error ? error.message : "Operation failed." })
  );
  return true;
});
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason !== "update") return;
  void (async () => {
    const state = await getState();
    const targets = /* @__PURE__ */ new Set();
    for (const a of state.assessments) {
      if (a.kind !== "full" || targets.has(a.targetKey)) continue;
      targets.add(a.targetKey);
      if (a.ruleSetVersion !== RULESET_VERSION || CHECKS.some((c) => a.ruleVersions?.[c.id] !== ruleVersion(c))) {
        try {
          await saveAssessment(replayAssessment(a, state.settings));
        } catch {
        }
      }
    }
  })().catch(() => {
  });
});
//# sourceMappingURL=background.js.map
