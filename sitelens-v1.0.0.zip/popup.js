// src/ui/shared.ts
async function send(message2) {
  const result = await chrome.runtime.sendMessage(message2);
  if (result?.error) throw new Error(result.error);
  return result;
}

// ../../packages/rule-definitions/src/privacy.ts
function text(value, limit = 4096) {
  return String(value ?? "").replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "").slice(0, limit);
}
function redactUrl(value) {
  try {
    if (!value) return "[unavailable URL]";
    const u = new URL(value);
    if (!["http:", "https:"].includes(u.protocol)) return `${u.protocol}[OMITTED]`;
    u.username = "";
    u.password = "";
    u.hash = "";
    if (u.search) u.search = "?REDACTED";
    u.pathname = u.pathname.split("/").map((p) => p.length > 80 || /^eyJ[\w-]+\.[\w-]+\.[\w-]+$/.test(p) ? "[REDACTED]" : p).join("/");
    return text(u.href, 2048);
  } catch {
    return "[unavailable URL]";
  }
}
function originOf(url) {
  try {
    if (!url) return "";
    return new URL(url).origin;
  } catch {
    return "";
  }
}
function httpUrl(url) {
  try {
    return ["http:", "https:"].includes(new URL(url).protocol);
  } catch {
    return false;
  }
}

// src/popup.ts
var [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
var target = document.querySelector("#popup-target");
var button = document.querySelector("#inspect");
var message = document.querySelector("#message");
target.textContent = httpUrl(tab?.url || "") ? redactUrl(tab.url) : "Open a regular HTTP or HTTPS website.";
button.disabled = !httpUrl(tab?.url || "");
var cookieInput = document.querySelector("#cookies");
cookieInput.checked = await chrome.permissions.contains({ permissions: ["cookies"] });
document.querySelector("#open").onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL("dashboard/index.html") });
button.onclick = async () => {
  button.disabled = true;
  message.textContent = "Collecting browser-visible evidence\u2026";
  try {
    if (!tab?.id || !httpUrl(tab.url || ""))
      throw new Error("Open an HTTP or HTTPS website first.");
    const headers = document.querySelector("#headers").checked;
    const cookies = cookieInput.checked;
    const origin = originOf(tab.url);
    if (headers || cookies) {
      const granted = await chrome.permissions.request({
        origins: [`${origin}/*`],
        ...cookies ? { permissions: ["cookies"] } : {}
      });
      if (granted && headers) await send({ type: "observe", origin });
    }
    const result = await send({
      type: "inspect",
      tabId: tab.id,
      includeCookies: cookies
    });
    await chrome.tabs.create({
      url: chrome.runtime.getURL(`dashboard/index.html?id=${result.id}`)
    });
    window.close();
  } catch (error) {
    message.textContent = error instanceof Error ? error.message : "Inspection failed.";
  } finally {
    button.disabled = false;
  }
};
//# sourceMappingURL=popup.js.map
